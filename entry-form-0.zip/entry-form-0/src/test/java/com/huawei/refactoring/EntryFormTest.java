package com.huawei.refactoring;

import org.junit.Test;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class EntryFormTest {

}
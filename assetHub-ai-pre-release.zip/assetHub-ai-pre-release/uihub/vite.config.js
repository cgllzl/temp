import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  root: "web",
  plugins: [react()],
  build: {
    outDir: "../dist",
    emptyOutDir: true
  },
  server: {
    host: "0.0.0.0",
    port: 5173,
    proxy: {
      "/lobe-market": "http://localhost:8092",
      "/session": "http://localhost:8092",
      "/auth": "http://localhost:8092"
    }
  }
});

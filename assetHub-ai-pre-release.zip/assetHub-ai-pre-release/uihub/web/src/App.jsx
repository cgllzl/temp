import { useEffect, useMemo, useState } from "react";
import {
  App as AntdApp,
  Badge,
  Button,
  Card,
  Col,
  Empty,
  Flex,
  Input,
  Layout,
  Row,
  Select,
  Space,
  Spin,
  Statistic,
  Tabs,
  Tag,
  Typography
} from "antd";
import {
  BellOutlined,
  CompassOutlined,
  FunnelPlotOutlined,
  RocketOutlined,
  SearchOutlined,
  ThunderboltOutlined
} from "@ant-design/icons";

const { Header, Content } = Layout;
const { Title, Paragraph, Text } = Typography;

const TAB_CONFIG = [
  { key: "agents", label: "Agents", endpoint: "/lobe-market/v1/agents" },
  { key: "mcp", label: "MCP", endpoint: "/lobe-market/v1/mcp" },
  { key: "skills", label: "Skills", endpoint: "/lobe-market/v1/skills" },
  { key: "prompts", label: "Prompts", endpoint: "/lobe-market/v1/prompts" }
];

const TAB_COLOR = {
  agents: "#1D4ED8",
  mcp: "#2563EB",
  skills: "#0EA5E9",
  prompts: "#0284C7"
};

const safeArray = (value) => (Array.isArray(value) ? value : []);
const asText = (value, fallback = "") => String(value || fallback);
const titleOf = (item) => asText(item.title || item.name || item.identifier, "未命名能力");
const summaryOf = (item) => asText(item.summary || item.description, "暂无描述");
const categoryOf = (item) => asText(item.category, "general");
const updatedAtOf = (item) => asText(item.updatedAt || item.createdAt, "");

const useMarketData = () => {
  const [metrics, setMetrics] = useState({ agents: 0, mcp: 0, skills: 0, prompts: 0 });
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(false);
  const { message } = AntdApp.useApp();

  useEffect(() => {
    let active = true;
    const load = async () => {
      setLoading(true);
      try {
        const results = await Promise.all(
          TAB_CONFIG.map(async (tab) => {
            const resp = await fetch(`${tab.endpoint}?page=1&pageSize=6&sort=updatedAt&order=desc`);
            if (!resp.ok) throw new Error(`${tab.label} 请求失败`);
            const data = await resp.json();
            return {
              key: tab.key,
              totalCount: Number(data?.totalCount || 0),
              items: safeArray(data?.items).map((item) => ({ ...item, dimension: tab.key }))
            };
          })
        );

        if (!active) return;

        setMetrics({
          agents: results.find((r) => r.key === "agents")?.totalCount || 0,
          mcp: results.find((r) => r.key === "mcp")?.totalCount || 0,
          skills: results.find((r) => r.key === "skills")?.totalCount || 0,
          prompts: results.find((r) => r.key === "prompts")?.totalCount || 0
        });

        const allNews = results
          .flatMap((r) => r.items)
          .sort((a, b) => new Date(updatedAtOf(b)).getTime() - new Date(updatedAtOf(a)).getTime())
          .slice(0, 8)
          .map((item, idx) => ({
            id: `${item.dimension}-${item.identifier || idx}`,
            title: titleOf(item),
            summary: summaryOf(item),
            updatedAt: updatedAtOf(item),
            dimension: item.dimension,
            category: categoryOf(item)
          }));
        setNews(allNews);
      } catch (error) {
        message.error(error?.message || "资讯加载失败");
      } finally {
        if (active) setLoading(false);
      }
    };

    load();
    return () => {
      active = false;
    };
  }, [message]);

  return { metrics, news, loading };
};

const CapabilityTabPane = ({ tabKey, endpoint }) => {
  const { message } = AntdApp.useApp();
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [page, setPage] = useState(1);
  const [keyword, setKeyword] = useState("");
  const [queryKeyword, setQueryKeyword] = useState("");
  const [category, setCategory] = useState("");
  const [categories, setCategories] = useState([]);
  const pageSize = 9;

  const loadCategories = async (q = "") => {
    try {
      const resp = await fetch(`${endpoint}/categories${q ? `?q=${encodeURIComponent(q)}` : ""}`);
      if (!resp.ok) throw new Error("分类加载失败");
      const data = await resp.json();
      setCategories(safeArray(data).map((it) => ({ value: it.category, label: `${it.category} (${it.count})` })));
    } catch {
      setCategories([]);
    }
  };

  const loadList = async (reset = false) => {
    setLoading(true);
    try {
      const targetPage = reset ? 1 : page;
      const params = new URLSearchParams({
        page: String(targetPage),
        pageSize: String(pageSize),
        sort: "updatedAt",
        order: "desc"
      });
      if (queryKeyword) params.set("q", queryKeyword);
      if (category) params.set("category", category);

      const resp = await fetch(`${endpoint}?${params.toString()}`);
      if (!resp.ok) throw new Error("列表加载失败");
      const data = await resp.json();
      const nextItems = safeArray(data?.items).filter((item) => asText(item.visibility, "public") === "public");
      setItems(nextItems);
      setTotalCount(Number(data?.totalCount || nextItems.length));
      if (reset) setPage(1);
    } catch (error) {
      message.error(error?.message || "加载失败");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCategories(queryKeyword);
  }, [queryKeyword]);

  useEffect(() => {
    loadList(true);
  }, [queryKeyword, category, endpoint]);

  const hasMore = useMemo(() => page * pageSize < totalCount, [page, pageSize, totalCount]);

  const onSearch = () => {
    setQueryKeyword(keyword.trim());
  };

  return (
    <Space direction="vertical" size={20} style={{ width: "100%" }}>
      <Card className="portal-filter-card" bordered={false}>
        <Row gutter={[12, 12]}>
          <Col xs={24} md={10}>
            <Input
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              onPressEnter={onSearch}
              allowClear
              placeholder="搜索名称、描述、标签"
              prefix={<SearchOutlined />}
            />
          </Col>
          <Col xs={24} md={8}>
            <Select
              value={category || undefined}
              allowClear
              onChange={(val) => setCategory(val || "")}
              style={{ width: "100%" }}
              placeholder="分类"
              options={categories}
            />
          </Col>
          <Col xs={24} md={6}>
            <Button type="primary" block icon={<FunnelPlotOutlined />} onClick={onSearch}>
              应用筛选
            </Button>
          </Col>
        </Row>
      </Card>

      {loading ? (
        <Card className="portal-loading"><Spin /></Card>
      ) : items.length === 0 ? (
        <Card><Empty description="暂无能力" /></Card>
      ) : (
        <>
          <Row gutter={[16, 16]}>
            {items.map((item) => (
              <Col xs={24} md={12} xl={8} key={item.identifier || item.id}>
                <Card className="capability-card" bordered={false}>
                  <Space direction="vertical" size={12} style={{ width: "100%" }}>
                    <Flex justify="space-between" align="start">
                      <Tag color={TAB_COLOR[tabKey]}>{tabKey.toUpperCase()}</Tag>
                      <Text type="secondary">{updatedAtOf(item).slice(0, 10)}</Text>
                    </Flex>
                    <Title level={5} style={{ margin: 0 }}>{titleOf(item)}</Title>
                    <Paragraph ellipsis={{ rows: 2 }} style={{ margin: 0, color: "#64748B" }}>
                      {summaryOf(item)}
                    </Paragraph>
                    <Flex justify="space-between" align="center">
                      <Tag>{categoryOf(item)}</Tag>
                      <Text type="secondary">{item.version ? `v${item.version}` : "已上架"}</Text>
                    </Flex>
                  </Space>
                </Card>
              </Col>
            ))}
          </Row>
          <Flex justify="center" style={{ marginTop: 8 }}>
            <Button
              disabled={!hasMore}
              onClick={() => {
                const next = page + 1;
                setPage(next);
                setLoading(true);
                const params = new URLSearchParams({
                  page: String(next),
                  pageSize: String(pageSize),
                  sort: "updatedAt",
                  order: "desc"
                });
                if (queryKeyword) params.set("q", queryKeyword);
                if (category) params.set("category", category);
                fetch(`${endpoint}?${params.toString()}`)
                  .then((resp) => {
                    if (!resp.ok) throw new Error("加载更多失败");
                    return resp.json();
                  })
                  .then((data) => {
                    const nextItems = safeArray(data?.items).filter(
                      (item) => asText(item.visibility, "public") === "public"
                    );
                    setItems((prev) => [...prev, ...nextItems]);
                    setTotalCount(Number(data?.totalCount || totalCount));
                  })
                  .catch((error) => message.error(error?.message || "加载失败"))
                  .finally(() => setLoading(false));
              }}
            >
              {hasMore ? "加载更多" : "没有更多了"}
            </Button>
          </Flex>
        </>
      )}
    </Space>
  );
};

const PortalPage = () => {
  const { metrics, news, loading } = useMarketData();

  return (
    <Layout className="portal-layout">
      <Header className="portal-header">
        <Flex justify="space-between" align="center" style={{ width: "100%" }}>
          <Space size={12}>
            <div className="brand-dot" />
            <Text className="brand-text">AssetHub Enterprise Portal</Text>
          </Space>
          <Badge dot>
            <Button icon={<BellOutlined />}>资讯</Button>
          </Badge>
        </Flex>
      </Header>

      <Content className="portal-content">
        <div className="hero-panel">
          <Row gutter={[20, 20]} align="middle">
            <Col xs={24} xl={14}>
              <Tag className="section-pill" icon={<RocketOutlined />}>企业能力门户</Tag>
              <Title className="hero-title">
                统一展示已上架的 <span>Agent / MCP / Skill / Prompt</span>
              </Title>
              <Paragraph className="hero-desc">
                为业务用户提供可发现、可筛选、可对比的一站式能力目录，支持资讯追踪与多维能力检索。
              </Paragraph>
              <Space wrap>
                <Button type="primary" size="large" icon={<CompassOutlined />}>立即探索</Button>
                <Button size="large">查看接入指南</Button>
              </Space>
            </Col>
            <Col xs={24} xl={10}>
              <Card className="hero-stat-card" bordered={false}>
                <Row gutter={[16, 16]}>
                  <Col xs={12}><Statistic title="Agents" value={metrics.agents} /></Col>
                  <Col xs={12}><Statistic title="MCP" value={metrics.mcp} /></Col>
                  <Col xs={12}><Statistic title="Skills" value={metrics.skills} /></Col>
                  <Col xs={12}><Statistic title="Prompts" value={metrics.prompts} /></Col>
                </Row>
              </Card>
            </Col>
          </Row>
        </div>

        <Row gutter={[16, 16]} style={{ marginTop: 20 }}>
          <Col xs={24} xl={8}>
            <Card className="news-card" title="资讯中心" extra={<Tag color="blue">实时</Tag>} bordered={false}>
              <Spin spinning={loading}>
                <Space direction="vertical" size={10} style={{ width: "100%" }}>
                  {news.slice(0, 5).map((item) => (
                    <div className="news-item" key={item.id}>
                      <Flex justify="space-between" align="center">
                        <Tag color={TAB_COLOR[item.dimension]}>{item.dimension.toUpperCase()}</Tag>
                        <Text type="secondary">{item.updatedAt.slice(0, 10)}</Text>
                      </Flex>
                      <Text strong>{item.title}</Text>
                      <Paragraph ellipsis={{ rows: 2 }} style={{ margin: 0 }}>{item.summary}</Paragraph>
                    </div>
                  ))}
                </Space>
              </Spin>
            </Card>
          </Col>

          <Col xs={24} xl={16}>
            <Card className="tabs-card" bordered={false}>
              <Tabs
                defaultActiveKey="agents"
                items={TAB_CONFIG.map((tab) => ({
                  key: tab.key,
                  label: tab.label,
                  children: <CapabilityTabPane tabKey={tab.key} endpoint={tab.endpoint} />
                }))}
              />
            </Card>
          </Col>
        </Row>

        <div className="portal-cta">
          <ThunderboltOutlined className="cta-icon" />
          <div>
            <Title level={4} style={{ margin: 0, color: "#F8FAFC" }}>找不到所需能力？</Title>
            <Text style={{ color: "rgba(248,250,252,0.75)" }}>提交业务需求，我们将优先上架高频场景能力。</Text>
          </div>
          <Button type="primary" size="large">提交需求</Button>
        </div>
      </Content>
    </Layout>
  );
};

const App = () => (
  <AntdApp>
    <PortalPage />
  </AntdApp>
);

export default App;

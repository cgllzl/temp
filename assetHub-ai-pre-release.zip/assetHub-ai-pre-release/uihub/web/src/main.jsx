import React from "react";
import { createRoot } from "react-dom/client";
import { ConfigProvider } from "antd";
import zhCN from "antd/locale/zh_CN";
import App from "./App";
import "antd/dist/reset.css";
import "./styles.css";

const theme = {
  token: {
    colorPrimary: "#0052FF",
    colorInfo: "#0052FF",
    colorSuccess: "#16A34A",
    colorWarning: "#D97706",
    colorError: "#DC2626",
    colorTextBase: "#0F172A",
    colorBgBase: "#FAFAFA",
    borderRadius: 12,
    fontFamily: "Inter, PingFang SC, Microsoft YaHei, sans-serif"
  },
  components: {
    Button: {
      borderRadius: 12,
      controlHeight: 44
    },
    Card: {
      borderRadiusLG: 16
    },
    Tabs: {
      itemSelectedColor: "#0052FF",
      itemColor: "#64748B",
      inkBarColor: "#0052FF"
    }
  }
};

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ConfigProvider locale={zhCN} theme={theme}>
      <App />
    </ConfigProvider>
  </React.StrictMode>
);

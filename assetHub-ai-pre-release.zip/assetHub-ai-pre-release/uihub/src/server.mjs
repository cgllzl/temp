import { serve } from "@hono/node-server";
import { Hono } from "hono";
import { cors } from "hono/cors";
import { betterAuth } from "better-auth";
import { getMigrations } from "better-auth/db/migration";
import { DatabaseSync } from "node:sqlite";
import { Pool } from "pg";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";

const PORT = Number.parseInt(process.env.PORT || "8092", 10);
const AUTH_SECRET = process.env.BETTER_AUTH_SECRET || "";
const AUTH_BASE_URL_RAW = process.env.BETTER_AUTH_URL || "";
const AUTH_BASE_PATH = "/auth";
const AUTH_DB_PATH = process.env.UIHUB_DB_PATH || "/data/uihub/auth.sqlite";
const AUTH_DATABASE_URL = process.env.UIHUB_DATABASE_URL || "";
const AUTH_USE_POSTGRES = Boolean(AUTH_DATABASE_URL);
const AUTH_DB_BOOTSTRAP_RETRIES = Math.max(
  1,
  Number.parseInt(process.env.UIHUB_DB_BOOTSTRAP_RETRIES || "20", 10)
);
const AUTH_DB_BOOTSTRAP_DELAY_MS = Math.max(
  500,
  Number.parseInt(process.env.UIHUB_DB_BOOTSTRAP_DELAY_MS || "2000", 10)
);
const ADMIN_EMAIL = process.env.UIHUB_ADMIN_EMAIL || "";
const ADMIN_PASSWORD = process.env.UIHUB_ADMIN_PASSWORD || "";
const ADMIN_NAME = process.env.UIHUB_ADMIN_NAME || "AssetHub Admin";
const ADMIN_EMAILS = [
  ADMIN_EMAIL,
  ...(process.env.UIHUB_ADMIN_EMAILS || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean)
];
const TRUSTED_ORIGINS = (process.env.UIHUB_TRUSTED_ORIGINS || "")
  .split(",")
  .map((item) => item.trim())
  .filter(Boolean);

const MCP_BASE_URL = (process.env.MCPJUNGLE_BASE_URL || "http://ai-assethub-mcphub:8080").replace(/\/+$/, "");
const MCP_INIT_MODE = process.env.MCPJUNGLE_INIT_MODE || "enterprise";
const MCP_SERVER_MODE = process.env.MCPJUNGLE_SERVER_MODE || MCP_INIT_MODE;
const MCP_ADMIN_TOKEN_PATH = process.env.MCPJUNGLE_ADMIN_TOKEN_PATH || "/data/mcpjungle/admin.token";
const MCP_SERVICE_PRINCIPAL_NAME = process.env.MCP_SERVICE_PRINCIPAL_NAME || "svc-agenthub-runtime";
const MCP_SERVICE_PRINCIPAL_TOKEN_PATH =
  process.env.MCP_SERVICE_PRINCIPAL_TOKEN_PATH || "/data/mcpjungle/service-principals/agenthub-runtime.token";
const MCP_UI_USER_PREFIX = process.env.UIHUB_MCP_USER_PREFIX || "ui";
const MCP_UI_USER_TOKEN_DIR = process.env.UIHUB_MCP_USER_TOKEN_DIR || "/data/mcpjungle/ui-users";
const MCP_TIMEOUT = Number.parseInt(process.env.MCPJUNGLE_TIMEOUT_SECONDS || "10", 10);
const MCP_INIT_RETRIES = Number.parseInt(process.env.MCPJUNGLE_INIT_RETRIES || "30", 10);
const MCP_ADMIN_TOKEN_ENV = process.env.MCPJUNGLE_ADMIN_TOKEN || "";
const AGENTHUB_INTERNAL_URL = (process.env.AGENTHUB_INTERNAL_URL || "http://ai-assethub-agenthub:8091").replace(/\/+$/, "");
const SKILLHUB_INTERNAL_URL = (process.env.SKILLHUB_INTERNAL_URL || "http://ai-assethub-skillhub:8090").replace(/\/+$/, "");
const LOBE_MARKET_DEFAULT_AUTHOR = process.env.LOBE_MARKET_DEFAULT_AUTHOR || "AssetHub";
const CLIENT_DIST_DIR = process.env.UIHUB_WEB_DIST_DIR || path.join(process.cwd(), "dist");

const STATIC_CONTENT_TYPES = {
  ".css": "text/css; charset=utf-8",
  ".gif": "image/gif",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".map": "application/json; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".otf": "font/otf",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ttf": "font/ttf",
  ".webp": "image/webp",
  ".woff": "font/woff",
  ".woff2": "font/woff2"
};

await fs.mkdir(path.dirname(AUTH_DB_PATH), { recursive: true });
if (!AUTH_SECRET) {
  console.error("[uihub] BETTER_AUTH_SECRET is required");
  process.exit(1);
}

const db = AUTH_DATABASE_URL
  ? new Pool({ connectionString: AUTH_DATABASE_URL })
  : new DatabaseSync(AUTH_DB_PATH);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const isRetryableAuthDbError = (error) => {
  if (!AUTH_USE_POSTGRES) return false;
  const code = String(error?.code || "").toUpperCase();
  if (["57P03", "ECONNREFUSED", "EHOSTUNREACH", "ETIMEDOUT"].includes(code)) {
    return true;
  }
  const message = String(error?.message || "").toLowerCase();
  return (
    message.includes("database system is starting up") ||
    message.includes("database system is not yet accepting connections")
  );
};

const runAuthMigrations = async (authOptions) => {
  const { toBeCreated, toBeAdded, runMigrations } = await getMigrations(authOptions);
  if ((toBeCreated?.length || 0) + (toBeAdded?.length || 0) > 0) {
    await runMigrations();
  }
};

const runAuthMigrationsWithRetry = async (authOptions) => {
  for (let attempt = 1; attempt <= AUTH_DB_BOOTSTRAP_RETRIES; attempt += 1) {
    try {
      await runAuthMigrations(authOptions);
      return;
    } catch (error) {
      const retryable = isRetryableAuthDbError(error);
      const lastAttempt = attempt === AUTH_DB_BOOTSTRAP_RETRIES;
      if (!retryable || lastAttempt) {
        throw error;
      }
      console.warn(
        `[uihub] auth db not ready (attempt ${attempt}/${AUTH_DB_BOOTSTRAP_RETRIES}), retry in ${AUTH_DB_BOOTSTRAP_DELAY_MS}ms`
      );
      await sleep(AUTH_DB_BOOTSTRAP_DELAY_MS);
    }
  }
};

const normalizeBaseUrl = (value) => {
  if (!value) return "";
  try {
    const parsed = new URL(value);
    if (parsed.pathname && parsed.pathname !== "/" && parsed.pathname !== "") {
      console.warn(
        `[uihub] BETTER_AUTH_URL contains a path (${parsed.pathname}); it will be ignored to avoid 404s.`
      );
    }
    return parsed.origin;
  } catch {
    return value;
  }
};

const AUTH_BASE_URL = normalizeBaseUrl(AUTH_BASE_URL_RAW);

const authConfig = {
  database: db,
  secret: AUTH_SECRET,
  baseURL: AUTH_BASE_URL,
  basePath: AUTH_BASE_PATH,
  trustedOrigins: TRUSTED_ORIGINS,
  emailAndPassword: { enabled: true }
};

const auth = betterAuth(authConfig);
await runAuthMigrationsWithRetry(auth.options);

const readFileToken = async (path) => {
  try {
    const value = await fs.readFile(path, "utf-8");
    return value.trim();
  } catch {
    return "";
  }
};

const writeFileToken = async (filePath, token) => {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, `${token}\n`, "utf-8");
};

const randomToken = () => crypto.randomBytes(32).toString("base64url");

const normalizeUserNamePart = (value) =>
  (value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^[-.]+|[-.]+$/g, "");

const buildSessionMcpUsername = (session) => {
  const email = (session?.user?.email || "").trim();
  const id = (session?.user?.id || "").trim();
  const seed = email || id;
  if (!seed) {
    throw new Error("session user identity is missing");
  }

  const local = email.includes("@") ? email.split("@")[0] : seed;
  const safeLocal = normalizeUserNamePart(local) || "user";
  const safePrefix = normalizeUserNamePart(MCP_UI_USER_PREFIX) || "ui";
  const hash = crypto.createHash("sha256").update(seed).digest("hex").slice(0, 10);

  // Keep username short and predictable while maintaining collision resistance via hash suffix.
  const base = `${safePrefix}-${safeLocal}`.slice(0, 48).replace(/[-.]+$/g, "");
  return `${base}-${hash}`;
};

const getSessionUserTokenPath = (username) => path.join(MCP_UI_USER_TOKEN_DIR, `${username}.token`);

const waitMcpReady = async () => {
  for (let i = 0; i < MCP_INIT_RETRIES; i += 1) {
    try {
      const resp = await fetch(`${MCP_BASE_URL}/health`, { signal: AbortSignal.timeout(MCP_TIMEOUT * 1000) });
      if (resp.ok) return;
    } catch {
      // ignore
    }
    await new Promise((resolve) => setTimeout(resolve, 2000));
  }
  throw new Error("mcpjungle not ready");
};

const mcpRequest = async (path, { method = "GET", token = "", body } = {}) => {
  const headers = { Accept: "application/json" };
  if (body) headers["Content-Type"] = "application/json";
  if (token) headers.Authorization = `Bearer ${token}`;
  const resp = await fetch(`${MCP_BASE_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(MCP_TIMEOUT * 1000)
  });
  const text = await resp.text();
  return { status: resp.status, text };
};

const marketRequestJson = async (url, { method = "GET", body } = {}) => {
  const headers = { Accept: "application/json" };
  if (body) {
    headers["Content-Type"] = "application/json";
  }
  const resp = await fetch(url, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(MCP_TIMEOUT * 1000)
  });
  const text = await resp.text();
  if (!resp.ok) {
    const err = new Error(`HTTP ${resp.status} ${text}`.trim());
    err.status = resp.status;
    throw err;
  }
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
};

const normalizeLocale = (raw) => {
  const value = String(raw || "").toLowerCase();
  if (value.startsWith("zh")) return "zh-CN";
  return "en-US";
};

const toPositiveInt = (raw, fallback) => {
  const value = Number.parseInt(String(raw || ""), 10);
  if (Number.isNaN(value) || value <= 0) return fallback;
  return value;
};

const normalizeOrder = (raw) => (String(raw || "desc").toLowerCase() === "asc" ? "asc" : "desc");

const normalizeText = (raw) => String(raw || "").trim().toLowerCase();

const ensureIsoTimestamp = (raw) => {
  if (!raw) return new Date().toISOString();
  const value = String(raw);
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return `${value}T00:00:00.000Z`;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return new Date().toISOString();
  return date.toISOString();
};

const semverToVersionNumber = (raw) => {
  const match = String(raw || "0.1.0").match(/^(\d+)\.(\d+)\.(\d+)/);
  if (!match) return 1;
  const major = Number.parseInt(match[1], 10);
  const minor = Number.parseInt(match[2], 10);
  const patch = Number.parseInt(match[3], 10);
  return major * 1000000 + minor * 1000 + patch;
};

const inferConnectionType = (item) => {
  const tags = Array.isArray(item?.meta?.tags) ? item.meta.tags.map((t) => String(t).toLowerCase()) : [];
  if (tags.includes("stdio")) return "stdio";
  if (tags.includes("sse")) return "sse";
  if (tags.includes("streamable_http") || tags.includes("http")) return "http";
  return "http";
};

const paginateItems = (items, page, pageSize) => {
  const totalCount = items.length;
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));
  const currentPage = Math.min(Math.max(page, 1), totalPages);
  const start = (currentPage - 1) * pageSize;
  const slice = items.slice(start, start + pageSize);
  return {
    items: slice,
    currentPage,
    pageSize,
    totalCount,
    totalPages
  };
};

const sortBy = (items, field, order) => {
  const factor = order === "asc" ? 1 : -1;
  return [...items].sort((a, b) => {
    const av = String(a?.[field] || "").toLowerCase();
    const bv = String(b?.[field] || "").toLowerCase();
    if (av < bv) return -1 * factor;
    if (av > bv) return 1 * factor;
    return 0;
  });
};

const buildCategoryCounts = (items) => {
  const counts = new Map();
  for (const item of items) {
    const category = String(item?.category || "").trim();
    if (!category) continue;
    counts.set(category, (counts.get(category) || 0) + 1);
  }
  return [...counts.entries()].map(([category, count]) => ({ category, count }));
};

const mapAgentItem = (item) => ({
  identifier: item.identifier,
  name: item.title || item.identifier,
  icon: item.avatar || "",
  title: item.title || item.identifier,
  description: item.description || "",
  summary: item.description || "",
  avatar: item.avatar || "",
  author: LOBE_MARKET_DEFAULT_AUTHOR,
  category: item.category || "general",
  tags: item.tags || [],
  createdAt: ensureIsoTimestamp(item.created_at || item.updated_at),
  updatedAt: ensureIsoTimestamp(item.updated_at || item.created_at),
  homepage: item.homepage || "",
  manifestUrl: `/lobe-market/api/v1/agents/detail/${encodeURIComponent(item.identifier || "")}`,
  schemaVersion: 1,
  visibility: "public",
  status: item.status || "published",
  installCount: 0,
  tokenUsage: 0,
  pluginCount: 0,
  knowledgeCount: 0
});

const fetchAllAgents = async () => {
  const pageSize = 200;
  let page = 1;
  let total = 0;
  const all = [];
  while (page <= 50) {
    const data = await marketRequestJson(
      `${AGENTHUB_INTERNAL_URL}/agents?page=${page}&page_size=${pageSize}`
    );
    const items = Array.isArray(data?.items) ? data.items : [];
    total = Number(data?.total || items.length || 0);
    all.push(...items);
    if (all.length >= total || items.length === 0) break;
    page += 1;
  }
  return all;
};

const fetchPluginsIndex = async (locale) => {
  const lang = normalizeLocale(locale);
  try {
    const data = await marketRequestJson(`${AGENTHUB_INTERNAL_URL}/plugins-index/index.${lang}.json`);
    if (Array.isArray(data?.plugins)) return data;
  } catch {
    // fallback
  }
  return marketRequestJson(`${AGENTHUB_INTERNAL_URL}/plugins-index/index.en-US.json`);
};

const mapPluginItem = (item) => {
  const meta = item?.meta || {};
  const icon = meta?.avatar || "plugin";
  const manifestUrl = item?.manifest || `/plugins-index/manifests/${encodeURIComponent(item?.identifier || "")}.json`;
  const connectionType = inferConnectionType(item);
  const toolsCount = Number(item?.toolsCount || 0);
  const promptsCount = Number(item?.promptsCount || 0);
  const resourcesCount = Number(item?.resourcesCount || 0);
  return {
    id: item?.id || item?.identifier || "",
    identifier: item?.identifier || "",
    title: meta?.title || item?.identifier || "",
    name: meta?.title || item?.identifier || "",
    description: meta?.description || "",
    summary: meta?.description || "",
    icon,
    avatar: icon,
    author: item?.author || LOBE_MARKET_DEFAULT_AUTHOR,
    category: meta?.category || "tools",
    tags: meta?.tags || [],
    homepage: item?.homepage || "",
    manifestUrl,
    manifest: item?.manifest || "",
    createdAt: ensureIsoTimestamp(item?.createdAt),
    updatedAt: ensureIsoTimestamp(item?.updatedAt || item?.createdAt),
    capabilities: {
      prompts: promptsCount > 0,
      resources: resourcesCount > 0,
      tools: toolsCount > 0
    },
    connectionType,
    installationMethods: connectionType,
    promptsCount,
    resourcesCount,
    toolsCount,
    schemaVersion: item?.schemaVersion || 1,
    type: "mcp",
    installType: "mcp",
    pluginType: "mcp",
    installCount: Number(item?.installCount || 0),
    likeCount: Number(item?.likeCount || 0),
    visibility: "public",
    status: "published"
  };
};

const fetchAllSkills = async () => {
  const pageSize = 200;
  let page = 1;
  let total = 0;
  const all = [];
  while (page <= 50) {
    const data = await marketRequestJson(
      `${SKILLHUB_INTERNAL_URL}/skills?page=${page}&page_size=${pageSize}`
    );
    const items = Array.isArray(data?.items) ? data.items : [];
    total = Number(data?.total || items.length || 0);
    all.push(...items);
    if (all.length >= total || items.length === 0) break;
    page += 1;
  }
  return all;
};

const mapSkillItem = (item) => ({
  identifier: item?.name || "",
  name: item?.name || "",
  title: item?.name || "",
  icon: "skill",
  description: item?.description || "",
  summary: item?.description || "",
  category: item?.type || "custom",
  tags: [],
  author: LOBE_MARKET_DEFAULT_AUTHOR,
  stars: 0,
  downloads: 0,
  commentCount: 0,
  installCount: 0,
  isFeatured: false,
  isOfficial: false,
  isValidated: String(item?.validation_status || "").toLowerCase() === "validated",
  ratingCount: 0,
  resourcesCount: Number(item?.resources_count || 0),
  createdAt: ensureIsoTimestamp(item?.created_at || item?.updated_at),
  updatedAt: ensureIsoTimestamp(item?.updated_at || item?.created_at),
  version: item?.latest_version || "0.1.0",
  status: item?.status || "published",
  visibility: "public"
});

const mapPromptItem = (pluginItem, prompt, index) => {
  const promptName = String(prompt?.name || `prompt-${index + 1}`);
  const identifier = `${pluginItem.identifier}::${promptName}`;
  const promptArguments = Array.isArray(prompt?.arguments) ? prompt.arguments : [];
  const promptDescription = String(prompt?.description || pluginItem.description || "");
  return {
    id: identifier,
    identifier,
    name: promptName,
    title: promptName,
    description: promptDescription,
    summary: promptDescription,
    category: pluginItem.category || "general",
    tags: [...new Set([...(pluginItem.tags || []), "prompt"])],
    sourceIdentifier: pluginItem.identifier,
    sourceName: pluginItem.title || pluginItem.identifier,
    sourceType: "mcp",
    arguments: promptArguments,
    argumentsCount: promptArguments.length,
    manifestUrl: pluginItem.manifestUrl,
    updatedAt: ensureIsoTimestamp(pluginItem.updatedAt),
    createdAt: ensureIsoTimestamp(pluginItem.createdAt),
    status: "published",
    visibility: "public"
  };
};

const fetchAllPrompts = async (locale) => {
  const raw = await fetchPluginsIndex(locale);
  const plugins = (raw?.plugins || []).map(mapPluginItem).filter((item) => Boolean(item.identifier));
  const manifestResults = await Promise.allSettled(
    plugins.map(async (pluginItem) => {
      const manifest = await marketRequestJson(
        `${AGENTHUB_INTERNAL_URL}/plugins-index/manifests/${encodeURIComponent(pluginItem.identifier)}.json`
      );
      const prompts = Array.isArray(manifest?.prompts) ? manifest.prompts : [];
      return prompts.map((prompt, index) => mapPromptItem(pluginItem, prompt, index));
    })
  );

  const merged = [];
  for (const result of manifestResults) {
    if (result.status === "fulfilled") {
      merged.push(...result.value);
    }
  }
  return merged;
};

const safeResolveStaticFile = (reqPath) => {
  const safePath = String(reqPath || "").replace(/^\/+/, "");
  const resolved = path.resolve(CLIENT_DIST_DIR, safePath);
  const baseResolved = path.resolve(CLIENT_DIST_DIR);
  if (!resolved.startsWith(baseResolved)) return "";
  return resolved;
};

const readStaticFile = async (reqPath) => {
  const resolved = safeResolveStaticFile(reqPath);
  if (!resolved) return null;
  try {
    const content = await fs.readFile(resolved);
    const ext = path.extname(resolved).toLowerCase();
    const type = STATIC_CONTENT_TYPES[ext] || "application/octet-stream";
    return { content, type };
  } catch {
    return null;
  }
};

const ensureAdminUser = async () => {
  if (!ADMIN_EMAIL || !ADMIN_PASSWORD) return;
  try {
    await auth.api.signUpEmail({
      body: { email: ADMIN_EMAIL, password: ADMIN_PASSWORD, name: ADMIN_NAME }
    });
  } catch (error) {
    const message = error?.message || "";
    if (!message.toLowerCase().includes("exists")) {
      console.warn("[uihub] failed to seed admin user:", message);
    }
  }
};

const ensureAdminToken = async () => {
  if (MCP_SERVER_MODE === "development") return "";
  const existing = (await readFileToken(MCP_ADMIN_TOKEN_PATH)) || MCP_ADMIN_TOKEN_ENV;
  if (existing) return existing;

  await waitMcpReady();
  const { status, text } = await mcpRequest("/init", { method: "POST", body: { mode: MCP_INIT_MODE } });
  if (status === 400 && text.includes("already initialized")) {
    throw new Error("mcpjungle already initialized but admin token missing");
  }
  if (status < 200 || status >= 300) {
    throw new Error(`init failed: HTTP ${status} ${text}`);
  }
  let payload = {};
  try {
    payload = JSON.parse(text);
  } catch {
    payload = {};
  }
  const adminToken = payload.admin_access_token || "";
  if (!adminToken) {
    throw new Error("init ok but admin token missing");
  }
  await writeFileToken(MCP_ADMIN_TOKEN_PATH, adminToken);
  return adminToken;
};

const ensureServicePrincipalToken = async () => {
  if (MCP_SERVER_MODE === "development") return "";
  const existing = await readFileToken(MCP_SERVICE_PRINCIPAL_TOKEN_PATH);
  if (existing) return existing;
  const adminToken = await ensureAdminToken();
  if (!adminToken) return "";

  const usersResp = await mcpRequest("/api/v0/users", { token: adminToken });
  if (usersResp.status !== 200) {
    throw new Error(`list users failed: HTTP ${usersResp.status} ${usersResp.text}`);
  }
  let users = [];
  try {
    users = JSON.parse(usersResp.text) || [];
  } catch {
    users = [];
  }
  const exists = users.some((user) => user?.username === MCP_SERVICE_PRINCIPAL_NAME);
  if (exists) {
    const token = randomToken();
    const updateResp = await mcpRequest(`/api/v0/users/${encodeURIComponent(MCP_SERVICE_PRINCIPAL_NAME)}`, {
      method: "PUT",
      token: adminToken,
      body: { username: MCP_SERVICE_PRINCIPAL_NAME, access_token: token }
    });
    if (updateResp.status !== 200) {
      throw new Error(`update user failed: HTTP ${updateResp.status} ${updateResp.text}`);
    }
    await writeFileToken(MCP_SERVICE_PRINCIPAL_TOKEN_PATH, token);
    return token;
  }

  const createResp = await mcpRequest("/api/v0/users", {
    method: "POST",
    token: adminToken,
    body: { username: MCP_SERVICE_PRINCIPAL_NAME }
  });
  if (createResp.status !== 201 && createResp.status !== 200) {
    throw new Error(`create user failed: HTTP ${createResp.status} ${createResp.text}`);
  }
  let payload = {};
  try {
    payload = JSON.parse(createResp.text);
  } catch {
    payload = {};
  }
  const token = payload.access_token || "";
  if (!token) throw new Error("user token missing in response");
  await writeFileToken(MCP_SERVICE_PRINCIPAL_TOKEN_PATH, token);
  return token;
};

const ensureSessionUserToken = async (session) => {
  if (MCP_SERVER_MODE === "development") return "";

  const username = buildSessionMcpUsername(session);
  const tokenPath = getSessionUserTokenPath(username);
  const existing = await readFileToken(tokenPath);
  if (existing) {
    return existing;
  }

  const adminToken = await ensureAdminToken();
  if (!adminToken) {
    throw new Error("admin token unavailable");
  }

  const usersResp = await mcpRequest("/api/v0/users", { token: adminToken });
  if (usersResp.status !== 200) {
    throw new Error(`list users failed: HTTP ${usersResp.status} ${usersResp.text}`);
  }

  let users = [];
  try {
    users = JSON.parse(usersResp.text) || [];
  } catch {
    users = [];
  }

  const desiredToken = randomToken();
  const exists = users.some((user) => user?.username === username);
  if (exists) {
    const updateResp = await mcpRequest(`/api/v0/users/${encodeURIComponent(username)}`, {
      method: "PUT",
      token: adminToken,
      body: { username, access_token: desiredToken }
    });
    if (updateResp.status !== 200) {
      throw new Error(`update user failed: HTTP ${updateResp.status} ${updateResp.text}`);
    }
    await writeFileToken(tokenPath, desiredToken);
    return desiredToken;
  }

  const createResp = await mcpRequest("/api/v0/users", {
    method: "POST",
    token: adminToken,
    body: { username, access_token: desiredToken }
  });
  if (createResp.status !== 201 && createResp.status !== 200) {
    throw new Error(`create user failed: HTTP ${createResp.status} ${createResp.text}`);
  }
  await writeFileToken(tokenPath, desiredToken);
  return desiredToken;
};

await ensureAdminUser();

const app = new Hono();

app.use(
  "*",
  cors({
    origin: (origin) => {
      if (!origin) return "*";
      if (TRUSTED_ORIGINS.length === 0) return origin;
      return TRUSTED_ORIGINS.includes(origin) ? origin : "";
    },
    credentials: true
  })
);

app.all(`${AUTH_BASE_PATH}/*`, (c) => auth.handler(c.req.raw));

const requireAuth = async (c, next) => {
  const session = await auth.api.getSession({ headers: c.req.raw.headers });
  if (!session) return c.json({ error: "unauthorized" }, 401);
  c.set("session", session);
  await next();
};

app.get("/session", async (c) => {
  const session = await auth.api.getSession({ headers: c.req.raw.headers });
  if (!session) return c.json({ error: "unauthorized" }, 401);
  return c.json(session);
});

app.get("/mcp/status", requireAuth, async (c) => {
  const session = c.get("session");
  const mappedUsername = (() => {
    try {
      return buildSessionMcpUsername(session);
    } catch {
      return "";
    }
  })();
  const mappedTokenPath = mappedUsername ? getSessionUserTokenPath(mappedUsername) : "";
  const mappedToken = mappedTokenPath ? await readFileToken(mappedTokenPath) : "";
  const adminToken = (await readFileToken(MCP_ADMIN_TOKEN_PATH)) || MCP_ADMIN_TOKEN_ENV;
  const servicePrincipalToken = await readFileToken(MCP_SERVICE_PRINCIPAL_TOKEN_PATH);
  return c.json({
    server_mode: MCP_SERVER_MODE,
    admin_token_present: Boolean(adminToken),
    service_principal_name: MCP_SERVICE_PRINCIPAL_NAME,
    service_principal_token_present: Boolean(servicePrincipalToken),
    session_user_mcp_username: mappedUsername || null,
    session_user_token_present: Boolean(mappedToken)
  });
});

const toMcpErrorResponse = (error, fallback) => {
  const message = error?.message || fallback;
  if (message.includes("admin token missing")) {
    return {
      status: 409,
      body: {
        error:
          "MCPJungle 已初始化但 admin token 缺失。请临时设置 MCPJUNGLE_ADMIN_TOKEN 或恢复 /data/mcpjungle/admin.token。"
      }
    };
  }
  if (message.includes("HTTP 401")) {
    return {
      status: 502,
      body: { error: "MCPJungle 鉴权失败，请检查 admin token 是否有效。" }
    };
  }
  return { status: 500, body: { error: message || fallback } };
};

const normalizeEmail = (value) => (value || "").trim().toLowerCase();

const isAdminSession = (session) => {
  const email = normalizeEmail(session?.user?.email);
  if (!email) return false;
  return ADMIN_EMAILS.map(normalizeEmail).includes(email);
};

const isAdminMcpOperation = (pathname, method) => {
  if (pathname === "/init") return true;
  if (pathname === "/api/v0/server_configs") return true;
  if (pathname.startsWith("/api/v0/clients")) return true;
  if (pathname.startsWith("/api/v0/users") && pathname !== "/api/v0/users/whoami") return true;
  if (pathname.startsWith("/api/v0/tool-groups")) return true;
  if (pathname === "/api/v0/tools/enable" || pathname === "/api/v0/tools/disable") return true;
  if (pathname === "/api/v0/prompts/enable" || pathname === "/api/v0/prompts/disable") return true;
  if (pathname.startsWith("/api/v0/servers") && method !== "GET") return true;
  return false;
};

app.all("/mcpjungle/*", requireAuth, async (c) => {
  try {
    const session = c.get("session");
    const sessionEmail = normalizeEmail(session?.user?.email) || "unknown";
    const isAdmin = isAdminSession(session);
    const url = new URL(c.req.url);
    const method = c.req.method;
    const rawPath = c.req.path || "/";
    const proxiedPath = rawPath.startsWith("/mcpjungle") ? rawPath.slice("/mcpjungle".length) : rawPath;
    const pathname = (proxiedPath || "/").replace(/\/+/g, "/");

    if (pathname === "/mcp" || pathname.startsWith("/mcp/") || pathname === "/sse" || pathname === "/message") {
      return c.json({ error: "MCP transport endpoints are not exposed via ui-api proxy" }, 403);
    }

    const adminOperation = isAdminMcpOperation(pathname, method);
    if (adminOperation && !isAdmin) {
      return c.json({ error: "forbidden: admin operation" }, 403);
    }

    let token = "";
    let upstreamIdentity = "anonymous";
    if (MCP_SERVER_MODE !== "development") {
      if (adminOperation || isAdmin) {
        token = await ensureAdminToken();
        upstreamIdentity = "admin";
      } else {
        token = await ensureSessionUserToken(session);
        upstreamIdentity = "session-user";
      }
      if (!token) {
        return c.json({ error: "mcp token unavailable" }, 503);
      }
    }

    const headers = { Accept: c.req.header("accept") || "application/json" };
    const contentType = c.req.header("content-type");
    if (contentType) {
      headers["Content-Type"] = contentType;
    }
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    const bodyAllowed = method !== "GET" && method !== "HEAD";
    const rawBody = bodyAllowed ? await c.req.raw.text() : "";

    const upstream = await fetch(`${MCP_BASE_URL}${pathname}${url.search}`, {
      method,
      headers,
      body: bodyAllowed && rawBody ? rawBody : undefined,
      signal: AbortSignal.timeout(MCP_TIMEOUT * 1000)
    });

    console.info(
      `[uihub:mcp-proxy] user=${sessionEmail} role=${isAdmin ? "admin" : "user"} identity=${upstreamIdentity} ` +
        `method=${method} path=${pathname} status=${upstream.status}`
    );

    const upstreamBody = await upstream.arrayBuffer();
    const responseHeaders = new Headers();
    const upstreamContentType = upstream.headers.get("content-type");
    if (upstreamContentType) {
      responseHeaders.set("content-type", upstreamContentType);
    }

    return new Response(upstreamBody, {
      status: upstream.status,
      headers: responseHeaders
    });
  } catch (error) {
    const { status, body } = toMcpErrorResponse(error, "mcp proxy failed");
    return c.json(body, status);
  }
});

app.post("/mcp/bootstrap", requireAuth, async (c) => {
  try {
    const session = c.get("session");
    const token = await ensureSessionUserToken(session);
    return c.json({ access_token: token });
  } catch (error) {
    const { status, body } = toMcpErrorResponse(error, "bootstrap failed");
    return c.json(body, status);
  }
});

app.get("/mcp/token", requireAuth, async (c) => {
  try {
    const session = c.get("session");
    const token = await ensureSessionUserToken(session);
    if (!token && MCP_SERVER_MODE !== "development") {
      return c.json({ error: "token unavailable" }, 503);
    }
    return c.json({ access_token: token });
  } catch (error) {
    const { status, body } = toMcpErrorResponse(error, "token unavailable");
    return c.json(body, status);
  }
});

// Some clients build market URLs with absolute paths and may drop the /lobe-market prefix.
// Provide root aliases so both path styles resolve to the same handlers.
app.use("/api/v1/*", async (c) => {
  const url = new URL(c.req.url);
  url.pathname = url.pathname.replace("/api/v1/", "/lobe-market/v1/");
  const rewrittenReq = new Request(url.toString(), c.req.raw);
  return app.fetch(rewrittenReq);
});

app.use("/v1/*", async (c) => {
  const url = new URL(c.req.url);
  url.pathname = url.pathname.replace("/v1/", "/lobe-market/v1/");
  const rewrittenReq = new Request(url.toString(), c.req.raw);
  return app.fetch(rewrittenReq);
});

app.get("/lobehub-oidc/userinfo", async (c) => {
  return c.json({ accountId: 1, sub: "assethub-market-user" });
});

// LobeHub Market SDK (some versions) requests /api/v1/* while others use /v1/*.
// Keep both working by rewriting /lobe-market/api/... to /lobe-market/...
app.use("/lobe-market/api/*", async (c) => {
  const url = new URL(c.req.url);
  url.pathname = url.pathname.replace("/lobe-market/api/", "/lobe-market/");
  const rewrittenReq = new Request(url.toString(), c.req.raw);
  return app.fetch(rewrittenReq);
});

app.get("/lobe-market/lobehub-oidc/userinfo", async (c) => {
  return c.json({ accountId: 1, sub: "assethub-market-user" });
});

app.get("/lobe-market/v1/agents", async (c) => {
  try {
    const q = normalizeText(c.req.query("q"));
    const category = normalizeText(c.req.query("category"));
    const page = toPositiveInt(c.req.query("page"), 1);
    const pageSize = Math.min(toPositiveInt(c.req.query("pageSize"), 20), 100);
    const sort = String(c.req.query("sort") || "updatedAt");
    const order = normalizeOrder(c.req.query("order"));

    let items = (await fetchAllAgents()).map(mapAgentItem);
    items = items.filter((item) => String(item.visibility || "public") === "public");
    if (category) {
      items = items.filter((item) => normalizeText(item.category) === category);
    }
    if (q) {
      items = items.filter((item) =>
        [item.identifier, item.title, item.description, item.author, ...(item.tags || [])]
          .join(",")
          .toLowerCase()
          .includes(q)
      );
    }

    const sortField = sort === "name" ? "title" : sort === "createdAt" ? "createdAt" : "updatedAt";
    const sorted = sortBy(items, sortField, order);
    return c.json(paginateItems(sorted, page, pageSize));
  } catch (error) {
    return c.json({ error: error?.message || "failed to list agents" }, 500);
  }
});

app.get("/lobe-market/v1/agents/categories", async (c) => {
  try {
    const q = normalizeText(c.req.query("q"));
    let items = (await fetchAllAgents()).map(mapAgentItem);
    if (q) {
      items = items.filter((item) =>
        [item.identifier, item.title, item.description, item.author, ...(item.tags || [])]
          .join(",")
          .toLowerCase()
          .includes(q)
      );
    }
    return c.json(buildCategoryCounts(items));
  } catch (error) {
    return c.json({ error: error?.message || "failed to list categories" }, 500);
  }
});

app.get("/lobe-market/v1/agents/identifiers", async (c) => {
  try {
    const items = (await fetchAllAgents()).map(mapAgentItem);
    return c.json(items.map((item) => ({ id: item.identifier, lastModified: item.updatedAt })));
  } catch (error) {
    return c.json({ error: error?.message || "failed to list identifiers" }, 500);
  }
});

app.get("/lobe-market/v1/agents/detail/:identifier", async (c) => {
  const identifier = c.req.param("identifier");
  const locale = normalizeLocale(c.req.query("locale"));
  try {
    const detail = await marketRequestJson(`${AGENTHUB_INTERNAL_URL}/agents/${encodeURIComponent(identifier)}`);
    const fallback = mapAgentItem({
      identifier,
      title: detail?.title,
      description: detail?.description,
      avatar: detail?.avatar,
      category: detail?.category,
      tags: detail?.tags,
      updated_at: detail?.updated_at,
      status: detail?.status
    });

    let localized = null;
    try {
      localized = await marketRequestJson(
        `${AGENTHUB_INTERNAL_URL}/agents-index/agent-${encodeURIComponent(identifier)}.${locale}.json`
      );
    } catch {
      localized = await marketRequestJson(
        `${AGENTHUB_INTERNAL_URL}/agents-index/agent-${encodeURIComponent(identifier)}.json`
      );
    }

    const payloadMeta = localized?.meta || {};
    const payloadConfig = localized?.config || {};
    const versions = Array.isArray(detail?.versions)
      ? detail.versions.map((v) => ({
          version: v.version,
          createdAt: v.created_at || v.updated_at || fallback.updatedAt,
          updatedAt: v.updated_at || v.created_at || fallback.updatedAt,
          isLatest: v.version === detail?.latest_version,
          status: detail?.status || "published"
        }))
      : [];

    return c.json({
      identifier,
      name: payloadMeta.title || fallback.title,
      title: payloadMeta.title || fallback.title,
      summary: payloadMeta.description || fallback.description,
      description: payloadMeta.description || fallback.description,
      avatar: payloadMeta.avatar || fallback.avatar,
      category: payloadMeta.category || fallback.category,
      tags: payloadMeta.tags || fallback.tags,
      author: fallback.author,
      ownerId: null,
      config: payloadConfig,
      version: detail?.published_version || detail?.latest_version || "0.1.0",
      versions,
      tokenUsage: 0,
      homepage: localized?.homepage || "",
      status: detail?.status || "published",
      createdAt: detail?.created_at || fallback.createdAt,
      updatedAt: detail?.updated_at || fallback.updatedAt
    });
  } catch (error) {
    const status = error?.status === 404 ? 404 : 500;
    return c.json({ error: error?.message || "failed to get agent detail" }, status);
  }
});

app.get("/lobe-market/v1/plugins", async (c) => {
  try {
    const q = normalizeText(c.req.query("q"));
    const category = normalizeText(c.req.query("category"));
    const page = toPositiveInt(c.req.query("page"), 1);
    const pageSize = Math.min(toPositiveInt(c.req.query("pageSize"), 20), 100);
    const sort = String(c.req.query("sort") || "createdAt");
    const order = normalizeOrder(c.req.query("order"));
    const locale = normalizeLocale(c.req.query("locale"));

    const raw = await fetchPluginsIndex(locale);
    let items = (raw?.plugins || []).map(mapPluginItem);
    if (category) {
      items = items.filter((item) => normalizeText(item.category) === category);
    }
    if (q) {
      items = items.filter((item) =>
        [item.identifier, item.title, item.description, item.author, ...(item.tags || [])]
          .join(",")
          .toLowerCase()
          .includes(q)
      );
    }
    const sortField = sort === "name" ? "title" : "createdAt";
    const sorted = sortBy(items, sortField, order);
    const paged = paginateItems(sorted, page, pageSize);
    return c.json({
      ...paged,
      categories: [...new Set(items.map((item) => item.category).filter(Boolean))]
    });
  } catch (error) {
    return c.json({ error: error?.message || "failed to list plugins" }, 500);
  }
});

app.get("/lobe-market/v1/plugins/categories", async (c) => {
  try {
    const q = normalizeText(c.req.query("q"));
    const locale = normalizeLocale(c.req.query("locale"));
    const raw = await fetchPluginsIndex(locale);
    let items = (raw?.plugins || []).map(mapPluginItem);
    if (q) {
      items = items.filter((item) =>
        [item.identifier, item.title, item.description, item.author, ...(item.tags || [])]
          .join(",")
          .toLowerCase()
          .includes(q)
      );
    }
    return c.json(buildCategoryCounts(items));
  } catch (error) {
    return c.json({ error: error?.message || "failed to list categories" }, 500);
  }
});

app.get("/lobe-market/v1/plugins/identifiers", async (c) => {
  try {
    const locale = normalizeLocale(c.req.query("locale"));
    const raw = await fetchPluginsIndex(locale);
    const items = (raw?.plugins || []).map(mapPluginItem);
    return c.json(items.map((item) => ({ id: item.identifier, lastModified: item.createdAt })));
  } catch (error) {
    return c.json({ error: error?.message || "failed to list identifiers" }, 500);
  }
});

app.get("/lobe-market/v1/plugins/:identifier/manifest", async (c) => {
  const identifier = c.req.param("identifier");
  try {
    const manifest = await marketRequestJson(
      `${AGENTHUB_INTERNAL_URL}/plugins-index/manifests/${encodeURIComponent(identifier)}.json`
    );
    return c.json(manifest || {});
  } catch (error) {
    const status = error?.status === 404 ? 404 : 500;
    return c.json({ error: error?.message || "failed to get plugin manifest" }, status);
  }
});

app.get("/lobe-market/v1/plugins/:identifier", async (c) => {
  const identifier = c.req.param("identifier");
  const locale = normalizeLocale(c.req.query("locale"));
  const requestedVersion = c.req.query("version") || "";
  try {
    const raw = await fetchPluginsIndex(locale);
    const item = (raw?.plugins || []).map(mapPluginItem).find((p) => p.identifier === identifier);
    if (!item) {
      return c.json({ error: "plugin not found" }, 404);
    }
    let manifest = {};
    try {
      manifest = await marketRequestJson(
        `${AGENTHUB_INTERNAL_URL}/plugins-index/manifests/${encodeURIComponent(identifier)}.json`
      );
    } catch {
      manifest = {};
    }

    const version = String(requestedVersion || manifest?.version || "0.1.0");
    const nowIso = ensureIsoTimestamp(item.updatedAt);
    return c.json({
      ...item,
      author: {
        name: item.author || LOBE_MARKET_DEFAULT_AUTHOR,
        url: item.homepage || undefined
      },
      version,
      versions: [
        {
          version,
          createdAt: ensureIsoTimestamp(item.createdAt),
          isLatest: true
        }
      ],
      overview: {
        summary: item.summary || item.description || "",
        readme: manifest?.description || item.description || ""
      },
      prompts: Array.isArray(manifest?.prompts) ? manifest.prompts : [],
      resources: Array.isArray(manifest?.resources) ? manifest.resources : [],
      tools: Array.isArray(manifest?.tools) ? manifest.tools : [],
      validatedAt: nowIso,
      isValidated: true,
      isClaimed: true,
      isOfficial: false,
      isFeatured: false,
      ratingAverage: 0,
      ratingCount: Number(item.ratingCount || 0),
      commentCount: Number(item.commentCount || 0)
    });
  } catch (error) {
    return c.json({ error: error?.message || "failed to get plugin detail" }, 500);
  }
});

app.get("/lobe-market/v1/mcp", async (c) => {
  const url = new URL(c.req.url);
  url.pathname = "/lobe-market/v1/plugins";
  const req = new Request(url.toString(), c.req.raw);
  return app.fetch(req);
});

app.get("/lobe-market/v1/mcp/categories", async (c) => {
  const url = new URL(c.req.url);
  url.pathname = "/lobe-market/v1/plugins/categories";
  const req = new Request(url.toString(), c.req.raw);
  return app.fetch(req);
});

app.get("/lobe-market/v1/mcp/identifiers", async (c) => {
  const url = new URL(c.req.url);
  url.pathname = "/lobe-market/v1/plugins/identifiers";
  const req = new Request(url.toString(), c.req.raw);
  return app.fetch(req);
});

app.get("/lobe-market/v1/mcp/:identifier", async (c) => {
  const identifier = encodeURIComponent(c.req.param("identifier"));
  const url = new URL(c.req.url);
  url.pathname = `/lobe-market/v1/plugins/${identifier}`;
  const req = new Request(url.toString(), c.req.raw);
  return app.fetch(req);
});

app.get("/lobe-market/v1/mcp/:identifier/manifest", async (c) => {
  const identifier = encodeURIComponent(c.req.param("identifier"));
  const url = new URL(c.req.url);
  url.pathname = `/lobe-market/v1/plugins/${identifier}/manifest`;
  const req = new Request(url.toString(), c.req.raw);
  return app.fetch(req);
});

app.get("/lobe-market/v1/mcps", async (c) => {
  const url = new URL(c.req.url);
  url.pathname = "/lobe-market/v1/plugins";
  const req = new Request(url.toString(), c.req.raw);
  return app.fetch(req);
});

app.get("/lobe-market/v1/mcps/categories", async (c) => {
  const url = new URL(c.req.url);
  url.pathname = "/lobe-market/v1/plugins/categories";
  const req = new Request(url.toString(), c.req.raw);
  return app.fetch(req);
});

app.get("/lobe-market/v1/mcps/identifiers", async (c) => {
  const url = new URL(c.req.url);
  url.pathname = "/lobe-market/v1/plugins/identifiers";
  const req = new Request(url.toString(), c.req.raw);
  return app.fetch(req);
});

app.get("/lobe-market/v1/mcps/:identifier", async (c) => {
  const identifier = encodeURIComponent(c.req.param("identifier"));
  const url = new URL(c.req.url);
  url.pathname = `/lobe-market/v1/plugins/${identifier}`;
  const req = new Request(url.toString(), c.req.raw);
  return app.fetch(req);
});

app.get("/lobe-market/v1/mcps/:identifier/manifest", async (c) => {
  const identifier = encodeURIComponent(c.req.param("identifier"));
  const url = new URL(c.req.url);
  url.pathname = `/lobe-market/v1/plugins/${identifier}/manifest`;
  const req = new Request(url.toString(), c.req.raw);
  return app.fetch(req);
});

app.get("/lobe-market/v1/skills", async (c) => {
  try {
    const q = normalizeText(c.req.query("q"));
    const category = normalizeText(c.req.query("category"));
    const page = toPositiveInt(c.req.query("page"), 1);
    const pageSize = Math.min(toPositiveInt(c.req.query("pageSize"), 20), 100);
    const sort = String(c.req.query("sort") || "updatedAt");
    const order = normalizeOrder(c.req.query("order"));

    let items = (await fetchAllSkills()).map(mapSkillItem);
    if (category) {
      items = items.filter((item) => normalizeText(item.category) === category);
    }
    if (q) {
      items = items.filter((item) =>
        [item.identifier, item.title, item.description, item.author, ...(item.tags || [])]
          .join(",")
          .toLowerCase()
          .includes(q)
      );
    }
    const sortField = sort === "name" ? "title" : sort === "createdAt" ? "createdAt" : "updatedAt";
    const sorted = sortBy(items, sortField, order);
    return c.json(paginateItems(sorted, page, pageSize));
  } catch (error) {
    return c.json({ error: error?.message || "failed to list skills" }, 500);
  }
});

app.get("/lobe-market/v1/skills/categories", async (c) => {
  try {
    const q = normalizeText(c.req.query("q"));
    let items = (await fetchAllSkills()).map(mapSkillItem);
    if (q) {
      items = items.filter((item) =>
        [item.identifier, item.title, item.description, item.author, ...(item.tags || [])]
          .join(",")
          .toLowerCase()
          .includes(q)
      );
    }
    return c.json(buildCategoryCounts(items));
  } catch (error) {
    return c.json({ error: error?.message || "failed to list skill categories" }, 500);
  }
});

app.get("/lobe-market/v1/skills/identifiers", async (c) => {
  try {
    const items = (await fetchAllSkills()).map(mapSkillItem);
    return c.json(items.map((item) => ({ id: item.identifier, lastModified: item.updatedAt })));
  } catch (error) {
    return c.json({ error: error?.message || "failed to list identifiers" }, 500);
  }
});

app.get("/lobe-market/v1/skills/:identifier", async (c) => {
  const identifier = c.req.param("identifier");
  try {
    const detail = await marketRequestJson(`${SKILLHUB_INTERNAL_URL}/skills/${encodeURIComponent(identifier)}`);
    const latestVersion = String(detail?.latest_version || "0.1.0");
    const versions = Array.isArray(detail?.versions)
      ? detail.versions.map((v) => ({
          version: v.version,
          createdAt: ensureIsoTimestamp(v.created_at || v.updated_at),
          updatedAt: ensureIsoTimestamp(v.updated_at || v.created_at),
          isLatest: v.version === detail?.latest_version,
          status: detail?.status || "published",
          isValidated: String(v.validation_status || "").toLowerCase() === "validated",
          versionNumber: semverToVersionNumber(v.version)
        }))
      : [];
    const latestVersionEntry = versions.find((v) => v.isLatest) || versions[0];
    const isValidated = Boolean(latestVersionEntry?.isValidated);

    const manifest = {
      name: detail?.name || identifier,
      description: detail?.description || "",
      category: detail?.type || "custom",
      tags: [],
      version: latestVersion
    };

    return c.json({
      identifier: detail?.name || identifier,
      name: detail?.name || identifier,
      title: detail?.name || identifier,
      icon: "skill",
      description: detail?.description || "",
      summary: detail?.description || "",
      category: detail?.type || "custom",
      author: { name: LOBE_MARKET_DEFAULT_AUTHOR },
      tags: [],
      version: latestVersion,
      versionNumber: semverToVersionNumber(latestVersion),
      versions,
      content: "",
      overview: { summary: detail?.description || "" },
      manifest,
      resources: {},
      repository: undefined,
      homepage: undefined,
      installCount: 0,
      ratingCount: 0,
      ratingAverage: 0,
      commentCount: 0,
      isFeatured: false,
      isOfficial: false,
      isValidated,
      createdAt: ensureIsoTimestamp(detail?.created_at || detail?.updated_at),
      updatedAt: ensureIsoTimestamp(detail?.updated_at || detail?.created_at),
      visibility: "public",
      status: detail?.status || "published"
    });
  } catch (error) {
    const status = error?.status === 404 ? 404 : 500;
    return c.json({ error: error?.message || "failed to get skill detail" }, status);
  }
});

app.get("/lobe-market/v1/prompts", async (c) => {
  try {
    const q = normalizeText(c.req.query("q"));
    const category = normalizeText(c.req.query("category"));
    const source = normalizeText(c.req.query("source"));
    const locale = normalizeLocale(c.req.query("locale"));
    const page = toPositiveInt(c.req.query("page"), 1);
    const pageSize = Math.min(toPositiveInt(c.req.query("pageSize"), 20), 100);
    const sort = String(c.req.query("sort") || "updatedAt");
    const order = normalizeOrder(c.req.query("order"));

    let items = await fetchAllPrompts(locale);
    if (category) {
      items = items.filter((item) => normalizeText(item.category) === category);
    }
    if (source) {
      items = items.filter((item) => normalizeText(item.sourceIdentifier) === source);
    }
    if (q) {
      items = items.filter((item) =>
        [item.identifier, item.title, item.description, item.sourceName, ...(item.tags || [])]
          .join(",")
          .toLowerCase()
          .includes(q)
      );
    }

    const sortField = sort === "name" ? "title" : sort === "createdAt" ? "createdAt" : "updatedAt";
    const sorted = sortBy(items, sortField, order);
    return c.json(paginateItems(sorted, page, pageSize));
  } catch (error) {
    return c.json({ error: error?.message || "failed to list prompts" }, 500);
  }
});

app.get("/lobe-market/v1/prompts/categories", async (c) => {
  try {
    const q = normalizeText(c.req.query("q"));
    const locale = normalizeLocale(c.req.query("locale"));
    let items = await fetchAllPrompts(locale);
    if (q) {
      items = items.filter((item) =>
        [item.identifier, item.title, item.description, item.sourceName, ...(item.tags || [])]
          .join(",")
          .toLowerCase()
          .includes(q)
      );
    }
    return c.json(buildCategoryCounts(items));
  } catch (error) {
    return c.json({ error: error?.message || "failed to list prompt categories" }, 500);
  }
});

app.get("/lobe-market/v1/prompts/identifiers", async (c) => {
  try {
    const locale = normalizeLocale(c.req.query("locale"));
    const items = await fetchAllPrompts(locale);
    return c.json(items.map((item) => ({ id: item.identifier, lastModified: item.updatedAt })));
  } catch (error) {
    return c.json({ error: error?.message || "failed to list prompt identifiers" }, 500);
  }
});

app.get("/lobe-market/v1/prompts/:identifier", async (c) => {
  const identifier = c.req.param("identifier");
  const locale = normalizeLocale(c.req.query("locale"));
  try {
    const items = await fetchAllPrompts(locale);
    const detail = items.find((item) => item.identifier === identifier);
    if (!detail) {
      return c.json({ error: "prompt not found" }, 404);
    }
    return c.json(detail);
  } catch (error) {
    return c.json({ error: error?.message || "failed to get prompt detail" }, 500);
  }
});

app.get("*", async (c, next) => {
  const reqPath = c.req.path || "/";
  if (
    reqPath.startsWith("/auth") ||
    reqPath.startsWith("/api/") ||
    reqPath.startsWith("/v1/") ||
    reqPath.startsWith("/lobe-market/") ||
    reqPath.startsWith("/mcp") ||
    reqPath.startsWith("/mcpjungle") ||
    reqPath === "/session"
  ) {
    return next();
  }

  const normalizedPath = reqPath === "/" ? "index.html" : reqPath.slice(1);
  const staticFile = await readStaticFile(normalizedPath);
  if (staticFile) {
    return new Response(staticFile.content, {
      status: 200,
      headers: { "Content-Type": staticFile.type }
    });
  }

  if (!path.extname(normalizedPath)) {
    const fallback = await readStaticFile("index.html");
    if (fallback) {
      return new Response(fallback.content, {
        status: 200,
        headers: { "Content-Type": fallback.type }
      });
    }
  }
  return c.json({ error: "not found" }, 404);
});

const autoBootstrapEnabled = process.env.UIHUB_AUTO_BOOTSTRAP === "1";
if (autoBootstrapEnabled) {
  ensureServicePrincipalToken()
    .then((token) => {
      if (token) {
        console.log("[uihub] MCPJungle service principal token bootstrap completed");
      } else {
        console.warn("[uihub] MCPJungle service principal token bootstrap skipped (empty token)");
      }
    })
    .catch((error) => {
      const message = error?.message || "bootstrap failed";
      console.warn(`[uihub] MCPJungle token bootstrap failed: ${message}`);
    });
}

const shouldListen = process.env.UIHUB_NO_LISTEN !== "1";
if (shouldListen) {
  serve({ fetch: app.fetch, port: PORT });
}

export { app };

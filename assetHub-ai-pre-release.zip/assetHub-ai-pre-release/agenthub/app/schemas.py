from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.models import AgentStatus


class AgentMetaInput(BaseModel):
    title: str
    description: str
    avatar: Optional[str] = None
    category: Optional[str] = None
    tags: List[str] = Field(default_factory=list)


class AgentConfigInput(BaseModel):
    system_role: str = Field(alias="systemRole")
    opening_message: Optional[str] = Field(default=None, alias="openingMessage")
    opening_questions: List[str] = Field(default_factory=list, alias="openingQuestions")
    params: Optional[Dict[str, Any]] = None
    plugins: List[str] = Field(default_factory=list)
    examples: Optional[List[Any]] = None

    model_config = ConfigDict(validate_by_name=True)


class AgentLocaleInput(BaseModel):
    meta: AgentMetaInput
    config: AgentConfigInput
    author: Optional[str] = ""
    homepage: Optional[str] = ""


class AgentCreateRequest(BaseModel):
    identifier: str
    version: str = "0.1.0"
    mcp_servers: List[str] = Field(default_factory=list)
    mcp_tools: List[str] = Field(default_factory=list)
    locales: Dict[str, AgentLocaleInput]

    @model_validator(mode="after")
    def _require_en_us(self):
        if "en-US" not in (self.locales or {}):
            raise ValueError("locales must include en-US")
        return self


class AgentUpdateVersionRequest(BaseModel):
    version: str
    mcp_servers: List[str] = Field(default_factory=list)
    mcp_tools: List[str] = Field(default_factory=list)
    locales: Dict[str, AgentLocaleInput]

    @model_validator(mode="after")
    def _require_en_us(self):
        if "en-US" not in (self.locales or {}):
            raise ValueError("locales must include en-US")
        return self


class AgentReviewRequest(BaseModel):
    note: Optional[str] = None


class AgentPublishRequest(BaseModel):
    version: Optional[str] = None


class AgentListItem(BaseModel):
    identifier: str
    title: str
    description: str
    status: AgentStatus
    latest_version: Optional[str] = None
    published_version: Optional[str] = None
    updated_at: datetime
    avatar: Optional[str] = None
    category: Optional[str] = None
    tags: List[str] = Field(default_factory=list)


class AgentListResponse(BaseModel):
    items: List[AgentListItem]
    total: int
    page: int
    page_size: int


class AgentVersionRead(BaseModel):
    version: str
    locales: List[str]
    mcp_servers: List[str] = Field(default_factory=list)
    mcp_tools: List[str] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime


class AgentDetail(BaseModel):
    identifier: str
    title: str
    description: str
    avatar: Optional[str]
    category: Optional[str]
    tags: List[str] = Field(default_factory=list)
    status: AgentStatus
    latest_version: Optional[str]
    published_version: Optional[str]
    review_note: Optional[str]
    reviewed_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime
    versions: List[AgentVersionRead]


class AgentCreateResponse(BaseModel):
    identifier: str
    version: str
    status: AgentStatus

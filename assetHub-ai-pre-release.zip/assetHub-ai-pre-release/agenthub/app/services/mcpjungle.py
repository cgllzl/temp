from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class McpJungleError(RuntimeError):
    pass


@dataclass(frozen=True)
class McpJungleClient:
    base_url: str
    access_token: str = ""
    timeout_seconds: float = 10.0

    def list_servers(self) -> List[Dict[str, Any]]:
        return self._request_json("/api/v0/servers")

    def list_tools(self, server: Optional[str] = None) -> List[Dict[str, Any]]:
        if server:
            return self._request_json(f"/api/v0/tools?server={server}")
        return self._request_json("/api/v0/tools")

    def invoke_tool(self, name: str, args: Dict[str, Any]) -> Dict[str, Any]:
        payload = dict(args)
        payload["name"] = name
        return self._request_json("/api/v0/tools/invoke", method="POST", payload=payload)

    def list_users(self) -> List[Dict[str, Any]]:
        return self._request_json("/api/v0/users")

    def create_user(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return self._request_json("/api/v0/users", method="POST", payload=payload)

    def update_user(self, username: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        return self._request_json(f"/api/v0/users/{username}", method="PUT", payload=payload)

    def _request_json(self, path: str, method: str = "GET", payload: Optional[Dict[str, Any]] = None):
        base = self.base_url.rstrip("/")
        url = f"{base}{path}"
        data = None
        headers = {"Accept": "application/json"}
        if payload is not None:
            data = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"

        req = Request(url, data=data, method=method, headers=headers)
        try:
            with urlopen(req, timeout=self.timeout_seconds) as resp:
                raw = resp.read().decode("utf-8")
        except HTTPError as exc:
            detail = exc.read().decode("utf-8") if exc.fp else ""
            raise McpJungleError(f"HTTP {exc.code} {detail}".strip()) from exc
        except URLError as exc:
            raise McpJungleError(f"request failed: {exc.reason}") from exc

        if not raw:
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise McpJungleError("invalid json response") from exc

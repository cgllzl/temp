from __future__ import annotations

import logging
from pathlib import Path

from app.config import settings

logger = logging.getLogger(__name__)

_token_cache: str | None = None


def _read_token(path: Path) -> str:
    try:
        token = path.read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        return ""
    except OSError as exc:
        logger.warning("failed to read MCPJungle token file: %s", exc)
        return ""
    return token


def _write_token(path: Path, token: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"{token}\n", encoding="utf-8")
    except OSError as exc:
        logger.warning("failed to write MCPJungle token file: %s", exc)


def _token_from_env() -> str:
    return (settings.mcpjungle_access_token or "").strip()


def _token_from_file() -> str:
    return _read_token(settings.mcpjungle_token_path)

def ensure_access_token() -> str:
    global _token_cache
    if _token_cache:
        return _token_cache

    env_token = _token_from_env()
    if env_token:
        _token_cache = env_token
        return _token_cache

    file_token = _token_from_file()
    if file_token:
        _token_cache = file_token
        return _token_cache
    logger.warning("MCPJUNGLE_ACCESS_TOKEN is empty and token file is missing")
    return ""


def get_access_token() -> str:
    return ensure_access_token()

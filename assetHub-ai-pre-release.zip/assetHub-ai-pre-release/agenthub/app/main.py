from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.db import init_db
from app.routers.agents import router as agents_router
from app.routers.health import router as health_router
from app.routers.plugins import router as plugins_router
from app.services.mcpjungle_auth import ensure_access_token
from app.storage import ensure_storage_dirs

app = FastAPI(title="AgentHub API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health_router)
app.include_router(agents_router)
app.include_router(plugins_router)

# Ensure storage exists before mounting static files to avoid boot errors.
ensure_storage_dirs(settings.storage_dir)


@app.on_event("startup")
def on_startup() -> None:
    ensure_storage_dirs(settings.storage_dir)
    init_db()
    ensure_access_token()


app.mount(
    "/agents-index",
    StaticFiles(directory=str(settings.storage_dir / "public"), html=False, check_dir=False),
    name="agents-index",
)

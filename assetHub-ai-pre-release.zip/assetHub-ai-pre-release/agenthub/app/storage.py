from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

SUPPORTED_LANGS: Tuple[str, str] = ("en-US", "zh-CN")


def ensure_storage_dirs(base_dir: Path) -> None:
    (base_dir / "agents").mkdir(parents=True, exist_ok=True)
    (base_dir / "public").mkdir(parents=True, exist_ok=True)


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)
        handle.write("\n")


def _clear_public(public_dir: Path) -> None:
    for path in public_dir.glob("*.json"):
        path.unlink(missing_ok=True)


def _index_entry(agent_payload: dict) -> dict:
    return {
        "identifier": agent_payload.get("identifier"),
        "meta": agent_payload.get("meta"),
        "author": agent_payload.get("author", ""),
        "createAt": agent_payload.get("createAt"),
        "createdAt": agent_payload.get("createdAt"),
        "homepage": agent_payload.get("homepage", ""),
    }


def export_public_index(
    storage_dir: Path,
    agents: Iterable[Tuple[str, Dict[str, dict]]],
    schema_version: int = 1,
) -> None:
    ensure_storage_dirs(storage_dir)
    public_dir = storage_dir / "public"
    _clear_public(public_dir)

    entries_by_lang: Dict[str, List[dict]] = {lang: [] for lang in SUPPORTED_LANGS}

    for identifier, payloads in agents:
        if not payloads:
            continue
        fallback = payloads.get("en-US") or next(iter(payloads.values()))
        if not fallback:
            continue

        for lang in SUPPORTED_LANGS:
            payload = payloads.get(lang) or fallback
            write_json(public_dir / f"agent-{identifier}.{lang}.json", payload)
            entries_by_lang[lang].append(_index_entry(payload))

        write_json(public_dir / f"agent-{identifier}.json", fallback)

    for lang in SUPPORTED_LANGS:
        index_payload = {"schemaVersion": schema_version, "agents": entries_by_lang[lang]}
        write_json(public_dir / f"index.{lang}.json", index_payload)

    write_json(public_dir / "index.json", {"schemaVersion": schema_version, "agents": entries_by_lang["en-US"]})

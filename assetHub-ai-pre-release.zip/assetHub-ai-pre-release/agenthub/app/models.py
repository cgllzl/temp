from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Optional
from uuid import UUID, uuid4

from sqlalchemy import Column, JSON, UniqueConstraint
from sqlmodel import Field, SQLModel


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class AgentStatus(str, Enum):
    draft = "draft"
    in_review = "in_review"
    published = "published"
    unpublished = "unpublished"
    archived = "archived"


class Agent(SQLModel, table=True):
    id: UUID = Field(default_factory=uuid4, primary_key=True, index=True)
    identifier: str = Field(nullable=False, unique=True, index=True)

    display_name: str = Field(nullable=False)
    description: str = Field(nullable=False)
    avatar: Optional[str] = Field(default=None)
    category: Optional[str] = Field(default=None)
    tags: Optional[list] = Field(default=None, sa_column=Column(JSON))

    status: AgentStatus = Field(default=AgentStatus.draft)
    latest_version: Optional[str] = Field(default=None)
    published_version: Optional[str] = Field(default=None)

    review_note: Optional[str] = Field(default=None)
    reviewed_at: Optional[datetime] = Field(default=None)

    created_at: datetime = Field(default_factory=utcnow)
    updated_at: datetime = Field(default_factory=utcnow)


class AgentVersion(SQLModel, table=True):
    __table_args__ = (
        UniqueConstraint("agent_id", "version", name="uq_agent_version"),
    )

    id: UUID = Field(default_factory=uuid4, primary_key=True, index=True)
    agent_id: UUID = Field(foreign_key="agent.id", index=True)
    version: str = Field(nullable=False)
    payloads: dict = Field(sa_column=Column(JSON, nullable=False))
    mcp_servers: Optional[list] = Field(default=None, sa_column=Column(JSON))
    mcp_tools: Optional[list] = Field(default=None, sa_column=Column(JSON))

    created_at: datetime = Field(default_factory=utcnow)
    updated_at: datetime = Field(default_factory=utcnow)

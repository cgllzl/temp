from __future__ import annotations

import json
from collections import Counter
from datetime import datetime, timezone
from typing import Any, Dict, List, Tuple
from urllib.parse import quote

from fastapi import APIRouter, HTTPException, Request

from app.config import settings
from app.services.mcpjungle import McpJungleClient, McpJungleError
from app.services.mcpjungle_auth import get_access_token

router = APIRouter(prefix="/plugins-index", tags=["plugins"])

SUPPORTED_LOCALES: Tuple[str, str] = ("en-US", "zh-CN")
SCHEMA_VERSION = 1
SCHEMA_URL = "https://unpkg.com/@lobehub/chat-plugin-sdk@latest/schema.json"


def _client() -> McpJungleClient:
    return McpJungleClient(
        base_url=settings.mcpjungle_base_url,
        access_token=get_access_token(),
        timeout_seconds=settings.mcpjungle_timeout_seconds,
    )


def _build_public_base_url(request: Request) -> str:
    if settings.plugins_base_url:
        return settings.plugins_base_url.rstrip("/")

    host = request.headers.get("x-forwarded-host") or request.headers.get("host") or ""
    proto = request.headers.get("x-forwarded-proto") or request.url.scheme
    if host:
        return f"{proto}://{host}/plugins-index"

    return str(request.base_url).rstrip("/") + "/plugins-index"


def _split_tool_name(name: str) -> Tuple[str, str] | None:
    if "__" not in name:
        return None
    server, tool = name.split("__", 1)
    if not server or not tool:
        return None
    return server, tool


def _normalize_schema(raw: Any) -> Dict[str, Any]:
    data = raw
    if isinstance(raw, str):
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = {}
    if not isinstance(data, dict):
        data = {}
    schema = dict(data)
    if schema.get("type") != "object":
        schema["type"] = "object"
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        schema["properties"] = {}
    return schema


def _find_duplicate_tags(tags: List[str]) -> List[str]:
    if not tags:
        return []
    counts = Counter(tags)
    threshold = 3 if len(tags) > 10 else 1
    result = [tag for tag, count in counts.items() if count >= threshold]
    result.sort(key=lambda tag: counts[tag], reverse=True)
    return result


def _group_tools_by_server(tools: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    grouped: Dict[str, List[Dict[str, Any]]] = {}
    for tool in tools:
        if tool.get("enabled") is False:
            continue
        name = tool.get("name") or ""
        parsed = _split_tool_name(name)
        if not parsed:
            continue
        server, tool_name = parsed
        payload = dict(tool)
        payload["tool_name"] = tool_name
        grouped.setdefault(server, []).append(payload)
    return grouped


def _build_plugin_entry(
    server: Dict[str, Any],
    base_url: str,
    locale: str,
    created_at: str,
) -> Dict[str, Any]:
    name = server.get("name") or ""
    description = server.get("description") or f"MCP server {name}"
    tags = [tag for tag in ["mcp", server.get("transport")] if tag]
    return {
        "author": settings.plugins_author,
        "createdAt": created_at,
        "homepage": server.get("url") or "",
        "identifier": name,
        "locale": locale,
        "manifest": f"{base_url}/manifests/{quote(name)}.json",
        "meta": {
            "avatar": settings.plugins_avatar,
            "tags": tags or ["mcp"],
            "title": name,
            "description": description,
            "category": "tools",
        },
        "schemaVersion": SCHEMA_VERSION,
    }


def _build_manifest(
    server: Dict[str, Any],
    tools: List[Dict[str, Any]],
    base_url: str,
    created_at: str,
) -> Dict[str, Any]:
    name = server.get("name") or ""
    description = server.get("description") or f"MCP server {name}"
    tags = [tag for tag in ["mcp", server.get("transport")] if tag]
    api_entries = []
    for tool in tools:
        tool_name = tool.get("tool_name") or ""
        if not tool_name:
            continue
        api_entries.append(
            {
                "name": tool_name,
                "description": tool.get("description") or f"{name}::{tool_name}",
                "parameters": _normalize_schema(tool.get("input_schema")),
                "url": f"{base_url}/api/{quote(name)}/{quote(tool_name, safe='')}",
            }
        )

    return {
        "$schema": SCHEMA_URL,
        "api": api_entries,
        "author": settings.plugins_author,
        "createdAt": created_at,
        "homepage": server.get("url") or "",
        "identifier": name,
        "meta": {
            "avatar": settings.plugins_avatar,
            "tags": tags or ["mcp"],
            "title": name,
            "description": description,
        },
        "version": "1",
    }


def _load_plugins(locale: str, base_url: str) -> Dict[str, Any]:
    if locale not in SUPPORTED_LOCALES:
        raise HTTPException(status_code=400, detail="unsupported locale")

    client = _client()
    try:
        servers = client.list_servers()
        tools = client.list_tools()
    except McpJungleError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    tools_by_server = _group_tools_by_server(tools)
    created_at = datetime.now(timezone.utc).date().isoformat()

    plugins = []
    for server in servers:
        name = server.get("name")
        if not name:
            continue
        if name not in tools_by_server:
            continue
        plugins.append(_build_plugin_entry(server, base_url, locale, created_at))

    tags: List[str] = []
    for item in plugins:
        tags.extend(item.get("meta", {}).get("tags", []))

    return {
        "schemaVersion": SCHEMA_VERSION,
        "plugins": plugins,
        "tags": _find_duplicate_tags(tags),
    }


def _load_manifest(identifier: str, base_url: str) -> Dict[str, Any]:
    client = _client()
    try:
        servers = client.list_servers()
        tools = client.list_tools(server=identifier)
    except McpJungleError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    server = next((item for item in servers if item.get("name") == identifier), None)
    if not server:
        raise HTTPException(status_code=404, detail="plugin not found")

    tools_by_server = _group_tools_by_server(tools)
    server_tools = tools_by_server.get(identifier, [])
    if not server_tools:
        raise HTTPException(status_code=404, detail="plugin has no tools")

    created_at = datetime.now(timezone.utc).date().isoformat()
    return _build_manifest(server, server_tools, base_url, created_at)


@router.get("/index.json")
def get_index(request: Request) -> Dict[str, Any]:
    base_url = _build_public_base_url(request)
    return _load_plugins("en-US", base_url)


@router.get("/index.en-US.json")
def get_index_en(request: Request) -> Dict[str, Any]:
    base_url = _build_public_base_url(request)
    return _load_plugins("en-US", base_url)


@router.get("/index.zh-CN.json")
def get_index_zh(request: Request) -> Dict[str, Any]:
    base_url = _build_public_base_url(request)
    return _load_plugins("zh-CN", base_url)


@router.get("/manifests/{identifier}.json")
def get_manifest(identifier: str, request: Request) -> Dict[str, Any]:
    base_url = _build_public_base_url(request)
    return _load_manifest(identifier, base_url)


@router.post("/api/{server}/{tool}")
async def invoke_plugin_tool(server: str, tool: str, request: Request) -> Dict[str, Any]:
    content_type = request.headers.get("content-type", "")
    raw_body = await request.body()

    payload: Dict[str, Any] = {}
    if raw_body:
        if "application/json" not in content_type:
            raise HTTPException(status_code=415, detail="unsupported media type")
        try:
            payload = await request.json()
        except Exception as exc:
            raise HTTPException(status_code=400, detail="invalid json") from exc
        if not isinstance(payload, dict):
            raise HTTPException(status_code=400, detail="payload must be object")

    client = _client()
    try:
        return client.invoke_tool(f"{server}__{tool}", payload)
    except McpJungleError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/api/{server}/{tool:path}")
async def invoke_tool(server: str, tool: str, request: Request) -> Dict[str, Any]:
    body = await request.body()
    payload: Dict[str, Any] = {}
    if body:
        try:
            payload = json.loads(body.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail="invalid json body") from exc

    client = _client()
    name = f"{server}__{tool}"
    try:
        return client.invoke_tool(name, payload)
    except McpJungleError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

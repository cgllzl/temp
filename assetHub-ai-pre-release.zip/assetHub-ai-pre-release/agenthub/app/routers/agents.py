from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlmodel import Session, select

from app.config import settings
from app.db import get_session
from app.models import Agent, AgentStatus, AgentVersion
from app.schemas import (
    AgentCreateRequest,
    AgentCreateResponse,
    AgentDetail,
    AgentListItem,
    AgentListResponse,
    AgentPublishRequest,
    AgentReviewRequest,
    AgentUpdateVersionRequest,
    AgentVersionRead,
)
from app.storage import export_public_index

router = APIRouter(prefix="/agents", tags=["agents"])

IDENTIFIER_RE = re.compile(r"^[a-z0-9-]{3,64}$")


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _validate_identifier(identifier: str) -> None:
    if not IDENTIFIER_RE.fullmatch(identifier):
        raise HTTPException(status_code=400, detail="invalid identifier format")


def _require_locale(locale) -> None:
    if not locale.meta.title.strip():
        raise HTTPException(status_code=400, detail="meta.title is required")
    if not locale.meta.description.strip():
        raise HTTPException(status_code=400, detail="meta.description is required")
    if not locale.config.system_role.strip():
        raise HTTPException(status_code=400, detail="config.systemRole is required")


def _normalize_locales(locales: Dict[str, Any]) -> Dict[str, Any]:
    normalized = dict(locales)
    en = normalized.get("en-US")
    if not en:
        raise HTTPException(status_code=400, detail="locales must include en-US")
    if "zh-CN" not in normalized:
        normalized["zh-CN"] = en
    return normalized


def _normalize_mcp_list(values: List[str] | None) -> List[str]:
    if not values:
        return []
    normalized: List[str] = []
    seen = set()
    for value in values:
        if value is None:
            continue
        item = str(value).strip()
        if not item or item in seen:
            continue
        seen.add(item)
        normalized.append(item)
    return normalized


def _build_agent_payload(
    identifier: str,
    locale,
    created_at: datetime,
    mcp_servers: List[str],
    mcp_tools: List[str],
) -> dict:
    meta = locale.meta.dict(exclude_none=True)
    if mcp_servers:
        meta["mcpServers"] = mcp_servers
    if mcp_tools:
        meta["mcpTools"] = mcp_tools
    config = locale.config.dict(by_alias=True, exclude_none=True)
    timestamp = created_at.isoformat()
    return {
        "schemaVersion": 1,
        "identifier": identifier,
        "meta": meta,
        "config": config,
        "author": locale.author or "",
        "homepage": locale.homepage or "",
        "createAt": timestamp,
        "createdAt": timestamp,
    }


def _get_agent_or_404(session: Session, identifier: str) -> Agent:
    agent = session.exec(select(Agent).where(Agent.identifier == identifier)).first()
    if not agent:
        raise HTTPException(status_code=404, detail="agent not found")
    return agent


def _get_version_or_404(session: Session, agent_id, version: str) -> AgentVersion:
    record = session.exec(
        select(AgentVersion).where(
            AgentVersion.agent_id == agent_id,
            AgentVersion.version == version,
        )
    ).first()
    if not record:
        raise HTTPException(status_code=404, detail="agent version not found")
    return record


def _to_version_read(version: AgentVersion) -> AgentVersionRead:
    locales = sorted(version.payloads.keys()) if isinstance(version.payloads, dict) else []
    return AgentVersionRead(
        version=version.version,
        locales=locales,
        mcp_servers=version.mcp_servers or [],
        mcp_tools=version.mcp_tools or [],
        created_at=version.created_at,
        updated_at=version.updated_at,
    )


def _build_agent_detail(agent: Agent, session: Session) -> AgentDetail:
    versions = session.exec(
        select(AgentVersion)
        .where(AgentVersion.agent_id == agent.id)
        .order_by(AgentVersion.created_at.desc())
    ).all()

    return AgentDetail(
        identifier=agent.identifier,
        title=agent.display_name,
        description=agent.description,
        avatar=agent.avatar,
        category=agent.category,
        tags=agent.tags or [],
        status=agent.status,
        latest_version=agent.latest_version,
        published_version=agent.published_version,
        review_note=agent.review_note,
        reviewed_at=agent.reviewed_at,
        created_at=agent.created_at,
        updated_at=agent.updated_at,
        versions=[_to_version_read(v) for v in versions],
    )


def _export_agents(session: Session) -> None:
    agents = session.exec(select(Agent).where(Agent.status == AgentStatus.published)).all()
    payloads = []
    for agent in agents:
        version = agent.published_version or agent.latest_version
        if not version:
            continue
        record = session.exec(
            select(AgentVersion).where(
                AgentVersion.agent_id == agent.id,
                AgentVersion.version == version,
            )
        ).first()
        if not record:
            continue
        payloads.append((agent.identifier, record.payloads))

    export_public_index(settings.storage_dir, payloads, schema_version=1)


@router.get("", response_model=AgentListResponse)
def list_agents(
    session: Session = Depends(get_session),
    statuses: List[AgentStatus] | None = Query(default=None),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=200),
) -> AgentListResponse:
    query = select(Agent)
    if statuses:
        query = query.where(Agent.status.in_(statuses))
    rows = session.exec(query.order_by(Agent.updated_at.desc())).all()

    items = [
        AgentListItem(
            identifier=row.identifier,
            title=row.display_name,
            description=row.description,
            status=row.status,
            latest_version=row.latest_version,
            published_version=row.published_version,
            updated_at=row.updated_at,
            avatar=row.avatar,
            category=row.category,
            tags=row.tags or [],
        )
        for row in rows
    ]

    total = len(items)
    start = (page - 1) * page_size
    end = start + page_size
    return AgentListResponse(items=items[start:end], total=total, page=page, page_size=page_size)


@router.get("/{identifier}", response_model=AgentDetail)
def get_agent(identifier: str, session: Session = Depends(get_session)) -> AgentDetail:
    agent = _get_agent_or_404(session, identifier)
    return _build_agent_detail(agent, session)


@router.post("", response_model=AgentCreateResponse)
def create_agent(payload: AgentCreateRequest, session: Session = Depends(get_session)) -> AgentCreateResponse:
    _validate_identifier(payload.identifier)

    existing = session.exec(select(Agent).where(Agent.identifier == payload.identifier)).first()
    if existing:
        raise HTTPException(status_code=409, detail="agent already exists")

    locales = _normalize_locales(payload.locales)
    for locale in locales.values():
        _require_locale(locale)

    created_at = utcnow()
    mcp_servers = _normalize_mcp_list(payload.mcp_servers)
    mcp_tools = _normalize_mcp_list(payload.mcp_tools)

    locale_payloads = {
        key: _build_agent_payload(payload.identifier, value, created_at, mcp_servers, mcp_tools)
        for key, value in locales.items()
    }

    en_meta = locales["en-US"].meta
    agent = Agent(
        identifier=payload.identifier,
        display_name=en_meta.title,
        description=en_meta.description,
        avatar=en_meta.avatar,
        category=en_meta.category,
        tags=en_meta.tags,
        status=AgentStatus.draft,
        latest_version=payload.version,
        published_version=None,
        created_at=created_at,
        updated_at=created_at,
    )
    session.add(agent)
    version_record = AgentVersion(
        agent_id=agent.id,
        version=payload.version,
        payloads=locale_payloads,
        mcp_servers=mcp_servers,
        mcp_tools=mcp_tools,
        created_at=created_at,
        updated_at=created_at,
    )
    session.add(version_record)
    session.commit()
    session.refresh(agent)

    return AgentCreateResponse(identifier=agent.identifier, version=payload.version, status=agent.status)


@router.post("/{identifier}/versions", response_model=AgentCreateResponse)
def create_version(
    identifier: str,
    payload: AgentUpdateVersionRequest,
    session: Session = Depends(get_session),
) -> AgentCreateResponse:
    agent = _get_agent_or_404(session, identifier)

    existing = session.exec(
        select(AgentVersion).where(
            AgentVersion.agent_id == agent.id,
            AgentVersion.version == payload.version,
        )
    ).first()
    if existing:
        raise HTTPException(status_code=409, detail="agent version already exists")

    locales = _normalize_locales(payload.locales)
    for locale in locales.values():
        _require_locale(locale)

    created_at = utcnow()
    mcp_servers = _normalize_mcp_list(payload.mcp_servers)
    mcp_tools = _normalize_mcp_list(payload.mcp_tools)

    locale_payloads = {
        key: _build_agent_payload(identifier, value, created_at, mcp_servers, mcp_tools)
        for key, value in locales.items()
    }

    en_meta = locales["en-US"].meta
    agent.display_name = en_meta.title
    agent.description = en_meta.description
    agent.avatar = en_meta.avatar
    agent.category = en_meta.category
    agent.tags = en_meta.tags
    agent.latest_version = payload.version
    agent.status = AgentStatus.draft
    agent.published_version = None
    agent.review_note = None
    agent.reviewed_at = None
    agent.updated_at = created_at

    version_record = AgentVersion(
        agent_id=agent.id,
        version=payload.version,
        payloads=locale_payloads,
        mcp_servers=mcp_servers,
        mcp_tools=mcp_tools,
        created_at=created_at,
        updated_at=created_at,
    )
    session.add(version_record)
    session.add(agent)
    session.commit()

    _export_agents(session)

    return AgentCreateResponse(identifier=agent.identifier, version=payload.version, status=agent.status)


@router.post("/export")
def export_agents(session: Session = Depends(get_session)) -> dict:
    _export_agents(session)
    return {"status": "ok"}


@router.post("/{identifier}/submit-review", response_model=AgentDetail)
def submit_review(
    identifier: str,
    payload: AgentReviewRequest,
    session: Session = Depends(get_session),
) -> AgentDetail:
    agent = _get_agent_or_404(session, identifier)
    if agent.status not in {AgentStatus.draft, AgentStatus.unpublished}:
        raise HTTPException(status_code=400, detail="agent cannot be submitted for review")

    agent.status = AgentStatus.in_review
    agent.review_note = payload.note
    agent.reviewed_at = utcnow()
    agent.updated_at = utcnow()
    session.add(agent)
    session.commit()

    return _build_agent_detail(agent, session)


@router.post("/{identifier}/approve", response_model=AgentDetail)
def approve_agent(
    identifier: str,
    payload: AgentPublishRequest,
    session: Session = Depends(get_session),
) -> AgentDetail:
    agent = _get_agent_or_404(session, identifier)
    if agent.status != AgentStatus.in_review:
        raise HTTPException(status_code=400, detail="agent is not in review")

    version = payload.version or agent.latest_version
    if not version:
        raise HTTPException(status_code=400, detail="no version to publish")

    _get_version_or_404(session, agent.id, version)

    agent.status = AgentStatus.published
    agent.published_version = version
    agent.review_note = None
    agent.reviewed_at = utcnow()
    agent.updated_at = utcnow()
    session.add(agent)
    session.commit()

    _export_agents(session)

    return _build_agent_detail(agent, session)


@router.post("/{identifier}/reject", response_model=AgentDetail)
def reject_agent(
    identifier: str,
    payload: AgentReviewRequest,
    session: Session = Depends(get_session),
) -> AgentDetail:
    agent = _get_agent_or_404(session, identifier)
    if agent.status != AgentStatus.in_review:
        raise HTTPException(status_code=400, detail="agent is not in review")

    agent.status = AgentStatus.draft
    agent.review_note = payload.note
    agent.reviewed_at = utcnow()
    agent.updated_at = utcnow()
    session.add(agent)
    session.commit()

    return _build_agent_detail(agent, session)


@router.post("/{identifier}/publish", response_model=AgentDetail)
def publish_agent(
    identifier: str,
    payload: AgentPublishRequest,
    session: Session = Depends(get_session),
) -> AgentDetail:
    agent = _get_agent_or_404(session, identifier)
    if agent.status != AgentStatus.unpublished:
        raise HTTPException(status_code=400, detail="agent is not unpublished")

    version = payload.version or agent.latest_version
    if not version:
        raise HTTPException(status_code=400, detail="no version to publish")

    _get_version_or_404(session, agent.id, version)

    agent.status = AgentStatus.published
    agent.published_version = version
    agent.review_note = None
    agent.reviewed_at = utcnow()
    agent.updated_at = utcnow()
    session.add(agent)
    session.commit()

    _export_agents(session)

    return _build_agent_detail(agent, session)


@router.post("/{identifier}/unpublish", response_model=AgentDetail)
def unpublish_agent(identifier: str, session: Session = Depends(get_session)) -> AgentDetail:
    agent = _get_agent_or_404(session, identifier)
    if agent.status != AgentStatus.published:
        raise HTTPException(status_code=400, detail="agent is not published")

    agent.status = AgentStatus.unpublished
    agent.review_note = None
    agent.reviewed_at = utcnow()
    agent.updated_at = utcnow()
    session.add(agent)
    session.commit()

    _export_agents(session)

    return _build_agent_detail(agent, session)

from __future__ import annotations

from typing import Generator

from sqlmodel import SQLModel, Session, create_engine

from app.config import settings
from app import models  # noqa: F401  # Ensure model tables are registered in SQLModel metadata


def _create_engine():
    connect_args = {}
    if settings.database_url.startswith("sqlite"):
        connect_args = {"check_same_thread": False}
    return create_engine(
        settings.database_url,
        echo=False,
        pool_pre_ping=True,
        connect_args=connect_args,
    )


engine = _create_engine()


def init_db() -> None:
    SQLModel.metadata.create_all(engine)


def get_session() -> Generator[Session, None, None]:
    with Session(engine) as session:
        yield session

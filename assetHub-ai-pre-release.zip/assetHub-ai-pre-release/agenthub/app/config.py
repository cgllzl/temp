from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import List


@dataclass(frozen=True)
class Settings:
    database_url: str
    storage_dir: Path
    cors_origins: List[str]
    port: int
    mcpjungle_base_url: str
    mcpjungle_access_token: str
    mcpjungle_timeout_seconds: float
    mcpjungle_token_path: Path
    plugins_base_url: str
    plugins_author: str
    plugins_avatar: str


def _parse_cors_origins(raw: str) -> List[str]:
    items = [item.strip() for item in raw.split(",") if item.strip()]
    return items or ["*"]


def get_settings() -> Settings:
    database_url = os.getenv("AGENTHUB_DATABASE_URL") or os.getenv("DATABASE_URL")
    if not database_url:
        database_url = "sqlite:///./agenthub.db"
    elif database_url.startswith("postgres://"):
        database_url = database_url.replace("postgres://", "postgresql+psycopg2://", 1)

    storage_dir = Path(os.getenv("AGENTHUB_STORAGE_DIR", "./agenthub-data")).resolve()
    cors_origins = _parse_cors_origins(os.getenv("AGENTHUB_CORS_ORIGINS", "*"))
    port = int(os.getenv("PORT", "8091"))
    mcpjungle_base_url = os.getenv("MCPJUNGLE_BASE_URL", "http://127.0.0.1:8080").rstrip("/")
    mcpjungle_access_token = os.getenv("MCPJUNGLE_ACCESS_TOKEN", "")
    mcpjungle_timeout_seconds = float(os.getenv("MCPJUNGLE_TIMEOUT_SECONDS", "10"))
    token_path_raw = os.getenv(
        "AGENTHUB_MCP_SERVICE_TOKEN_PATH",
        str(storage_dir / "mcpjungle" / "service-principals" / "agenthub-runtime.token"),
    )
    mcpjungle_token_path = Path(token_path_raw).expanduser().resolve()
    plugins_base_url = os.getenv("AGENTHUB_PLUGINS_BASE_URL", "").rstrip("/")
    plugins_author = os.getenv("AGENTHUB_PLUGINS_AUTHOR", "AssetHub")
    plugins_avatar = os.getenv("AGENTHUB_PLUGINS_AVATAR", "plugin")

    return Settings(
        database_url=database_url,
        storage_dir=storage_dir,
        cors_origins=cors_origins,
        port=port,
        mcpjungle_base_url=mcpjungle_base_url,
        mcpjungle_access_token=mcpjungle_access_token,
        mcpjungle_timeout_seconds=mcpjungle_timeout_seconds,
        mcpjungle_token_path=mcpjungle_token_path,
        plugins_base_url=plugins_base_url,
        plugins_author=plugins_author,
        plugins_avatar=plugins_avatar,
    )


settings = get_settings()

from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.db import init_db
from app.routers.health import router as health_router
from app.routers.skills import router as skills_router
from app.storage import ensure_storage_dirs

app = FastAPI(title="SkillHub API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health_router)
app.include_router(skills_router)


@app.on_event("startup")
def on_startup() -> None:
    ensure_storage_dirs(settings.storage_dir)
    init_db()

from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from typing import List, Tuple
from zipfile import ZipFile, ZIP_DEFLATED


def ensure_storage_dirs(base_dir: Path) -> None:
    (base_dir / "skills").mkdir(parents=True, exist_ok=True)
    (base_dir / "packages").mkdir(parents=True, exist_ok=True)
    (base_dir / "tmp").mkdir(parents=True, exist_ok=True)


def create_temp_dir(base_dir: Path) -> Path:
    ensure_storage_dirs(base_dir)
    tmp_root = base_dir / "tmp"
    return Path(tempfile.mkdtemp(dir=tmp_root))


def safe_extract(zip_path: Path, dest_dir: Path) -> None:
    with ZipFile(zip_path, "r") as zf:
        for member in zf.infolist():
            member_path = dest_dir / member.filename
            resolved = member_path.resolve()
            if not str(resolved).startswith(str(dest_dir.resolve())):
                raise ValueError("zip contains invalid path")
        zf.extractall(dest_dir)


def resolve_skill_root(extract_dir: Path) -> Tuple[Path, str]:
    entries = [p for p in extract_dir.iterdir() if not p.name.startswith("__MACOSX")]
    dirs = [p for p in entries if p.is_dir()]
    files = [p for p in entries if p.is_file()]

    if files:
        raise ValueError("zip root must contain only a single skill directory")
    if len(dirs) != 1:
        raise ValueError("zip root must contain exactly one skill directory")

    skill_root = dirs[0]
    return skill_root, skill_root.name


def build_files_manifest(skill_root: Path) -> Tuple[List[str], dict]:
    files: List[str] = []
    for path in skill_root.rglob("*"):
        if path.is_file():
            files.append(path.relative_to(skill_root).as_posix())

    def count_prefix(prefix: str) -> int:
        return sum(1 for item in files if item.startswith(prefix))

    summary = {
        "total": len(files),
        "scripts": count_prefix("scripts/"),
        "references": count_prefix("references/"),
        "assets": count_prefix("assets/"),
    }
    return files, summary


def move_skill_root(skill_root: Path, target_root: Path) -> None:
    if target_root.exists():
        raise FileExistsError("target skill directory already exists")
    target_root.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(skill_root), str(target_root))


def package_skill(skill_root: Path, package_dir: Path, name: str, version: str) -> Path:
    package_dir.mkdir(parents=True, exist_ok=True)
    package_path = package_dir / f"{name}-{version}.zip"
    with ZipFile(package_path, "w", ZIP_DEFLATED) as zf:
        for path in skill_root.rglob("*"):
            if path.is_file():
                rel = path.relative_to(skill_root).as_posix()
                arcname = f"{name}/{rel}"
                zf.write(path, arcname)
    return package_path

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Optional
from uuid import UUID, uuid4

from sqlalchemy import Column, JSON, UniqueConstraint
from sqlmodel import Field, SQLModel


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class SkillType(str, Enum):
    custom = "custom"
    org_provisioned = "org-provisioned"
    partner = "partner"
    anthropic = "anthropic"


class SkillStatus(str, Enum):
    draft = "draft"
    active = "active"
    deprecated = "deprecated"
    archived = "archived"


class ValidationStatus(str, Enum):
    not_validated = "not_validated"
    passed = "passed"
    failed = "failed"
    not_available = "not_available"


class Skill(SQLModel, table=True):
    id: UUID = Field(default_factory=uuid4, primary_key=True, index=True)
    name: str = Field(nullable=False, unique=True, index=True)
    description: str
    type: SkillType = Field(default=SkillType.custom)
    status: SkillStatus = Field(default=SkillStatus.draft)
    latest_version: Optional[str] = Field(default=None)
    created_at: datetime = Field(default_factory=utcnow)
    updated_at: datetime = Field(default_factory=utcnow)


class SkillVersion(SQLModel, table=True):
    __table_args__ = (
        UniqueConstraint("skill_id", "version", name="uq_skill_version"),
    )

    id: UUID = Field(default_factory=uuid4, primary_key=True, index=True)
    skill_id: UUID = Field(foreign_key="skill.id", index=True)
    version: str = Field(nullable=False)
    directory_name: str = Field(nullable=False)
    storage_path: str = Field(nullable=False)

    dependencies: Optional[list] = Field(default=None, sa_column=Column(JSON))
    files_summary: Optional[dict] = Field(default=None, sa_column=Column(JSON))
    files_manifest: Optional[list] = Field(default=None, sa_column=Column(JSON))

    dependencies_count: int = Field(default=0)
    resources_count: int = Field(default=0)

    validation_status: ValidationStatus = Field(default=ValidationStatus.not_validated)
    validation_report: Optional[dict] = Field(default=None, sa_column=Column(JSON))
    validated_at: Optional[datetime] = Field(default=None)

    package_path: Optional[str] = Field(default=None)

    created_at: datetime = Field(default_factory=utcnow)
    updated_at: datetime = Field(default_factory=utcnow)

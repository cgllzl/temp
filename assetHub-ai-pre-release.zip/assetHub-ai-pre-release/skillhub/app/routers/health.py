from __future__ import annotations

import importlib.util
import os
import shutil
import sys

from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
def health_check() -> dict:
    return {"status": "ok"}


@router.get("/health/skills-ref")
def skills_ref_health() -> dict:
    bin_name = os.getenv("SKILLS_REF_BIN", "skills-ref")
    path = shutil.which(bin_name)
    module_available = importlib.util.find_spec("skills_ref.cli") is not None
    command = [path] if path else ([sys.executable, "-m", "skills_ref.cli"] if module_available else None)
    return {
        "available": bool(path) or module_available,
        "bin": bin_name,
        "path": path,
        "module_available": module_available,
        "command": command,
    }

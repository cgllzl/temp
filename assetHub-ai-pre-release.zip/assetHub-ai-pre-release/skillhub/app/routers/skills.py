from __future__ import annotations

import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Tuple

from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from sqlmodel import Session, select

from app.config import settings
from app.db import get_session
from app.models import Skill, SkillStatus, SkillType, SkillVersion, ValidationStatus
from app.schemas import (
    PackageResponse,
    SkillCreateRequest,
    SkillCreateResponse,
    SkillDetail,
    SkillListItem,
    SkillListResponse,
    SkillStatusUpdateRequest,
    SkillVersionRead,
    UploadResponse,
    ValidationResponse,
)
from app.skill_parser import DESCRIPTION_MAX_LENGTH, NAME_RE, parse_skill_md, update_skill_md_metadata
from app.skill_templates import write_standard_skill
from app.storage import (
    build_files_manifest,
    create_temp_dir,
    move_skill_root,
    package_skill,
    resolve_skill_root,
    safe_extract,
)
from app.validators import run_skills_ref_validate

router = APIRouter(prefix="/skills", tags=["skills"])


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _to_version_read(version: SkillVersion) -> SkillVersionRead:
    return SkillVersionRead(
        version=version.version,
        directory_name=version.directory_name,
        dependencies=version.dependencies,
        files_summary=version.files_summary,
        files_manifest=version.files_manifest,
        dependencies_count=version.dependencies_count,
        resources_count=version.resources_count,
        validation_status=version.validation_status,
        validated_at=version.validated_at,
        validation_report=version.validation_report,
        package_available=bool(version.package_path),
        created_at=version.created_at,
        updated_at=version.updated_at,
    )


def _get_skill_or_404(session: Session, name: str) -> Skill:
    skill = session.exec(select(Skill).where(Skill.name == name)).first()
    if not skill:
        raise HTTPException(status_code=404, detail="skill not found")
    return skill


def _get_version_or_404(session: Session, skill_id, version: str) -> SkillVersion:
    record = session.exec(
        select(SkillVersion).where(
            SkillVersion.skill_id == skill_id,
            SkillVersion.version == version,
        )
    ).first()
    if not record:
        raise HTTPException(status_code=404, detail="skill version not found")
    return record


def _build_skill_detail(skill: Skill, session: Session) -> SkillDetail:
    versions = session.exec(
        select(SkillVersion)
        .where(SkillVersion.skill_id == skill.id)
        .order_by(SkillVersion.created_at.desc())
    ).all()

    return SkillDetail(
        name=skill.name,
        description=skill.description,
        type=skill.type,
        status=skill.status,
        latest_version=skill.latest_version,
        created_at=skill.created_at,
        updated_at=skill.updated_at,
        versions=[_to_version_read(v) for v in versions],
    )


def _normalize_dependencies(dependencies: List[str]) -> List[str]:
    return [item.strip() for item in dependencies if isinstance(item, str) and item.strip()]


def _persist_skill_version(
    session: Session,
    skill_root: Path,
    directory_name: str,
    metadata,
    files_manifest: List[str],
    files_summary: dict,
) -> Tuple[str, str]:
    resources_count = (
        files_summary.get("scripts", 0)
        + files_summary.get("references", 0)
        + files_summary.get("assets", 0)
    )
    dependencies_count = len(metadata.dependencies)

    skill = session.exec(select(Skill).where(Skill.name == metadata.name)).first()
    if skill:
        existing = session.exec(
            select(SkillVersion).where(
                SkillVersion.skill_id == skill.id,
                SkillVersion.version == metadata.version,
            )
        ).first()
        if existing:
            raise HTTPException(status_code=409, detail="skill version already exists")

    target_root = settings.storage_dir / "skills" / metadata.name / metadata.version
    moved = False
    try:
        try:
            move_skill_root(skill_root, target_root)
            moved = True
        except FileExistsError:
            raise HTTPException(status_code=409, detail="skill version already exists")

        if not skill:
            skill = Skill(
                name=metadata.name,
                description=metadata.description,
                type=metadata.skill_type,
                status=SkillStatus.draft,
                latest_version=metadata.version,
                created_at=utcnow(),
                updated_at=utcnow(),
            )
            session.add(skill)
            session.commit()
            session.refresh(skill)
        else:
            skill.description = metadata.description
            skill.type = metadata.skill_type
            skill.latest_version = metadata.version
            skill.updated_at = utcnow()
            session.add(skill)
            session.commit()

        version_record = SkillVersion(
            skill_id=skill.id,
            version=metadata.version,
            directory_name=directory_name,
            storage_path=str(target_root),
            dependencies=metadata.dependencies if metadata.dependencies else None,
            files_summary=files_summary,
            files_manifest=files_manifest,
            dependencies_count=dependencies_count,
            resources_count=resources_count,
            created_at=utcnow(),
            updated_at=utcnow(),
        )
        session.add(version_record)
        session.commit()
    except Exception:
        if moved:
            shutil.rmtree(target_root, ignore_errors=True)
        raise

    return metadata.name, metadata.version


@router.get("", response_model=SkillListResponse)
def list_skills(
    session: Session = Depends(get_session),
    types: List[SkillType] | None = Query(default=None),
    statuses: List[SkillStatus] | None = Query(default=None),
    validation_statuses: List[ValidationStatus] | None = Query(default=None),
    has_scripts: bool | None = Query(default=None),
    has_dependencies: bool | None = Query(default=None),
    validation_passed: bool | None = Query(default=None),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=200),
) -> SkillListResponse:
    query = select(Skill)
    if types:
        query = query.where(Skill.type.in_(types))
    if statuses:
        query = query.where(Skill.status.in_(statuses))

    skills = session.exec(query.order_by(Skill.updated_at.desc())).all()
    items: List[SkillListItem] = []
    for skill in skills:
        dependencies_count = 0
        resources_count = 0
        validation_status = ValidationStatus.not_validated
        scripts_count = 0
        if skill.latest_version:
            latest = session.exec(
                select(SkillVersion).where(
                    SkillVersion.skill_id == skill.id,
                    SkillVersion.version == skill.latest_version,
                )
            ).first()
            if latest:
                dependencies_count = latest.dependencies_count
                resources_count = latest.resources_count
                validation_status = latest.validation_status
                files_summary = latest.files_summary or {}
                scripts_count = int(files_summary.get("scripts", 0) or 0)

        if has_scripts is not None:
            if has_scripts and scripts_count == 0:
                continue
            if not has_scripts and scripts_count > 0:
                continue

        if has_dependencies is not None:
            if has_dependencies and dependencies_count == 0:
                continue
            if not has_dependencies and dependencies_count > 0:
                continue

        if validation_statuses:
            if validation_status not in validation_statuses:
                continue

        if validation_passed is not None:
            if validation_passed and validation_status != ValidationStatus.passed:
                continue
            if not validation_passed and validation_status == ValidationStatus.passed:
                continue

        items.append(
            SkillListItem(
                name=skill.name,
                description=skill.description,
                type=skill.type,
                status=skill.status,
                latest_version=skill.latest_version,
                updated_at=skill.updated_at,
                dependencies_count=dependencies_count,
                resources_count=resources_count,
                validation_status=validation_status,
            )
        )
    total = len(items)
    start = (page - 1) * page_size
    end = start + page_size
    return SkillListResponse(
        items=items[start:end],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/{name}", response_model=SkillDetail)
def get_skill_detail(name: str, session: Session = Depends(get_session)) -> SkillDetail:
    skill = _get_skill_or_404(session, name)
    return _build_skill_detail(skill, session)


@router.patch("/{name}/status", response_model=SkillDetail)
def update_skill_status(
    name: str,
    payload: SkillStatusUpdateRequest,
    session: Session = Depends(get_session),
) -> SkillDetail:
    skill = _get_skill_or_404(session, name)
    skill.status = payload.status
    skill.updated_at = utcnow()
    session.add(skill)
    session.commit()
    session.refresh(skill)
    return _build_skill_detail(skill, session)


@router.get("/template")
def download_template(
    background_tasks: BackgroundTasks,
    template: str = Query(default="standard"),
) -> FileResponse:
    if template != "standard":
        raise HTTPException(status_code=400, detail="unsupported template")

    tmp_dir = create_temp_dir(settings.storage_dir)
    skill_root = tmp_dir / "example-skill"
    write_standard_skill(
        skill_root,
        name="example-skill",
        description="Example skill template",
        version="0.1.0",
        skill_type=SkillType.custom,
        dependencies=[],
    )
    package_dir = tmp_dir / "package"
    package_path = package_skill(skill_root, package_dir, "example-skill", "0.1.0")

    if background_tasks is not None:
        background_tasks.add_task(shutil.rmtree, tmp_dir, ignore_errors=True)

    return FileResponse(
        path=str(package_path),
        filename="skill-template-standard.zip",
        media_type="application/zip",
    )


@router.post("/create", response_model=SkillCreateResponse)
def create_skill(
    payload: SkillCreateRequest,
    session: Session = Depends(get_session),
) -> SkillCreateResponse:
    name = payload.name.strip()
    description = payload.description.strip()
    version = (payload.version or "0.1.0").strip()
    dependencies = _normalize_dependencies(payload.dependencies)

    if not name or not NAME_RE.match(name):
        raise HTTPException(
            status_code=400,
            detail="name must be lowercase letters, numbers, or hyphens and <=64 chars",
        )
    if not description:
        raise HTTPException(status_code=400, detail="description is required")
    if len(description) > DESCRIPTION_MAX_LENGTH:
        raise HTTPException(
            status_code=400,
            detail=f"description must be <= {DESCRIPTION_MAX_LENGTH} characters",
        )
    if not version:
        raise HTTPException(status_code=400, detail="version is required")

    tmp_dir = create_temp_dir(settings.storage_dir)
    try:
        skill_root = tmp_dir / name
        write_standard_skill(
            skill_root,
            name=name,
            description=description,
            version=version,
            skill_type=payload.type,
            dependencies=dependencies,
        )
        skill_md = skill_root / "SKILL.md"
        metadata = parse_skill_md(skill_md, name)
        files_manifest, files_summary = build_files_manifest(skill_root)

        saved_name, saved_version = _persist_skill_version(
            session,
            skill_root,
            name,
            metadata,
            files_manifest,
            files_summary,
        )
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

    return SkillCreateResponse(name=saved_name, version=saved_version, status="created")


@router.get("/{name}/versions/{version}", response_model=SkillVersionRead)
def get_skill_version(
    name: str, version: str, session: Session = Depends(get_session)
) -> SkillVersionRead:
    skill = _get_skill_or_404(session, name)
    record = _get_version_or_404(session, skill.id, version)
    return _to_version_read(record)


@router.post("/upload", response_model=UploadResponse)
async def upload_skill(
    file: UploadFile = File(...),
    version: str | None = Query(default=None),
    session: Session = Depends(get_session),
) -> UploadResponse:
    tmp_dir = create_temp_dir(settings.storage_dir)
    try:
        zip_path = tmp_dir / "upload.zip"
        with zip_path.open("wb") as out:
            shutil.copyfileobj(file.file, out)

        extract_dir = tmp_dir / "extract"
        extract_dir.mkdir(parents=True, exist_ok=True)
        try:
            safe_extract(zip_path, extract_dir)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"invalid zip: {exc}") from exc

        try:
            skill_root, directory_name = resolve_skill_root(extract_dir)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        skill_md = skill_root / "SKILL.md"
        if not skill_md.exists():
            raise HTTPException(status_code=400, detail="SKILL.md not found")

        if version is not None:
            version = version.strip()
            if not version:
                raise HTTPException(status_code=400, detail="version is required")
            try:
                update_skill_md_metadata(skill_md, {"version": version})
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc

        try:
            metadata = parse_skill_md(skill_md, directory_name)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        files_manifest, files_summary = build_files_manifest(skill_root)
        saved_name, saved_version = _persist_skill_version(
            session,
            skill_root,
            directory_name,
            metadata,
            files_manifest,
            files_summary,
        )

        return UploadResponse(name=saved_name, version=saved_version, status="uploaded")
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


@router.post("/{name}/versions/{version}/validate", response_model=ValidationResponse)
def validate_skill_version(
    name: str, version: str, session: Session = Depends(get_session)
) -> ValidationResponse:
    skill = _get_skill_or_404(session, name)
    record = _get_version_or_404(session, skill.id, version)

    skill_root = Path(record.storage_path)
    if not skill_root.exists():
        raise HTTPException(status_code=404, detail="skill files not found")

    result = run_skills_ref_validate(skill_root, expected_name=record.directory_name or skill.name)
    record.validation_status = result.status
    record.validation_report = result.report
    record.validated_at = utcnow()
    record.updated_at = utcnow()

    session.add(record)
    session.commit()

    return ValidationResponse(
        status=result.status,
        validated_at=record.validated_at,
        report=result.report,
    )


@router.post("/{name}/versions/{version}/package", response_model=PackageResponse)
def package_skill_version(
    name: str, version: str, session: Session = Depends(get_session)
) -> PackageResponse:
    skill = _get_skill_or_404(session, name)
    record = _get_version_or_404(session, skill.id, version)

    skill_root = Path(record.storage_path)
    if not skill_root.exists():
        raise HTTPException(status_code=404, detail="skill files not found")

    package_dir = settings.storage_dir / "packages" / name
    package_path = package_skill(skill_root, package_dir, name, version)

    record.package_path = str(package_path)
    record.updated_at = utcnow()
    session.add(record)
    session.commit()

    return PackageResponse(package_path=package_path.name, created_at=record.updated_at)


@router.get("/{name}/versions/{version}/package")
def download_package(
    name: str, version: str, session: Session = Depends(get_session)
):
    skill = _get_skill_or_404(session, name)
    record = _get_version_or_404(session, skill.id, version)
    if not record.package_path:
        raise HTTPException(status_code=404, detail="package not found")

    package_path = Path(record.package_path)
    if not package_path.exists():
        raise HTTPException(status_code=404, detail="package file missing")

    return FileResponse(
        path=str(package_path),
        filename=package_path.name,
        media_type="application/zip",
    )

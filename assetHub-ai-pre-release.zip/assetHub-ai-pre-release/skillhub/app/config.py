from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import List


@dataclass(frozen=True)
class Settings:
    database_url: str
    storage_dir: Path
    cors_origins: List[str]
    port: int


def _parse_cors_origins(raw: str) -> List[str]:
    items = [item.strip() for item in raw.split(",") if item.strip()]
    return items or ["*"]


def get_settings() -> Settings:
    database_url = os.getenv("SKILLHUB_DATABASE_URL") or os.getenv("DATABASE_URL")
    if not database_url:
        database_url = "sqlite:///./skillhub.db"
    elif database_url.startswith("postgres://"):
        database_url = database_url.replace("postgres://", "postgresql+psycopg2://", 1)

    storage_dir = Path(os.getenv("SKILLHUB_STORAGE_DIR", "./skillhub-data")).resolve()
    cors_origins = _parse_cors_origins(os.getenv("SKILLHUB_CORS_ORIGINS", "*"))
    port = int(os.getenv("PORT", "8090"))

    return Settings(
        database_url=database_url,
        storage_dir=storage_dir,
        cors_origins=cors_origins,
        port=port,
    )


settings = get_settings()

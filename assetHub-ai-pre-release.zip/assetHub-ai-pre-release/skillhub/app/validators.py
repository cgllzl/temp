from __future__ import annotations

import importlib.util
import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from app.models import ValidationStatus


@dataclass
class ValidationResult:
    status: ValidationStatus
    report: Optional[Dict[str, Any]] = None


def _prepare_validation_root(
    skill_root: Path,
    expected_name: Optional[str],
) -> tuple[Path, Optional[Path]]:
    if not expected_name or skill_root.name == expected_name:
        return skill_root, None

    tmp_dir = Path(tempfile.mkdtemp(prefix="skillhub-validate-"))
    link_path = tmp_dir / expected_name
    try:
        link_path.symlink_to(skill_root, target_is_directory=True)
    except Exception:
        shutil.copytree(skill_root, link_path)
    return link_path, tmp_dir


def run_skills_ref_validate(
    skill_root: Path,
    expected_name: Optional[str] = None,
) -> ValidationResult:
    bin_name = os.getenv("SKILLS_REF_BIN", "skills-ref")
    executable = shutil.which(bin_name)
    command = None
    if executable:
        command = [executable]
    else:
        spec = importlib.util.find_spec("skills_ref.cli")
        if spec is not None:
            command = [sys.executable, "-m", "skills_ref.cli"]

    if not command:
        return ValidationResult(
            status=ValidationStatus.not_available,
            report={"error": f"{bin_name} not found in PATH and skills_ref.cli not available"},
        )

    temp_dir: Optional[Path] = None
    try:
        validation_root, temp_dir = _prepare_validation_root(skill_root, expected_name)
        timeout_sec = int(os.getenv("SKILLS_REF_TIMEOUT_SEC", "30"))
        completed = subprocess.run(
            [*command, "validate", str(validation_root)],
            capture_output=True,
            text=True,
            check=False,
            timeout=timeout_sec,
        )
    except subprocess.TimeoutExpired:
        return ValidationResult(
            status=ValidationStatus.failed,
            report={"error": "skills-ref validate timed out"},
        )
    except Exception as exc:  # noqa: BLE001
        return ValidationResult(
            status=ValidationStatus.failed,
            report={"error": f"validation failed to execute: {exc}"},
        )

    finally:
        if temp_dir is not None:
            shutil.rmtree(temp_dir, ignore_errors=True)

    status = ValidationStatus.passed if completed.returncode == 0 else ValidationStatus.failed
    report = {
        "exit_code": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }
    return ValidationResult(status=status, report=report)

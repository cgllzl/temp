from __future__ import annotations

from datetime import datetime
from typing import Any, List, Optional

from pydantic import BaseModel, Field

from app.models import SkillStatus, SkillType, ValidationStatus


class SkillListItem(BaseModel):
    name: str
    description: str
    type: SkillType
    status: SkillStatus
    latest_version: Optional[str]
    updated_at: datetime
    dependencies_count: int = 0
    resources_count: int = 0
    validation_status: ValidationStatus = ValidationStatus.not_validated


class SkillListResponse(BaseModel):
    items: List[SkillListItem]
    total: int
    page: int
    page_size: int


class SkillVersionRead(BaseModel):
    version: str
    directory_name: str
    dependencies: Optional[list] = None
    files_summary: Optional[dict] = None
    files_manifest: Optional[list] = None
    dependencies_count: int = 0
    resources_count: int = 0
    validation_status: ValidationStatus
    validated_at: Optional[datetime] = None
    validation_report: Optional[Any] = None
    package_available: bool = False
    created_at: datetime
    updated_at: datetime


class SkillDetail(BaseModel):
    name: str
    description: str
    type: SkillType
    status: SkillStatus
    latest_version: Optional[str]
    created_at: datetime
    updated_at: datetime
    versions: List[SkillVersionRead]


class SkillStatusUpdateRequest(BaseModel):
    status: SkillStatus


class UploadResponse(BaseModel):
    name: str
    version: str
    status: str
    warnings: List[str] = Field(default_factory=list)


class SkillCreateRequest(BaseModel):
    name: str
    description: str
    version: str = "0.1.0"
    type: SkillType = SkillType.custom
    dependencies: List[str] = Field(default_factory=list)


class SkillCreateResponse(BaseModel):
    name: str
    version: str
    status: str


class ValidationResponse(BaseModel):
    status: ValidationStatus
    validated_at: Optional[datetime] = None
    report: Optional[Any] = None


class PackageResponse(BaseModel):
    package_path: str
    created_at: datetime

from __future__ import annotations

import textwrap
from pathlib import Path
from typing import Iterable, List

import yaml

from app.models import SkillType


STANDARD_TEMPLATE_BODY = """
# {name}

## Overview
Describe what this skill does, when it should be used, and what it produces.

## Trigger
Explain the user intent or context that should activate this skill.

## Usage
Provide example prompts or step-by-step guidance for using the skill.

## Resources
List references, assets, or scripts that the skill relies on.
""".strip()

STANDARD_DIRECTORY_READMES = {
    "scripts": "Place executable scripts here. Describe inputs/outputs in each file.",
    "references": "Add reference documents, specs, or datasets here.",
    "assets": "Store images, configuration, or other supporting assets here.",
}


def render_skill_md(
    name: str,
    description: str,
    version: str,
    skill_type: SkillType,
    dependencies: Iterable[str] | None = None,
) -> str:
    metadata: dict = {
        "version": version,
        "type": skill_type.value,
    }
    deps = [item for item in (dependencies or []) if item]
    if deps:
        metadata["dependencies"] = deps

    frontmatter: dict = {
        "name": name,
        "description": description,
        "metadata": metadata,
    }

    yaml_text = yaml.safe_dump(frontmatter, sort_keys=False).strip()
    body = STANDARD_TEMPLATE_BODY.format(name=name)
    body = textwrap.dedent(body).strip()
    return f"---\n{yaml_text}\n---\n\n{body}\n"


def write_standard_skill(
    root: Path,
    name: str,
    description: str,
    version: str,
    skill_type: SkillType,
    dependencies: Iterable[str] | None = None,
) -> None:
    root.mkdir(parents=True, exist_ok=True)
    skill_md = root / "SKILL.md"
    skill_md.write_text(
        render_skill_md(
            name=name,
            description=description,
            version=version,
            skill_type=skill_type,
            dependencies=dependencies,
        ),
        encoding="utf-8",
    )

    for directory, readme in STANDARD_DIRECTORY_READMES.items():
        path = root / directory
        path.mkdir(parents=True, exist_ok=True)
        readme_path = path / "README.md"
        readme_path.write_text(readme + "\n", encoding="utf-8")

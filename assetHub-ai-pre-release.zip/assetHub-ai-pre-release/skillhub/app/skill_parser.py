from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, List, Optional

import yaml

from app.models import SkillType


NAME_RE = re.compile(r"^[a-z0-9-]{1,64}$")
DESCRIPTION_MAX_LENGTH = 500


@dataclass
class SkillMetadata:
    name: str
    description: str
    version: str
    dependencies: List[str]
    skill_type: SkillType


def _extract_frontmatter(text: str) -> dict:
    if not text.startswith("---"):
        raise ValueError("SKILL.md missing YAML frontmatter")

    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        raise ValueError("SKILL.md frontmatter must start with '---'")

    end_index = None
    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            end_index = idx
            break

    if end_index is None:
        raise ValueError("SKILL.md frontmatter not closed with '---'")

    yaml_text = "\n".join(lines[1:end_index])
    data = yaml.safe_load(yaml_text) or {}
    if not isinstance(data, dict):
        raise ValueError("SKILL.md frontmatter must be a YAML mapping")
    return data


def parse_skill_md(path: Path, directory_name: str) -> SkillMetadata:
    text = path.read_text(encoding="utf-8")
    data = _extract_frontmatter(text)

    name = data.get("name")
    description = data.get("description")
    metadata = data.get("metadata") or {}
    if not isinstance(metadata, dict):
        metadata = {}
    version = metadata.get("version") or data.get("version") or "0.1.0"
    dependencies = metadata.get("dependencies") or data.get("dependencies") or []
    raw_type = metadata.get("type") or data.get("type")

    if not isinstance(name, str) or not name:
        raise ValueError("SKILL.md missing required 'name'")
    if not NAME_RE.match(name):
        raise ValueError("name must be lowercase letters, numbers, or hyphens and <=64 chars")

    if directory_name != name:
        raise ValueError("directory name must match SKILL.md name")

    if not isinstance(description, str) or not description:
        raise ValueError("SKILL.md missing required 'description'")
    if len(description) > DESCRIPTION_MAX_LENGTH:
        raise ValueError(f"description must be <= {DESCRIPTION_MAX_LENGTH} characters")

    if not isinstance(dependencies, list) or not all(isinstance(d, str) for d in dependencies):
        raise ValueError("dependencies must be a list of strings")

    if raw_type:
        try:
            skill_type = SkillType(raw_type)
        except ValueError as exc:
            raise ValueError("invalid type value in SKILL.md") from exc
    else:
        skill_type = SkillType.custom

    return SkillMetadata(
        name=name,
        description=description,
        version=str(version),
        dependencies=dependencies,
        skill_type=skill_type,
    )


def update_skill_md_metadata(path: Path, updates: dict) -> None:
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        raise ValueError("SKILL.md missing YAML frontmatter")

    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        raise ValueError("SKILL.md frontmatter must start with '---'")

    end_index = None
    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            end_index = idx
            break

    if end_index is None:
        raise ValueError("SKILL.md frontmatter not closed with '---'")

    yaml_text = "\n".join(lines[1:end_index])
    data = yaml.safe_load(yaml_text) or {}
    if not isinstance(data, dict):
        raise ValueError("SKILL.md frontmatter must be a YAML mapping")

    metadata = data.get("metadata")
    if not isinstance(metadata, dict):
        metadata = {}

    metadata.update(updates)
    data["metadata"] = metadata

    new_yaml = yaml.safe_dump(data, sort_keys=False).strip()
    body_lines = lines[end_index + 1 :]
    new_text = "\n".join(["---", new_yaml, "---", *body_lines])
    if text.endswith("\n"):
        new_text += "\n"
    path.write_text(new_text, encoding="utf-8")

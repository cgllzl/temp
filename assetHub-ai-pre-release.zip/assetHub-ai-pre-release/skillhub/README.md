# SkillHub Backend (FastAPI)

This service provides a minimal backend for managing Agent Skills.

## Requirements

- Python 3.11+
- Postgres (shared with MCPJungle) or SQLite for local testing

## Configuration

Environment variables:

- `DATABASE_URL`: Postgres DSN shared with MCPJungle
- `SKILLHUB_DATABASE_URL`: optional override for SkillHub
- `SKILLHUB_STORAGE_DIR`: storage root for skill files (default `./skillhub-data`)
- `SKILLHUB_CORS_ORIGINS`: comma-separated list of allowed origins (default `*`)
- `PORT`: service port (default `8090`)
- `SKILLS_REF_BIN`: skills-ref CLI binary name/path (default `skills-ref`)
- `SKILLS_REF_TIMEOUT_SEC`: validation timeout seconds (default `30`)

Docker build args:

- `INSTALL_SKILLS_REF` (default `true`)
- `SKILLS_REF_PIP_PACKAGE` (default `skills-ref`)

## Run locally

```bash
cd skillhub
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

export DATABASE_URL=postgres://mcpjungle:mcpjungle@localhost:5432/mcpjungle
uvicorn app.main:app --reload --port 8090
```

## Notes

- The service creates its own tables in the shared Postgres database using SQLModel.
- Validation uses the `skills-ref` CLI if available in `PATH`.
- For local development, install it manually if needed: `pip install skills-ref` (or override with `SKILLS_REF_PIP_PACKAGE` in Docker builds).

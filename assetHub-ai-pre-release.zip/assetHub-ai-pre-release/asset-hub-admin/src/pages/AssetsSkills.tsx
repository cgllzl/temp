import {
  BookOutlined,
  DownloadOutlined,
  InboxOutlined,
  PlusOutlined,
  ReloadOutlined,
  UploadOutlined,
  EyeOutlined
} from "@ant-design/icons";
import {
  App,
  Button,
  Card,
  Form,
  Input,
  Modal,
  Select,
  Space,
  Table,
  Tag,
  Typography,
  Upload
} from "antd";
import type { UploadRequestOption } from "rc-upload/lib/interface";
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import EmptyState from "../components/EmptyState";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";
import skillhubApi, {
  SkillListItem,
  SkillStatus,
  ValidationStatus
} from "../services/skillhub";

const { Paragraph } = Typography;

const AssetsSkills = () => {
  const { t } = useI18n();
  const navigate = useNavigate();
  const { message } = App.useApp();

  const [skills, setSkills] = useState<SkillListItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [total, setTotal] = useState(0);

  const [statuses, setStatuses] = useState<SkillStatus[]>([]);
  const [validationStatuses, setValidationStatuses] = useState<ValidationStatus[]>([]);
  const [hasScripts, setHasScripts] = useState<boolean | undefined>(undefined);
  const [hasDependencies, setHasDependencies] = useState<boolean | undefined>(undefined);

  const [uploadOpen, setUploadOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [createForm] = Form.useForm();

  const loadSkills = async (nextPage = page, nextPageSize = pageSize) => {
    setLoading(true);
    try {
      const resp = await skillhubApi.listSkills({
        statuses,
        validationStatuses,
        hasScripts,
        hasDependencies,
        page: nextPage,
        pageSize: nextPageSize
      });
      setSkills(resp.items || []);
      setTotal(resp.total || 0);
      setPage(resp.page || nextPage);
      setPageSize(resp.page_size || nextPageSize);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadSkillsFailed")}: ${messageText}`);
    } finally {
      setLoading(false);
      setLoaded(true);
    }
  };

  useEffect(() => {
    loadSkills(1, pageSize);
  }, [statuses, validationStatuses, hasScripts, hasDependencies]);

  const formatDate = (value?: string | null) => {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString();
  };

  const renderStatusTag = (value: SkillStatus) => {
    const map: Record<SkillStatus, string> = {
      draft: "default",
      active: "green",
      deprecated: "orange",
      archived: "red"
    };
    return <Tag color={map[value] || "default"}>{t(`skill.status.${value}`)}</Tag>;
  };

  const renderValidationTag = (value: ValidationStatus) => {
    const map: Record<ValidationStatus, string> = {
      not_validated: "default",
      passed: "green",
      failed: "red",
      not_available: "orange"
    };
    return <Tag color={map[value] || "default"}>{t(`skill.validation.${value}`)}</Tag>;
  };

  const columns = useMemo(
    () => [
      {
        title: t("table.skill.name"),
        dataIndex: "name",
        key: "name",
        render: (value: string) => (
          <Button type="link" onClick={() => navigate(`/assets/skills/${encodeURIComponent(value)}`)}>
            {value}
          </Button>
        )
      },
      {
        title: t("table.skill.description"),
        dataIndex: "description",
        key: "description",
        width: 420,
        render: (value: string) =>
          value ? (
            <Paragraph
              style={{ marginBottom: 0 }}
              ellipsis={{
                rows: 2,
                tooltip: { title: value, overlayInnerStyle: { maxWidth: 640 } }
              }}
            >
              {value}
            </Paragraph>
          ) : (
            "-"
          )
      },
      {
        title: t("table.skill.status"),
        dataIndex: "status",
        key: "status",
        render: (value: SkillStatus) => renderStatusTag(value)
      },
      {
        title: t("table.skill.latestVersion"),
        dataIndex: "latest_version",
        key: "latest_version",
        render: (value: string | null | undefined) => value || "-"
      },
      {
        title: t("table.skill.dependencies"),
        dataIndex: "dependencies_count",
        key: "dependencies_count",
        render: (value: number) => value ?? 0
      },
      {
        title: t("table.skill.resources"),
        dataIndex: "resources_count",
        key: "resources_count",
        render: (value: number) => value ?? 0
      },
      {
        title: t("table.skill.validation"),
        dataIndex: "validation_status",
        key: "validation_status",
        render: (value: ValidationStatus) => renderValidationTag(value)
      },
      {
        title: t("table.skill.updatedAt"),
        dataIndex: "updated_at",
        key: "updated_at",
        render: (value: string) => formatDate(value)
      },
      {
        title: t("table.actions"),
        key: "actions",
        render: (_: unknown, record: SkillListItem) => (
          <Button
            size="small"
            icon={<EyeOutlined />}
            onClick={() => navigate(`/assets/skills/${encodeURIComponent(record.name)}`)}
          >
            {t("action.view")}
          </Button>
        )
      }
    ],
    [navigate, t]
  );

  const handleUpload = async (file: File) => {
    setUploading(true);
    try {
      const resp = await skillhubApi.uploadSkill(file);
      message.success(`${t("message.skillUploaded")}: ${resp.name}@${resp.version}`);
      setUploadOpen(false);
      loadSkills(1, pageSize);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.skillUploadFailed")}: ${messageText}`);
    } finally {
      setUploading(false);
    }
  };

  const handleCreate = async () => {
    try {
      const values = await createForm.validateFields();
      setCreating(true);
      const resp = await skillhubApi.createSkill({
        name: values.name,
        description: values.description,
        version: values.version,
        type: values.type,
        dependencies: values.dependencies || []
      });
      message.success(`${t("message.skillCreated")}: ${resp.name}@${resp.version}`);
      setCreateOpen(false);
      createForm.resetFields();
      loadSkills(1, pageSize);
      navigate(`/assets/skills/${encodeURIComponent(resp.name)}`);
    } catch (error) {
      if (error && typeof error === "object" && "errorFields" in (error as any)) {
        return;
      }
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.skillCreateFailed")}: ${messageText}`);
    } finally {
      setCreating(false);
    }
  };

  const handleDownloadTemplate = async () => {
    try {
      const blob = await skillhubApi.downloadTemplate();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "skill-template-standard.zip";
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      message.success(t("message.skillTemplateDownloaded"));
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.skillTemplateFailed")}: ${messageText}`);
    }
  };

  const uploadProps = {
    multiple: false,
    accept: ".zip",
    showUploadList: false,
    customRequest: (options: UploadRequestOption) => {
      const file = options.file as File;
      handleUpload(file)
        .then(() => options.onSuccess?.("ok"))
        .catch((error) => options.onError?.(error));
    }
  };

  const headerActions = (
    <Space>
      <Button icon={<ReloadOutlined />} onClick={() => loadSkills()}>
        {t("action.refresh")}
      </Button>
      <Button className="btn-gradient" icon={<PlusOutlined />} onClick={() => setCreateOpen(true)}>
        {t("action.createSkill")}
      </Button>
      <Button icon={<UploadOutlined />} onClick={() => setUploadOpen(true)}>
        {t("action.importSkill")}
      </Button>
      <Button icon={<DownloadOutlined />} onClick={handleDownloadTemplate}>
        {t("action.downloadSkillTemplate")}
      </Button>
      <Button icon={<BookOutlined />} onClick={() => navigate("/assets/skills/guide")}>
        {t("action.skillGuide")}
      </Button>
    </Space>
  );

  return (
    <div>
      <PageHeader title={t("page.skills.title")} subtitle={t("page.skills.subtitle")} actions={headerActions} />

      <Card style={{ marginBottom: 16 }}>
        <Space wrap size="middle">
          <Select
            mode="multiple"
            allowClear
            placeholder={t("filter.skill.status")}
            value={statuses}
            style={{ minWidth: 200 }}
            onChange={(value) => setStatuses(value as SkillStatus[])}
            options={[
              { label: t("skill.status.draft"), value: "draft" },
              { label: t("skill.status.active"), value: "active" },
              { label: t("skill.status.deprecated"), value: "deprecated" },
              { label: t("skill.status.archived"), value: "archived" }
            ]}
          />
          <Select
            mode="multiple"
            allowClear
            placeholder={t("filter.skill.validation")}
            value={validationStatuses}
            style={{ minWidth: 220 }}
            onChange={(value) => setValidationStatuses(value as ValidationStatus[])}
            options={[
              { label: t("skill.validation.not_validated"), value: "not_validated" },
              { label: t("skill.validation.passed"), value: "passed" },
              { label: t("skill.validation.failed"), value: "failed" },
              { label: t("skill.validation.not_available"), value: "not_available" }
            ]}
          />
          <Select
            allowClear
            placeholder={t("filter.skill.hasScripts")}
            style={{ minWidth: 180 }}
            value={hasScripts === undefined ? undefined : String(hasScripts)}
            onChange={(value) =>
              setHasScripts(value === "true" ? true : value === "false" ? false : undefined)
            }
            options={[
              { label: t("filter.yes"), value: "true" },
              { label: t("filter.no"), value: "false" }
            ]}
          />
          <Select
            allowClear
            placeholder={t("filter.skill.hasDependencies")}
            style={{ minWidth: 200 }}
            value={hasDependencies === undefined ? undefined : String(hasDependencies)}
            onChange={(value) =>
              setHasDependencies(value === "true" ? true : value === "false" ? false : undefined)
            }
            options={[
              { label: t("filter.yes"), value: "true" },
              { label: t("filter.no"), value: "false" }
            ]}
          />
        </Space>
      </Card>

      {loaded && total === 0 && !loading ? (
        <EmptyState
          title={t("page.skills.emptyTitle")}
          description={t("page.skills.emptyDesc")}
          actions={headerActions}
        />
      ) : (
        <Card>
          <Table
            rowKey="name"
            columns={columns}
            dataSource={skills}
            loading={loading}
            pagination={{
              current: page,
              pageSize,
              total,
              showSizeChanger: true,
              onChange: (nextPage, nextSize) => {
                setPage(nextPage);
                setPageSize(nextSize || 20);
                loadSkills(nextPage, nextSize || 20);
              }
            }}
          />
        </Card>
      )}

      <Modal
        title={t("modal.skill.upload.title")}
        open={uploadOpen}
        onCancel={() => setUploadOpen(false)}
        footer={null}
      >
        <Upload.Dragger {...uploadProps} disabled={uploading}>
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">{t("modal.skill.upload.hint")}</p>
          <p className="ant-upload-hint">{t("modal.skill.upload.support")}</p>
        </Upload.Dragger>
      </Modal>

      <Modal
        title={t("modal.skill.create.title")}
        open={createOpen}
        onCancel={() => {
          setCreateOpen(false);
          createForm.resetFields();
        }}
        onOk={handleCreate}
        confirmLoading={creating}
        okText={t("action.create")}
        cancelText={t("action.cancel")}
      >
        <Form
          form={createForm}
          layout="vertical"
          initialValues={{ type: "custom", version: "0.1.0", dependencies: [] }}
        >
          <Form.Item
            label={t("form.skill.name")}
            name="name"
            rules={[
              { required: true, message: t("form.skill.nameRequired") },
              { pattern: /^[a-z0-9-]{1,64}$/, message: t("form.skill.nameInvalid") }
            ]}
          >
            <Input placeholder="example-skill" />
          </Form.Item>
          <Form.Item
            label={t("form.skill.description")}
            name="description"
            rules={[{ required: true, message: t("form.skill.descriptionRequired") }]}
            extra={t("form.skill.descriptionHint")}
          >
            <Input.TextArea rows={3} showCount maxLength={500} placeholder={t("form.skill.descriptionPlaceholder")} />
          </Form.Item>
          <Form.Item label={t("form.skill.version")} name="version">
            <Input placeholder="0.1.0" />
          </Form.Item>
          <Form.Item label={t("form.skill.type")} name="type">
            <Select
              options={[
                { label: t("skill.type.custom"), value: "custom" },
                { label: t("skill.type.org-provisioned"), value: "org-provisioned" },
                { label: t("skill.type.partner"), value: "partner" },
                { label: t("skill.type.anthropic"), value: "anthropic" }
              ]}
            />
          </Form.Item>
          <Form.Item label={t("form.skill.dependencies")} name="dependencies">
            <Select
              mode="tags"
              tokenSeparators={[",", " "]}
              placeholder="python>=3.11, node>=20"
            />
          </Form.Item>
          <div style={{ fontSize: 12, color: "var(--muted-foreground)" }}>
            {t("form.skill.standardTemplateHint")}
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default AssetsSkills;

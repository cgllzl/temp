import { Button, Card, Col, Row, Space, Tabs, Tag, Typography } from "antd";
import { useMemo } from "react";
import { useParams } from "react-router-dom";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";

const { Text } = Typography;

const AssetDetail = () => {
  const { type, id } = useParams();
  const { t } = useI18n();

  const title = useMemo(() => {
    if (!type || !id) return t("assetDetail.title");
    const typeKeyMap: Record<string, string> = {
      mcp: "assetType.mcp",
      skills: "assetType.skill",
      prompts: "assetType.prompt",
      agents: "assetType.agent"
    };
    const typeLabel = typeKeyMap[type] ? t(typeKeyMap[type]) : type.toUpperCase();
    return `${typeLabel} / ${id}`;
  }, [id, t, type]);

  return (
    <div>
      <PageHeader
        title={title}
        subtitle={t("assetDetail.subtitle")}
        actions={
          <Space>
            <Button>{t("action.archive")}</Button>
            <Button className="btn-gradient">{t("action.newVersion")}</Button>
          </Space>
        }
      />
      <Row gutter={[16, 16]}>
        <Col xs={24} lg={8}>
          <Card title={t("assetDetail.summary")}>
            <div style={{ display: "grid", gap: 12 }}>
              <div>
                <Text type="secondary">{t("assetDetail.field.status")}</Text>
                <div>
                  <Tag color="green">{t("status.active")}</Tag>
                </div>
              </div>
              <div>
                <Text type="secondary">{t("assetDetail.field.owner")}</Text>
                <div>Platform Team</div>
              </div>
              <div>
                <Text type="secondary">{t("assetDetail.field.latestVersion")}</Text>
                <div>v1.12.0</div>
              </div>
              <div>
                <Text type="secondary">{t("assetDetail.field.lastUpdated")}</Text>
                <div>2026-03-18</div>
              </div>
            </div>
          </Card>
        </Col>
        <Col xs={24} lg={16}>
          <Card>
            <Tabs
              items={[
                {
                  key: "overview",
                  label: t("assetDetail.tab.overview"),
                  children: t("assetDetail.tab.overview.content")
                },
                {
                  key: "versions",
                  label: t("assetDetail.tab.versions"),
                  children: t("assetDetail.tab.versions.content")
                },
                {
                  key: "dependencies",
                  label: t("assetDetail.tab.dependencies"),
                  children: t("assetDetail.tab.dependencies.content")
                },
                { key: "access", label: t("assetDetail.tab.access"), children: t("assetDetail.tab.access.content") },
                { key: "audit", label: t("assetDetail.tab.audit"), children: t("assetDetail.tab.audit.content") }
              ]}
            />
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default AssetDetail;

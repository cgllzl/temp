import { Tabs } from "antd";
import { useMemo } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";
import RegistryServers from "./RegistryServers";
import RegistryTools from "./RegistryTools";
import RegistryToolGroups from "./RegistryToolGroups";

const AssetsMcp = () => {
  const { t } = useI18n();
  const location = useLocation();
  const navigate = useNavigate();

  const activeTab = useMemo(() => {
    const params = new URLSearchParams(location.search);
    const tab = params.get("tab");
    if (tab === "tools" || tab === "toolGroups" || tab === "servers") return tab;
    return "servers";
  }, [location.search]);

  const handleTabChange = (key: string) => {
    const next = key === "servers" ? "/assets/mcp" : `/assets/mcp?tab=${key}`;
    navigate(next);
  };

  return (
    <div>
      <PageHeader title={t("page.mcp.title")} subtitle={t("page.mcp.subtitle")} />
      <Tabs
        activeKey={activeTab}
        onChange={handleTabChange}
        items={[
          {
            key: "servers",
            label: t("menu.assets.mcpServers"),
            children: <RegistryServers embedded />
          },
          {
            key: "tools",
            label: t("menu.assets.mcpTools"),
            children: <RegistryTools embedded />
          },
          {
            key: "toolGroups",
            label: t("menu.assets.mcpToolGroups"),
            children: <RegistryToolGroups embedded />
          }
        ]}
      />
    </div>
  );
};

export default AssetsMcp;

import PlaceholderPage from "../components/PlaceholderPage";
import { useI18n } from "../i18n";

const SystemAudit = () => {
  const { t } = useI18n();
  return (
    <PlaceholderPage
      title={t("page.system.audit.title")}
      subtitle={t("page.system.audit.subtitle")}
      emptyTitle={t("page.system.audit.emptyTitle")}
      emptyDescription={t("page.system.audit.emptyDesc")}
    />
  );
};

export default SystemAudit;

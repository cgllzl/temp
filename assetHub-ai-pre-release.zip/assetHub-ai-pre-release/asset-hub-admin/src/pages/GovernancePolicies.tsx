import { Button } from "antd";
import PlaceholderPage from "../components/PlaceholderPage";
import { useI18n } from "../i18n";

const GovernancePolicies = () => {
  const { t } = useI18n();
  return (
    <PlaceholderPage
      title={t("page.governance.policies.title")}
      subtitle={t("page.governance.policies.subtitle")}
      emptyTitle={t("page.governance.policies.emptyTitle")}
      emptyDescription={t("page.governance.policies.emptyDesc")}
      actions={<Button className="btn-gradient">{t("action.createPolicy")}</Button>}
    />
  );
};

export default GovernancePolicies;

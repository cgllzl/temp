import { App, Button, Card, Col, Row, Space, Spin, Typography } from "antd";
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import PageHeader from "../components/PageHeader";
import StatCard from "../components/StatCard";
import { useI18n } from "../i18n";
import api from "../services/mcpjungle";

const { Text } = Typography;

type McpStats = {
  servers: number;
  tools: number;
  prompts: number;
  toolGroups: number;
};

const AssetsMcpOverview = () => {
  const { t } = useI18n();
  const { message } = App.useApp();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState<McpStats>({ servers: 0, tools: 0, prompts: 0, toolGroups: 0 });

  const loadStats = async () => {
    setLoading(true);
    try {
      const [servers, tools, prompts, toolGroups] = await Promise.all([
        api.listServers(),
        api.listTools(),
        api.listPrompts(),
        api.listToolGroups()
      ]);
      setStats({
        servers: Array.isArray(servers) ? servers.length : 0,
        tools: Array.isArray(tools) ? tools.length : 0,
        prompts: Array.isArray(prompts) ? prompts.length : 0,
        toolGroups: Array.isArray(toolGroups) ? toolGroups.length : 0
      });
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadMcpStatsFailed")}: ${messageText}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, []);

  const cards = useMemo(
    () => [
      { label: t("stat.mcp.servers"), value: String(stats.servers) },
      { label: t("stat.mcp.tools"), value: String(stats.tools) },
      { label: t("stat.mcp.prompts"), value: String(stats.prompts) },
      { label: t("stat.mcp.toolGroups"), value: String(stats.toolGroups) }
    ],
    [stats, t]
  );

  return (
    <div>
      <PageHeader
        title={t("page.mcp.overview.title")}
        subtitle={t("page.mcp.overview.subtitle")}
        actions={
          <Space>
            <Button onClick={loadStats}>{t("action.refresh")}</Button>
            <Button className="btn-gradient" onClick={() => navigate("/assets/mcp/servers")}>
              {t("action.openServers")}
            </Button>
          </Space>
        }
      />

      <Card style={{ marginBottom: 20 }}>
        <Spin spinning={loading}>
          <Row gutter={[16, 16]}>
            {cards.map((card) => (
              <Col xs={24} md={12} lg={6} key={card.label}>
                <StatCard label={card.label} value={card.value} />
              </Col>
            ))}
          </Row>
        </Spin>
      </Card>

      <Row gutter={[16, 16]}>
        <Col xs={24} lg={16}>
          <Card title={t("section.mcp.entry.title")}>
            <Space wrap>
              <Button className="btn-gradient" onClick={() => navigate("/assets/mcp/servers")}>
                {t("action.openServers")}
              </Button>
              <Button onClick={() => navigate("/assets/mcp/tools")}>{t("action.openTools")}</Button>
              <Button onClick={() => navigate("/assets/mcp/tool-groups")}>{t("action.openToolGroups")}</Button>
            </Space>
            <div style={{ marginTop: 12 }}>
              <Text type="secondary">{t("hint.mcp.prompts")}</Text>
            </div>
          </Card>
        </Col>
        <Col xs={24} lg={8}>
          <Card title={t("section.mcp.note.title")}>
            <Text type="secondary">{t("section.mcp.note.body")}</Text>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default AssetsMcpOverview;

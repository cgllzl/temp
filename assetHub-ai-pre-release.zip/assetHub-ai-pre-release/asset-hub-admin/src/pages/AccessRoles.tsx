import { Button } from "antd";
import PlaceholderPage from "../components/PlaceholderPage";
import { useI18n } from "../i18n";

const AccessRoles = () => {
  const { t } = useI18n();
  return (
    <PlaceholderPage
      title={t("page.access.roles.title")}
      subtitle={t("page.access.roles.subtitle")}
      emptyTitle={t("page.access.roles.emptyTitle")}
      emptyDescription={t("page.access.roles.emptyDesc")}
      actions={<Button className="btn-gradient">{t("action.createRole")}</Button>}
    />
  );
};

export default AccessRoles;

import { LockOutlined, UserOutlined } from "@ant-design/icons";
import { App, Button, Card, Form, Input, Space, Typography } from "antd";
import { useState } from "react";
import authApi from "../services/uiauth";

const { Title, Text } = Typography;

type Props = {
  onSuccess: () => void;
};

const Login = ({ onSuccess }: Props) => {
  const { message } = App.useApp();
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (values: { email: string; password: string }) => {
    setLoading(true);
    try {
      await authApi.signIn(values);
      message.success("登录成功");
      onSuccess();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(messageText || "登录失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <Card style={{ width: 420 }}>
        <Space direction="vertical" size={16} style={{ width: "100%" }}>
          <Title level={3} style={{ marginBottom: 0 }}>
            AssetHub 登录
          </Title>
          <Text type="secondary">使用管理员账号登录后继续。</Text>
          <Form layout="vertical" onFinish={handleSubmit} requiredMark={false}>
            <Form.Item
              label="邮箱"
              name="email"
              rules={[{ required: true, message: "请输入邮箱" }]}
            >
              <Input prefix={<UserOutlined />} placeholder="admin@example.com" />
            </Form.Item>
            <Form.Item
              label="密码"
              name="password"
              rules={[{ required: true, message: "请输入密码" }]}
            >
              <Input.Password prefix={<LockOutlined />} placeholder="******" />
            </Form.Item>
            <Button type="primary" htmlType="submit" block loading={loading}>
              登录
            </Button>
          </Form>
        </Space>
      </Card>
    </div>
  );
};

export default Login;

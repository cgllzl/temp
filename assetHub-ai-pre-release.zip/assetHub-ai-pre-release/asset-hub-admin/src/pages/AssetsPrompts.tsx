import { Button } from "antd";
import PlaceholderPage from "../components/PlaceholderPage";
import { useI18n } from "../i18n";

const AssetsPrompts = () => {
  const { t } = useI18n();
  return (
    <PlaceholderPage
      title={t("page.prompts.title")}
      subtitle={t("page.prompts.subtitle")}
      emptyTitle={t("page.prompts.emptyTitle")}
      emptyDescription={t("page.prompts.emptyDesc")}
      actions={<Button className="btn-gradient">{t("action.addPrompt")}</Button>}
    />
  );
};

export default AssetsPrompts;

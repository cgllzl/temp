import {
  EyeOutlined,
  PlayCircleOutlined,
  ReloadOutlined,
  RollbackOutlined
} from "@ant-design/icons";
import {
  App,
  Button,
  Card,
  Descriptions,
  Drawer,
  Input,
  Modal,
  Space,
  Spin,
  Table,
  Tabs,
  Tag,
  Typography
} from "antd";
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";
import api, { McpPrompt, McpServer, McpTool, PromptResult, ToolInvokeResult } from "../services/mcpjungle";
import { parseJson, splitEntityName, toPrettyJson } from "../utils/mcp";

const { Text } = Typography;

const RegistryServerDetail = () => {
  const { t } = useI18n();
  const navigate = useNavigate();
  const { message } = App.useApp();
  const params = useParams();
  const serverName = useMemo(() => (params.name ? decodeURIComponent(params.name) : ""), [params.name]);

  const [server, setServer] = useState<McpServer | null>(null);
  const [loadingServer, setLoadingServer] = useState(false);

  const [tools, setTools] = useState<McpTool[]>([]);
  const [loadingTools, setLoadingTools] = useState(false);

  const [prompts, setPrompts] = useState<McpPrompt[]>([]);
  const [loadingPrompts, setLoadingPrompts] = useState(false);

  const [toolDetailOpen, setToolDetailOpen] = useState(false);
  const [toolDetailLoading, setToolDetailLoading] = useState(false);
  const [toolDetail, setToolDetail] = useState<McpTool | null>(null);

  const [promptDetailOpen, setPromptDetailOpen] = useState(false);
  const [promptDetailLoading, setPromptDetailLoading] = useState(false);
  const [promptDetail, setPromptDetail] = useState<McpPrompt | null>(null);

  const [invokeOpen, setInvokeOpen] = useState(false);
  const [invokeLoading, setInvokeLoading] = useState(false);
  const [invokePayload, setInvokePayload] = useState("{}");
  const [invokeResult, setInvokeResult] = useState<ToolInvokeResult | null>(null);

  const [renderOpen, setRenderOpen] = useState(false);
  const [renderLoading, setRenderLoading] = useState(false);
  const [renderPayload, setRenderPayload] = useState("{}");
  const [renderResult, setRenderResult] = useState<PromptResult | null>(null);

  const loadServer = async () => {
    if (!serverName) return;
    setLoadingServer(true);
    try {
      const data = await api.listServers();
      const found = Array.isArray(data) ? data.find((item) => item.name === serverName) : null;
      setServer(found || null);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadServerFailed")}: ${messageText}`);
    } finally {
      setLoadingServer(false);
    }
  };

  const loadTools = async () => {
    if (!serverName) return;
    setLoadingTools(true);
    try {
      const data = await api.listTools(serverName);
      setTools(Array.isArray(data) ? data : []);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadToolsFailed")}: ${messageText}`);
    } finally {
      setLoadingTools(false);
    }
  };

  const loadPrompts = async () => {
    if (!serverName) return;
    setLoadingPrompts(true);
    try {
      const data = await api.listPrompts(serverName);
      setPrompts(Array.isArray(data) ? data : []);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadPromptsFailed")}: ${messageText}`);
    } finally {
      setLoadingPrompts(false);
    }
  };

  const loadAll = () => {
    loadServer();
    loadTools();
    loadPrompts();
  };

  useEffect(() => {
    loadAll();
  }, [serverName]);

  const openToolDetail = async (record: McpTool) => {
    setToolDetailOpen(true);
    setToolDetailLoading(true);
    setToolDetail(null);
    try {
      const detail = await api.getTool(record.name);
      setToolDetail(detail);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadToolDetailFailed")}: ${messageText}`);
    } finally {
      setToolDetailLoading(false);
    }
  };

  const openPromptDetail = async (record: McpPrompt) => {
    setPromptDetailOpen(true);
    setPromptDetailLoading(true);
    setPromptDetail(null);
    try {
      const detail = await api.getPrompt(record.name);
      setPromptDetail(detail);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadPromptDetailFailed")}: ${messageText}`);
    } finally {
      setPromptDetailLoading(false);
    }
  };

  const handleToggleTool = async (record: McpTool, nextEnabled: boolean) => {
    try {
      if (nextEnabled) {
        await api.enableTools(record.name);
        message.success(t("message.toolEnabled"));
      } else {
        await api.disableTools(record.name);
        message.success(t("message.toolDisabled"));
      }
      loadTools();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.toolActionFailed")}: ${messageText}`);
    }
  };

  const handleTogglePrompt = async (record: McpPrompt, nextEnabled: boolean) => {
    try {
      if (nextEnabled) {
        await api.enablePrompts(record.name);
        message.success(t("message.promptEnabled"));
      } else {
        await api.disablePrompts(record.name);
        message.success(t("message.promptDisabled"));
      }
      loadPrompts();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.promptActionFailed")}: ${messageText}`);
    }
  };

  const handleInvoke = async () => {
    if (!toolDetail) return;
    const parsed = parseJson<Record<string, any>>(invokePayload);
    if (!parsed.ok) {
      message.error(`${t("message.invalidJson")}: ${parsed.error}`);
      return;
    }
    setInvokeLoading(true);
    try {
      const result = await api.invokeTool(toolDetail.name, parsed.value || {});
      setInvokeResult(result);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.toolInvokeFailed")}: ${messageText}`);
    } finally {
      setInvokeLoading(false);
    }
  };

  const handleRender = async () => {
    if (!promptDetail) return;
    const parsed = parseJson<Record<string, string>>(renderPayload);
    if (!parsed.ok) {
      message.error(`${t("message.invalidJson")}: ${parsed.error}`);
      return;
    }
    setRenderLoading(true);
    try {
      const result = await api.renderPrompt(promptDetail.name, parsed.value || {});
      setRenderResult(result);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.promptRenderFailed")}: ${messageText}`);
    } finally {
      setRenderLoading(false);
    }
  };

  const toolColumns = useMemo(
    () => [
      {
        title: t("table.tool.name"),
        dataIndex: "name",
        key: "name",
        render: (value: string) => splitEntityName(value).local
      },
      {
        title: t("table.tool.fullName"),
        dataIndex: "name",
        key: "fullName",
        render: (value: string) => <Text type="secondary">{value}</Text>
      },
      {
        title: t("table.tool.status"),
        dataIndex: "enabled",
        key: "enabled",
        render: (value: boolean) =>
          value ? <Tag color="green">{t("status.enabled")}</Tag> : <Tag>{t("status.disabled")}</Tag>
      },
      {
        title: t("table.tool.description"),
        dataIndex: "description",
        key: "description",
        render: (value: string | undefined) => value || "-"
      },
      {
        title: t("table.actions"),
        key: "actions",
        render: (_: unknown, record: McpTool) => (
          <Space>
            <Button size="small" icon={<EyeOutlined />} onClick={() => openToolDetail(record)}>
              {t("action.view")}
            </Button>
            <Button
              size="small"
              icon={<PlayCircleOutlined />}
              onClick={() => {
                setToolDetail(record);
                setInvokeResult(null);
                setInvokePayload("{}");
                setInvokeOpen(true);
              }}
            >
              {t("action.invoke")}
            </Button>
            <Button
              size="small"
              onClick={() => handleToggleTool(record, !record.enabled)}
              type={record.enabled ? "default" : "primary"}
            >
              {record.enabled ? t("action.disable") : t("action.enable")}
            </Button>
          </Space>
        )
      }
    ],
    [t]
  );

  const promptColumns = useMemo(
    () => [
      {
        title: t("table.prompt.name"),
        dataIndex: "name",
        key: "name",
        render: (value: string) => splitEntityName(value).local
      },
      {
        title: t("table.prompt.fullName"),
        dataIndex: "name",
        key: "fullName",
        render: (value: string) => <Text type="secondary">{value}</Text>
      },
      {
        title: t("table.prompt.status"),
        dataIndex: "enabled",
        key: "enabled",
        render: (value: boolean) =>
          value ? <Tag color="green">{t("status.enabled")}</Tag> : <Tag>{t("status.disabled")}</Tag>
      },
      {
        title: t("table.prompt.description"),
        dataIndex: "description",
        key: "description",
        render: (value: string | undefined) => value || "-"
      },
      {
        title: t("table.actions"),
        key: "actions",
        render: (_: unknown, record: McpPrompt) => (
          <Space>
            <Button size="small" icon={<EyeOutlined />} onClick={() => openPromptDetail(record)}>
              {t("action.view")}
            </Button>
            <Button
              size="small"
              icon={<PlayCircleOutlined />}
              onClick={() => {
                setPromptDetail(record);
                setRenderResult(null);
                setRenderPayload("{}");
                setRenderOpen(true);
              }}
            >
              {t("action.render")}
            </Button>
            <Button
              size="small"
              onClick={() => handleTogglePrompt(record, !record.enabled)}
              type={record.enabled ? "default" : "primary"}
            >
              {record.enabled ? t("action.disable") : t("action.enable")}
            </Button>
          </Space>
        )
      }
    ],
    [t]
  );

  return (
    <div>
      <PageHeader
        title={serverName || t("page.registry.serverDetail.title")}
        subtitle={t("page.registry.serverDetail.subtitle")}
        actions={
          <Space>
            <Button icon={<ReloadOutlined />} onClick={loadAll}>
              {t("action.refresh")}
            </Button>
            <Button icon={<RollbackOutlined />} onClick={() => navigate("/assets/mcp?tab=servers")}>
              {t("action.backToServers")}
            </Button>
          </Space>
        }
      />

      <Card style={{ marginBottom: 16 }}>
        <Spin spinning={loadingServer}>
          {server ? (
            <Descriptions column={2} size="small">
              <Descriptions.Item label={t("table.server.name")}>{server.name}</Descriptions.Item>
              <Descriptions.Item label={t("table.server.transport")}>{server.transport}</Descriptions.Item>
              <Descriptions.Item label={t("table.server.endpoint")}>
                {server.url || server.command || "-"}
              </Descriptions.Item>
              <Descriptions.Item label={t("table.server.sessionMode")}>
                {server.session_mode || "-"}
              </Descriptions.Item>
              <Descriptions.Item label={t("table.server.status")}>
                {server.enabled === undefined ? (
                  "-"
                ) : server.enabled ? (
                  <Tag color="green">{t("status.enabled")}</Tag>
                ) : (
                  <Tag>{t("status.disabled")}</Tag>
                )}
              </Descriptions.Item>
              <Descriptions.Item label={t("table.server.description")}>
                {server.description || "-"}
              </Descriptions.Item>
              <Descriptions.Item label={t("table.server.toolsCount")}>{tools.length}</Descriptions.Item>
              <Descriptions.Item label={t("table.server.promptsCount")}>{prompts.length}</Descriptions.Item>
            </Descriptions>
          ) : (
            <Text type="secondary">{t("empty.serverNotFound")}</Text>
          )}
        </Spin>
      </Card>

      <Card>
        <Tabs
          items={[
            {
              key: "overview",
              label: t("tab.overview"),
              children: (
                <div style={{ display: "grid", gap: 12 }}>
                  <Text type="secondary">{t("page.registry.serverDetail.overview")}</Text>
                </div>
              )
            },
            {
              key: "tools",
              label: t("tab.tools"),
              children: (
                <Table rowKey="name" columns={toolColumns} dataSource={tools} loading={loadingTools} />
              )
            },
            {
              key: "prompts",
              label: t("tab.prompts"),
              children: (
                <Table rowKey="name" columns={promptColumns} dataSource={prompts} loading={loadingPrompts} />
              )
            },
            {
              key: "config",
              label: t("tab.config"),
              children: (
                <pre style={{ margin: 0, background: "#f8fafc", padding: 16, borderRadius: 12 }}>
                  {toPrettyJson(server ?? {})}
                </pre>
              )
            }
          ]}
        />
      </Card>

      <Drawer
        title={t("drawer.tool.title")}
        open={toolDetailOpen}
        onClose={() => setToolDetailOpen(false)}
        width={520}
      >
        <Spin spinning={toolDetailLoading}>
          {toolDetail ? (
            <div style={{ display: "grid", gap: 12 }}>
              <div>
                <Text type="secondary">{t("table.tool.fullName")}</Text>
                <div>{toolDetail.name}</div>
              </div>
              <div>
                <Text type="secondary">{t("table.tool.status")}</Text>
                <div>
                  {toolDetail.enabled ? <Tag color="green">{t("status.enabled")}</Tag> : <Tag>{t("status.disabled")}</Tag>}
                </div>
              </div>
              <div>
                <Text type="secondary">{t("table.tool.description")}</Text>
                <div>{toolDetail.description || "-"}</div>
              </div>
              <div>
                <Text type="secondary">{t("table.tool.inputSchema")}</Text>
                <pre style={{ margin: 0, background: "#f8fafc", padding: 12, borderRadius: 12 }}>
                  {toPrettyJson(toolDetail.input_schema ?? {})}
                </pre>
              </div>
              <div>
                <Text type="secondary">{t("table.tool.annotations")}</Text>
                <pre style={{ margin: 0, background: "#f8fafc", padding: 12, borderRadius: 12 }}>
                  {toPrettyJson(toolDetail.annotations ?? {})}
                </pre>
              </div>
            </div>
          ) : (
            <Text type="secondary">{t("empty.noToolDetail")}</Text>
          )}
        </Spin>
      </Drawer>

      <Modal
        title={t("modal.tool.invoke.title")}
        open={invokeOpen}
        onCancel={() => setInvokeOpen(false)}
        onOk={handleInvoke}
        confirmLoading={invokeLoading}
        okText={t("action.invoke")}
        cancelText={t("action.cancel")}
      >
        <div style={{ display: "grid", gap: 12 }}>
          <Text type="secondary">{toolDetail?.name}</Text>
          <Input.TextArea
            rows={6}
            value={invokePayload}
            onChange={(event) => setInvokePayload(event.target.value)}
            placeholder='{"input":"value"}'
          />
          {invokeResult && (
            <pre style={{ margin: 0, background: "#f8fafc", padding: 12, borderRadius: 12 }}>
              {toPrettyJson(invokeResult)}
            </pre>
          )}
        </div>
      </Modal>

      <Drawer
        title={t("drawer.prompt.title")}
        open={promptDetailOpen}
        onClose={() => setPromptDetailOpen(false)}
        width={520}
      >
        <Spin spinning={promptDetailLoading}>
          {promptDetail ? (
            <div style={{ display: "grid", gap: 12 }}>
              <div>
                <Text type="secondary">{t("table.prompt.fullName")}</Text>
                <div>{promptDetail.name}</div>
              </div>
              <div>
                <Text type="secondary">{t("table.prompt.status")}</Text>
                <div>
                  {promptDetail.enabled ? <Tag color="green">{t("status.enabled")}</Tag> : <Tag>{t("status.disabled")}</Tag>}
                </div>
              </div>
              <div>
                <Text type="secondary">{t("table.prompt.description")}</Text>
                <div>{promptDetail.description || "-"}</div>
              </div>
              <div>
                <Text type="secondary">{t("table.prompt.arguments")}</Text>
                <pre style={{ margin: 0, background: "#f8fafc", padding: 12, borderRadius: 12 }}>
                  {toPrettyJson(promptDetail.arguments ?? {})}
                </pre>
              </div>
            </div>
          ) : (
            <Text type="secondary">{t("empty.noPromptDetail")}</Text>
          )}
        </Spin>
      </Drawer>

      <Modal
        title={t("modal.prompt.render.title")}
        open={renderOpen}
        onCancel={() => setRenderOpen(false)}
        onOk={handleRender}
        confirmLoading={renderLoading}
        okText={t("action.render")}
        cancelText={t("action.cancel")}
      >
        <div style={{ display: "grid", gap: 12 }}>
          <Text type="secondary">{promptDetail?.name}</Text>
          <Input.TextArea
            rows={6}
            value={renderPayload}
            onChange={(event) => setRenderPayload(event.target.value)}
            placeholder='{"name":"value"}'
          />
          {renderResult && (
            <pre style={{ margin: 0, background: "#f8fafc", padding: 12, borderRadius: 12 }}>
              {toPrettyJson(renderResult)}
            </pre>
          )}
        </div>
      </Modal>
    </div>
  );
};

export default RegistryServerDetail;

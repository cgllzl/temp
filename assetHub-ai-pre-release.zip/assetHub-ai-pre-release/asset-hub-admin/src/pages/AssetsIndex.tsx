import { App, Card, Col, Row } from "antd";
import { useEffect, useState } from "react";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";
import agenthubApi from "../services/agenthub";
import mcpApi from "../services/mcpjungle";
import skillhubApi from "../services/skillhub";

const AssetsIndex = () => {
  const { t } = useI18n();
  const { message } = App.useApp();
  const [mcpCount, setMcpCount] = useState<string>("—");
  const [skillCount, setSkillCount] = useState<string>("—");
  const [agentCount, setAgentCount] = useState<string>("—");

  useEffect(() => {
    const loadMcp = async () => {
      try {
        const servers = await mcpApi.listServers();
        const count = Array.isArray(servers) ? servers.length : 0;
        setMcpCount(String(count));
      } catch (error) {
        const messageText = error instanceof Error ? error.message : String(error);
        message.error(`${t("message.loadMcpStatsFailed")}: ${messageText}`);
        setMcpCount("—");
      }
    };
    const loadSkills = async () => {
      try {
        const response = await skillhubApi.listSkills({ page: 1, pageSize: 1 });
        const total = typeof response?.total === "number" ? response.total : 0;
        setSkillCount(String(total));
      } catch (error) {
        const messageText = error instanceof Error ? error.message : String(error);
        message.error(`${t("message.loadSkillsFailed")}: ${messageText}`);
        setSkillCount("—");
      }
    };
    const loadAgents = async () => {
      try {
        const response = await agenthubApi.listAgents({ page: 1, pageSize: 1 });
        const total = typeof response?.total === "number" ? response.total : 0;
        setAgentCount(String(total));
      } catch (error) {
        const messageText = error instanceof Error ? error.message : String(error);
        message.error(`${t("message.loadAgentsFailed")}: ${messageText}`);
        setAgentCount("—");
      }
    };
    loadMcp();
    loadSkills();
    loadAgents();
  }, [message, t]);

  const assetCards = [
    { title: t("assets.card.mcpServers"), count: mcpCount },
    { title: t("assets.card.skills"), count: skillCount },
    { title: t("assets.card.prompts"), count: "98" },
    { title: t("assets.card.agents"), count: agentCount }
  ];

  return (
    <div>
      <PageHeader
        title={t("page.assets.title")}
        subtitle={t("page.assets.subtitle")}
      />
      <Row gutter={[16, 16]}>
        {assetCards.map((card) => (
          <Col xs={24} md={12} lg={6} key={card.title}>
            <div className="gradient-border">
              <div className="gradient-border-inner" style={{ padding: 16 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div style={{ fontWeight: 600 }}>{card.title}</div>
                </div>
                <div style={{ fontSize: 28, fontWeight: 600, marginTop: 12 }}>{card.count}</div>
                <div style={{ color: "var(--muted-foreground)", fontSize: 12 }}>{t("assets.lastUpdated")}</div>
              </div>
            </div>
          </Col>
        ))}
      </Row>
      <Card style={{ marginTop: 20 }}>
        <div style={{ color: "var(--muted-foreground)" }}>{t("assets.tip")}</div>
      </Card>
    </div>
  );
};

export default AssetsIndex;

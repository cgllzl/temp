import {
  CheckCircleOutlined,
  CloseCircleOutlined,
  PlusOutlined,
  ReloadOutlined,
  RocketOutlined,
  StopOutlined
} from "@ant-design/icons";
import {
  App,
  Button,
  Card,
  Form,
  Input,
  Modal,
  Select,
  Space,
  Switch,
  Table,
  Tag,
  Typography
} from "antd";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import EmptyState from "../components/EmptyState";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";
import agenthubApi, { AgentCreatePayload, AgentListItem, AgentStatus } from "../services/agenthub";
import mcpApi, { McpServer, McpTool } from "../services/mcpjungle";

const { Paragraph, Text } = Typography;

const statusColors: Record<AgentStatus, string> = {
  draft: "default",
  in_review: "orange",
  published: "green",
  unpublished: "red",
  archived: "default"
};

const AssetsAgents = () => {
  const { t } = useI18n();
  const { message } = App.useApp();

  const [agents, setAgents] = useState<AgentListItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [total, setTotal] = useState(0);
  const [statuses, setStatuses] = useState<AgentStatus[]>([]);

  const [createOpen, setCreateOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [createForm] = Form.useForm();
  const [useZh, setUseZh] = useState(false);
  const [mcpLoading, setMcpLoading] = useState(false);
  const [mcpServers, setMcpServers] = useState<McpServer[]>([]);
  const [mcpTools, setMcpTools] = useState<McpTool[]>([]);

  const loadAgents = async (nextPage = page, nextPageSize = pageSize) => {
    setLoading(true);
    try {
      const resp = await agenthubApi.listAgents({
        statuses,
        page: nextPage,
        pageSize: nextPageSize
      });
      setAgents(resp.items || []);
      setTotal(resp.total || 0);
      setPage(resp.page || nextPage);
      setPageSize(resp.page_size || nextPageSize);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadAgentsFailed")}: ${messageText}`);
    } finally {
      setLoading(false);
      setLoaded(true);
    }
  };

  useEffect(() => {
    loadAgents(1, pageSize);
  }, [statuses]);

  useEffect(() => {
    const loadMcpAssets = async () => {
      setMcpLoading(true);
      try {
        const [servers, tools] = await Promise.all([mcpApi.listServers(), mcpApi.listTools()]);
        setMcpServers(servers || []);
        setMcpTools(tools || []);
      } catch (error) {
        const messageText = error instanceof Error ? error.message : String(error);
        message.error(`${t("message.loadMcpFailed")}: ${messageText}`);
      } finally {
        setMcpLoading(false);
      }
    };
    loadMcpAssets();
  }, [message, t]);

  const formatDate = (value?: string | null) => {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString();
  };

  const renderStatusTag = (value: AgentStatus) => {
    return <Tag color={statusColors[value] || "default"}>{t(`agent.status.${value}`)}</Tag>;
  };

  const handleSubmitReview = async (identifier: string) => {
    try {
      await agenthubApi.submitReview(identifier);
      message.success(t("message.agentSubmitted"));
      loadAgents(page, pageSize);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.agentSubmitFailed")}: ${messageText}`);
    }
  };

  const handleApprove = async (identifier: string) => {
    try {
      await agenthubApi.approveAgent(identifier);
      message.success(t("message.agentApproved"));
      loadAgents(page, pageSize);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.agentApproveFailed")}: ${messageText}`);
    }
  };

  const handleReject = async (identifier: string) => {
    try {
      await agenthubApi.rejectAgent(identifier);
      message.success(t("message.agentRejected"));
      loadAgents(page, pageSize);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.agentRejectFailed")}: ${messageText}`);
    }
  };

  const handlePublish = async (identifier: string) => {
    try {
      await agenthubApi.publishAgent(identifier);
      message.success(t("message.agentPublished"));
      loadAgents(page, pageSize);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.agentPublishFailed")}: ${messageText}`);
    }
  };

  const handleUnpublish = async (identifier: string) => {
    try {
      await agenthubApi.unpublishAgent(identifier);
      message.success(t("message.agentUnpublished"));
      loadAgents(page, pageSize);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.agentUnpublishFailed")}: ${messageText}`);
    }
  };

  const columns = useMemo(
    () => [
      {
        title: t("table.agent.identifier"),
        dataIndex: "identifier",
        key: "identifier",
        render: (value: string) => <Text code>{value}</Text>
      },
      {
        title: t("table.agent.title"),
        dataIndex: "title",
        key: "title",
        render: (value: string) => value || "-"
      },
      {
        title: t("table.agent.description"),
        dataIndex: "description",
        key: "description",
        width: 360,
        render: (value: string) =>
          value ? (
            <Paragraph
              style={{ marginBottom: 0 }}
              ellipsis={{ rows: 2, tooltip: { title: value, overlayInnerStyle: { maxWidth: 640 } } }}
            >
              {value}
            </Paragraph>
          ) : (
            "-"
          )
      },
      {
        title: t("table.agent.status"),
        dataIndex: "status",
        key: "status",
        render: (value: AgentStatus) => renderStatusTag(value)
      },
      {
        title: t("table.agent.latestVersion"),
        dataIndex: "latest_version",
        key: "latest_version",
        render: (value: string | null | undefined) => value || "-"
      },
      {
        title: t("table.agent.publishedVersion"),
        dataIndex: "published_version",
        key: "published_version",
        render: (value: string | null | undefined) => value || "-"
      },
      {
        title: t("table.agent.updatedAt"),
        dataIndex: "updated_at",
        key: "updated_at",
        render: (value: string) => formatDate(value)
      },
      {
        title: t("table.actions"),
        key: "actions",
        render: (_: unknown, record: AgentListItem) => {
          const actions: ReactNode[] = [];
          if (record.status === "draft") {
            actions.push(
              <Button key="submit" size="small" icon={<RocketOutlined />} onClick={() => handleSubmitReview(record.identifier)}>
                {t("action.submitReview")}
              </Button>
            );
          }
          if (record.status === "in_review") {
            actions.push(
              <Button key="approve" size="small" icon={<CheckCircleOutlined />} onClick={() => handleApprove(record.identifier)}>
                {t("action.approve")}
              </Button>
            );
            actions.push(
              <Button key="reject" size="small" icon={<CloseCircleOutlined />} onClick={() => handleReject(record.identifier)}>
                {t("action.reject")}
              </Button>
            );
          }
          if (record.status === "published") {
            actions.push(
              <Button key="unpublish" size="small" icon={<StopOutlined />} onClick={() => handleUnpublish(record.identifier)}>
                {t("action.unpublish")}
              </Button>
            );
          }
          if (record.status === "unpublished") {
            actions.push(
              <Button key="publish" size="small" icon={<RocketOutlined />} onClick={() => handlePublish(record.identifier)}>
                {t("action.publish")}
              </Button>
            );
          }
          if (actions.length === 0) {
            actions.push(
              <Button key="refresh" size="small" icon={<ReloadOutlined />} onClick={() => loadAgents(page, pageSize)}>
                {t("action.refresh")}
              </Button>
            );
          }
          return <Space size={6}>{actions}</Space>;
        }
      }
    ],
    [page, pageSize, t]
  );

  const mcpServerOptions = useMemo(
    () => mcpServers.map((server) => ({ label: server.name, value: server.name })),
    [mcpServers]
  );

  const mcpToolOptions = useMemo(
    () => mcpTools.map((tool) => ({ label: tool.name, value: tool.name })),
    [mcpTools]
  );

  const handleCreate = async () => {
    try {
      const values = await createForm.validateFields();
      setCreating(true);
      const payload: AgentCreatePayload = {
        identifier: values.identifier,
        version: values.version || "0.1.0",
        mcp_servers: values.mcp_servers || [],
        mcp_tools: values.mcp_tools || [],
        locales: {
          "en-US": {
            meta: {
              title: values.title,
              description: values.description,
              avatar: values.avatar,
              category: values.category,
              tags: values.tags || []
            },
            config: {
              systemRole: values.systemRole,
              openingMessage: values.openingMessage,
              openingQuestions: values.openingQuestions || []
            },
            author: values.author || "",
            homepage: values.homepage || ""
          }
        }
      };

      if (useZh) {
        payload.locales["zh-CN"] = {
          meta: {
            title: values.titleZh || values.title,
            description: values.descriptionZh || values.description,
            avatar: values.avatarZh || values.avatar,
            category: values.categoryZh || values.category,
            tags: values.tagsZh || values.tags || []
          },
          config: {
            systemRole: values.systemRoleZh || values.systemRole,
            openingMessage: values.openingMessageZh || values.openingMessage,
            openingQuestions: values.openingQuestionsZh || values.openingQuestions || []
          },
          author: values.authorZh || values.author || "",
          homepage: values.homepageZh || values.homepage || ""
        };
      }

      await agenthubApi.createAgent(payload);
      message.success(t("message.agentCreated"));
      setCreateOpen(false);
      setUseZh(false);
      createForm.resetFields();
      loadAgents(1, pageSize);
    } catch (error) {
      if (error && typeof error === "object" && "errorFields" in (error as any)) {
        return;
      }
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.agentCreateFailed")}: ${messageText}`);
    } finally {
      setCreating(false);
    }
  };

  return (
    <div>
      <PageHeader
        title={t("page.agents.title")}
        subtitle={t("page.agents.subtitle")}
        actions={
          <Space>
            <Button icon={<ReloadOutlined />} onClick={() => loadAgents(page, pageSize)}>
              {t("action.refresh")}
            </Button>
            <Button className="btn-gradient" icon={<PlusOutlined />} onClick={() => setCreateOpen(true)}>
              {t("action.registerAgent")}
            </Button>
          </Space>
        }
      />

      <Card>
        <Space style={{ marginBottom: 16 }}>
          <Select
            mode="multiple"
            allowClear
            placeholder={t("filter.agent.status")}
            value={statuses}
            onChange={(values) => setStatuses(values as AgentStatus[])}
            options={[
              { value: "draft", label: t("agent.status.draft") },
              { value: "in_review", label: t("agent.status.in_review") },
              { value: "published", label: t("agent.status.published") },
              { value: "unpublished", label: t("agent.status.unpublished") },
              { value: "archived", label: t("agent.status.archived") }
            ]}
            style={{ minWidth: 260 }}
          />
        </Space>

        <Table
          rowKey="identifier"
          loading={loading}
          columns={columns}
          dataSource={agents}
          pagination={{
            current: page,
            pageSize,
            total,
            onChange: (nextPage, nextPageSize) => loadAgents(nextPage, nextPageSize)
          }}
          locale={{
            emptyText: loaded ? (
              <EmptyState
                title={t("page.agents.emptyTitle")}
                description={t("page.agents.emptyDesc")}
              />
            ) : (
              t("message.loading")
            )
          }}
        />
      </Card>

      <Modal
        title={t("modal.agent.createTitle")}
        open={createOpen}
        onCancel={() => setCreateOpen(false)}
        onOk={handleCreate}
        confirmLoading={creating}
        width={720}
      >
        <Form layout="vertical" form={createForm} initialValues={{ version: "0.1.0" }}>
          <Form.Item
            label={t("form.agent.identifier")}
            name="identifier"
            rules={[
              { required: true, message: t("form.agent.identifierRequired") },
              {
                pattern: /^[a-z0-9-]{3,64}$/,
                message: t("form.agent.identifierInvalid")
              }
            ]}
          >
            <Input placeholder="asset-analyst" />
          </Form.Item>
          <Form.Item label={t("form.agent.version")} name="version">
            <Input placeholder="0.1.0" />
          </Form.Item>
          <Form.Item label={t("form.agent.title")} name="title" rules={[{ required: true, message: t("form.agent.titleRequired") }]}> 
            <Input />
          </Form.Item>
          <Form.Item
            label={t("form.agent.description")}
            name="description"
            rules={[{ required: true, message: t("form.agent.descriptionRequired") }]}
          >
            <Input.TextArea rows={3} />
          </Form.Item>
          <Form.Item label={t("form.agent.avatar")} name="avatar">
            <Input placeholder="😀 / https://..." />
          </Form.Item>
          <Form.Item label={t("form.agent.category")} name="category">
            <Input />
          </Form.Item>
          <Form.Item label={t("form.agent.tags")} name="tags">
            <Select mode="tags" placeholder={t("form.agent.tagsPlaceholder")} />
          </Form.Item>
          <Form.Item
            label={t("form.agent.mcpServers")}
            name="mcp_servers"
            extra={t("form.agent.mcpServersHint")}
          >
            <Select
              mode="multiple"
              allowClear
              showSearch
              loading={mcpLoading}
              placeholder={t("form.agent.mcpServersPlaceholder")}
              optionFilterProp="label"
              options={mcpServerOptions}
            />
          </Form.Item>
          <Form.Item
            label={t("form.agent.mcpTools")}
            name="mcp_tools"
            extra={t("form.agent.mcpToolsHint")}
          >
            <Select
              mode="multiple"
              allowClear
              showSearch
              loading={mcpLoading}
              placeholder={t("form.agent.mcpToolsPlaceholder")}
              optionFilterProp="label"
              options={mcpToolOptions}
            />
          </Form.Item>
          <Form.Item
            label={t("form.agent.systemRole")}
            name="systemRole"
            rules={[{ required: true, message: t("form.agent.systemRoleRequired") }]}
          >
            <Input.TextArea rows={4} />
          </Form.Item>
          <Form.Item label={t("form.agent.openingMessage")} name="openingMessage">
            <Input.TextArea rows={2} />
          </Form.Item>
          <Form.Item label={t("form.agent.openingQuestions")} name="openingQuestions">
            <Select mode="tags" placeholder={t("form.agent.openingQuestionsPlaceholder")} />
          </Form.Item>
          <Form.Item label={t("form.agent.author")} name="author">
            <Input />
          </Form.Item>
          <Form.Item label={t("form.agent.homepage")} name="homepage">
            <Input />
          </Form.Item>

          <Form.Item label={t("form.agent.useZh")}
            extra={t("form.agent.useZhHint")}
          >
            <Switch checked={useZh} onChange={setUseZh} />
          </Form.Item>

          {useZh && (
            <Card size="small" title={t("form.agent.zhSection")} style={{ marginTop: 16 }}>
              <Form.Item label={t("form.agent.titleZh")} name="titleZh">
                <Input />
              </Form.Item>
              <Form.Item label={t("form.agent.descriptionZh")} name="descriptionZh">
                <Input.TextArea rows={3} />
              </Form.Item>
              <Form.Item label={t("form.agent.avatarZh")} name="avatarZh">
                <Input />
              </Form.Item>
              <Form.Item label={t("form.agent.categoryZh")} name="categoryZh">
                <Input />
              </Form.Item>
              <Form.Item label={t("form.agent.tagsZh")} name="tagsZh">
                <Select mode="tags" />
              </Form.Item>
              <Form.Item label={t("form.agent.systemRoleZh")} name="systemRoleZh">
                <Input.TextArea rows={4} />
              </Form.Item>
              <Form.Item label={t("form.agent.openingMessageZh")} name="openingMessageZh">
                <Input.TextArea rows={2} />
              </Form.Item>
              <Form.Item label={t("form.agent.openingQuestionsZh")} name="openingQuestionsZh">
                <Select mode="tags" />
              </Form.Item>
              <Form.Item label={t("form.agent.authorZh")} name="authorZh">
                <Input />
              </Form.Item>
              <Form.Item label={t("form.agent.homepageZh")} name="homepageZh">
                <Input />
              </Form.Item>
            </Card>
          )}
        </Form>
      </Modal>
    </div>
  );
};

export default AssetsAgents;

import { ReloadOutlined } from "@ant-design/icons";
import { App, Button, Card, Select, Space, Tag, Typography } from "antd";
import { useState } from "react";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";
import agenthubApi from "../services/agenthub";
import api, { User } from "../services/mcpjungle";
import skillhubApi from "../services/skillhub";
import authApi from "../services/uiauth";

const { Text } = Typography;

const SystemSettings = () => {
  const { t } = useI18n();
  const { message } = App.useApp();
  const [health, setHealth] = useState<string | null>(null);
  const [version, setVersion] = useState<string | null>(null);
  const [whoami, setWhoami] = useState<User | null>(null);
  const [skillhubHealth, setSkillhubHealth] = useState<string | null>(null);
  const [skillsRefAvailable, setSkillsRefAvailable] = useState<boolean | null>(null);
  const [agenthubHealth, setAgenthubHealth] = useState<string | null>(null);
  const [testing, setTesting] = useState(false);
  const [initLoading, setInitLoading] = useState(false);

  const handleTest = async () => {
    setTesting(true);
    let mcpOk = false;
    let skillhubOk = false;
    let agenthubOk = false;
    try {
      const [healthResp, metaResp] = await Promise.all([api.getHealth(), api.getMetadata()]);
      setHealth(healthResp.status);
      setVersion(metaResp.version);
      mcpOk = true;
      try {
        const who = await api.whoami();
        setWhoami(who);
      } catch (error) {
        setWhoami(null);
        const messageText = error instanceof Error ? error.message : String(error);
        message.warning(`${t("message.userInfoFailed")}: ${messageText}`);
      }
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.connectionFailed")}: ${messageText}`);
    }

    try {
      const [healthResp, skillsRefResp] = await Promise.all([
        skillhubApi.getHealth(),
        skillhubApi.getSkillsRefHealth()
      ]);
      setSkillhubHealth(healthResp.status);
      setSkillsRefAvailable(Boolean(skillsRefResp.available));
      skillhubOk = true;
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.warning(`${t("message.skillhubConnectionFailed")}: ${messageText}`);
    }

    try {
      const healthResp = await agenthubApi.getHealth();
      setAgenthubHealth(healthResp.status);
      agenthubOk = true;
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.warning(`${t("message.agenthubConnectionFailed")}: ${messageText}`);
    } finally {
      if (mcpOk && skillhubOk && agenthubOk) {
        message.success(t("message.connectionOk"));
      } else if (mcpOk || skillhubOk || agenthubOk) {
        message.warning(t("message.connectionPartial"));
      }
      setTesting(false);
    }
  };

  const handleInit = async () => {
    setInitLoading(true);
    try {
      await authApi.bootstrapMcp();
      message.success(t("message.initOk"));
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.initFailed")}: ${messageText}`);
    } finally {
      setInitLoading(false);
    }
  };

  return (
    <div>
      <PageHeader
        title={t("page.system.settings.title")}
        subtitle={t("page.system.settings.subtitle")}
        actions={
          <Space>
            <Button icon={<ReloadOutlined />} loading={testing} onClick={handleTest}>
              {t("action.testConnection")}
            </Button>
          </Space>
        }
      />

      <Card style={{ marginBottom: 16 }} title={t("section.connection.title")}>
        <Space direction="vertical" size="small">
          <div>
            <Text type="secondary">{t("section.connection.health")}</Text>
            <div>{health ? <Tag color="green">{health}</Tag> : "-"}</div>
          </div>
          <div>
            <Text type="secondary">{t("section.connection.version")}</Text>
            <div>{version || "-"}</div>
          </div>
          <div>
            <Text type="secondary">{t("section.connection.user")}</Text>
            <div>{whoami ? `${whoami.username} (${whoami.role})` : "-"}</div>
          </div>
          <div>
            <Text type="secondary">{t("section.connection.skillhubHealth")}</Text>
            <div>{skillhubHealth ? <Tag color="green">{skillhubHealth}</Tag> : "-"}</div>
          </div>
          <div>
            <Text type="secondary">{t("section.connection.skillhubSkillsRef")}</Text>
            <div>
              {skillsRefAvailable === null ? "-" : (
                <Tag color={skillsRefAvailable ? "green" : "default"}>
                  {skillsRefAvailable ? t("status.available") : t("status.unavailable")}
                </Tag>
              )}
            </div>
          </div>
          <div>
            <Text type="secondary">{t("section.connection.agenthubHealth")}</Text>
            <div>{agenthubHealth ? <Tag color="green">{agenthubHealth}</Tag> : "-"}</div>
          </div>
        </Space>
      </Card>

      <Card title={t("section.init.title")}>
        <Space align="center">
          <Select
            value="enterprise"
            options={[
              { value: "development", label: "development" },
              { value: "enterprise", label: "enterprise" },
              { value: "production", label: "production" }
            ]}
            style={{ width: 200 }}
            disabled
          />
          <Button loading={initLoading} onClick={handleInit}>
            {t("action.init")}
          </Button>
        </Space>
      </Card>
    </div>
  );
};

export default SystemSettings;

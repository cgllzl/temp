import { Button } from "antd";
import PlaceholderPage from "../components/PlaceholderPage";
import { useI18n } from "../i18n";

const ObservabilityMetrics = () => {
  const { t } = useI18n();
  return (
    <PlaceholderPage
      title={t("page.observability.metrics.title")}
      subtitle={t("page.observability.metrics.subtitle")}
      emptyTitle={t("page.observability.metrics.emptyTitle")}
      emptyDescription={t("page.observability.metrics.emptyDesc")}
      actions={<Button className="btn-gradient">{t("action.connectMetrics")}</Button>}
    />
  );
};

export default ObservabilityMetrics;

import { ArrowUpOutlined, CloudOutlined, DeploymentUnitOutlined, ThunderboltOutlined } from "@ant-design/icons";
import { Button, Card, Col, Row, Space, Table, Tag, Typography } from "antd";
import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useI18n } from "../i18n";
import EmptyState from "../components/EmptyState";
import PageHeader from "../components/PageHeader";
import StatCard from "../components/StatCard";

const { Text } = Typography;

const Dashboard = () => {
  const { t } = useI18n();
  const navigate = useNavigate();

  const recentColumns = useMemo(
    () => [
      {
        title: t("table.asset"),
        dataIndex: "asset",
        key: "asset"
      },
      {
        title: t("table.type"),
        dataIndex: "type",
        key: "type",
        render: (value: string) => <Tag color="blue">{t(`assetType.${value}`)}</Tag>
      },
      {
        title: t("table.status"),
        dataIndex: "status",
        key: "status",
        render: (value: string) => {
          if (value === "active") return <Tag color="green">{t("status.active")}</Tag>;
          if (value === "draft") return <Tag color="gold">{t("status.draft")}</Tag>;
          return <Tag color="default">{value}</Tag>;
        }
      },
      {
        title: t("table.owner"),
        dataIndex: "owner",
        key: "owner"
      }
    ],
    [t]
  );

  const recentData = useMemo(
    () => [
      { key: "1", asset: "finance-guardrails", type: "prompt", status: "active", owner: "Platform" },
      { key: "2", asset: "vector-search", type: "mcp", status: "active", owner: "Infra" },
      { key: "3", asset: "policy-review", type: "skill", status: "draft", owner: "GRC" }
    ],
    []
  );

  return (
    <div>
      <PageHeader
        title={t("page.dashboard.title")}
        subtitle={t("page.dashboard.subtitle")}
        actions={
          <Space>
            <Button>{t("action.export")}</Button>
            <Button className="btn-gradient">{t("action.createAsset")}</Button>
          </Space>
        }
      />

      <div className="hero-panel" style={{ padding: 28, marginBottom: 24 }}>
        <div className="hero-glow" />
        <div className="hero-grid" />
        <Row gutter={[24, 24]} align="middle">
          <Col xs={24} md={14}>
            <div className="section-badge" style={{ marginBottom: 16 }}>
              <span className="pulse-dot" />
              <span className="mono-label">{t("hero.badge")}</span>
            </div>
            <h1 className="display-font" style={{ fontSize: 34, margin: 0 }}>
              {t("hero.title.prefix")}<span className="gradient-text">{t("hero.title.highlight")}</span>
              {t("hero.title.suffix")}
            </h1>
            <Text type="secondary" style={{ display: "block", marginTop: 12, maxWidth: 420 }}>
              {t("hero.description")}
            </Text>
            <Space style={{ marginTop: 20 }}>
              <Button className="btn-gradient">{t("hero.action.review")}</Button>
              <Button onClick={() => navigate("/assets")}>{t("hero.action.assets")}</Button>
            </Space>
          </Col>
          <Col xs={24} md={10}>
            <div style={{ display: "grid", gap: 12 }}>
              <div className="float-card" style={{ background: "#fff", padding: 16, borderRadius: 14 }}>
                <div style={{ fontSize: 12, color: "var(--muted-foreground)" }}>{t("hero.card.activeGateways")}</div>
                <div style={{ fontSize: 24, fontWeight: 600 }}>18</div>
              </div>
              <div
                className="float-card delay"
                style={{ background: "#fff", padding: 16, borderRadius: 14, border: "1px solid var(--border)" }}
              >
                <div style={{ fontSize: 12, color: "var(--muted-foreground)" }}>{t("hero.card.weeklyCalls")}</div>
                <div style={{ fontSize: 24, fontWeight: 600 }}>128k</div>
              </div>
            </div>
          </Col>
        </Row>
      </div>

      <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
        <Col xs={24} md={12} lg={6}>
          <StatCard label={t("stat.assets")} value="324" trend={t("trend.assets")} icon={<DeploymentUnitOutlined />} />
        </Col>
        <Col xs={24} md={12} lg={6}>
          <StatCard label={t("stat.activeAgents")} value="42" trend={t("trend.agents")} icon={<ThunderboltOutlined />} />
        </Col>
        <Col xs={24} md={12} lg={6}>
          <StatCard label={t("stat.toolCalls")} value="1.2M" trend={t("trend.calls")} icon={<CloudOutlined />} />
        </Col>
        <Col xs={24} md={12} lg={6}>
          <StatCard label={t("stat.policyPass")} value="98.4%" trend={t("trend.policy")} icon={<ArrowUpOutlined />} />
        </Col>
      </Row>

      <Row gutter={[16, 16]}>
        <Col xs={24} lg={14}>
          <Card title={t("card.recentAssets")} extra={<Button type="link">{t("action.viewAll")}</Button>}>
            <Table columns={recentColumns} dataSource={recentData} pagination={false} />
          </Card>
        </Col>
        <Col xs={24} lg={10}>
          <Card title={t("card.governanceQueue")}>
            <EmptyState
              title={t("empty.noApprovals.title")}
              description={t("empty.noApprovals.desc")}
              actions={<Button className="btn-gradient">{t("action.openPolicies")}</Button>}
            />
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default Dashboard;

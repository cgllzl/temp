import { EditOutlined, PlusOutlined, ReloadOutlined } from "@ant-design/icons";
import {
  App,
  Button,
  Card,
  Form,
  Input,
  Modal,
  Popconfirm,
  Space,
  Table,
  Tag
} from "antd";
import { useEffect, useMemo, useState } from "react";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";
import api, { McpClient } from "../services/mcpjungle";
import { parseStringList } from "../utils/mcp";

const AccessClients = () => {
  const { t } = useI18n();
  const { message } = App.useApp();
  const [clients, setClients] = useState<McpClient[]>([]);
  const [loading, setLoading] = useState(false);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingName, setEditingName] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [form] = Form.useForm();

  const loadClients = async () => {
    setLoading(true);
    try {
      const data = await api.listClients();
      setClients(Array.isArray(data) ? data : []);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadClientsFailed")}: ${messageText}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadClients();
  }, []);

  const openCreate = () => {
    setEditingName(null);
    form.resetFields();
    setEditorOpen(true);
  };

  const openEdit = (record: McpClient) => {
    setEditingName(record.name);
    form.setFieldsValue({
      name: record.name,
      description: record.description,
      allow_list: record.allow_list?.join(", ")
    });
    setEditorOpen(true);
  };

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      let allowList: string[] | undefined;
      try {
        allowList = parseStringList(values.allow_list);
      } catch (error) {
        const messageText = error instanceof Error ? error.message : String(error);
        message.error(`${t("message.invalidJson")}: ${messageText}`);
        return;
      }
      const payload: McpClient = {
        name: values.name,
        description: values.description || undefined,
        allow_list: allowList
      };

      setSaving(true);
      if (editingName) {
        await api.updateClient(editingName, payload);
        message.success(t("message.clientUpdated"));
      } else {
        const resp = await api.createClient(payload);
        message.success(t("message.clientCreated"));
        if (resp?.access_token) {
          Modal.info({
            title: t("modal.client.token.title"),
            content: <pre style={{ margin: 0 }}>{resp.access_token}</pre>
          });
        }
      }
      setEditorOpen(false);
      loadClients();
    } catch (error: any) {
      if (error?.errorFields) return;
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.clientSaveFailed")}: ${messageText}`);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (name: string) => {
    try {
      await api.deleteClient(name);
      message.success(t("message.clientDeleted"));
      loadClients();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.clientDeleteFailed")}: ${messageText}`);
    }
  };

  const columns = useMemo(
    () => [
      { title: t("table.client.name"), dataIndex: "name", key: "name" },
      {
        title: t("table.client.description"),
        dataIndex: "description",
        key: "description",
        render: (value: string | undefined) => value || "-"
      },
      {
        title: t("table.client.allowList"),
        dataIndex: "allow_list",
        key: "allow_list",
        render: (value: string[] | undefined) => (value?.length ? value.join(", ") : "-")
      },
      {
        title: t("table.client.tokenType"),
        dataIndex: "is_custom_access_token",
        key: "is_custom_access_token",
        render: (value: boolean | undefined) =>
          value ? <Tag color="blue">{t("status.custom")}</Tag> : <Tag>{t("status.generated")}</Tag>
      },
      {
        title: t("table.actions"),
        key: "actions",
        render: (_: unknown, record: McpClient) => (
          <Space>
            <Button size="small" icon={<EditOutlined />} onClick={() => openEdit(record)}>
              {t("action.edit")}
            </Button>
            <Popconfirm title={`${t("confirm.deleteClient")} ${record.name}?`} onConfirm={() => handleDelete(record.name)}>
              <Button size="small" danger>
                {t("action.delete")}
              </Button>
            </Popconfirm>
          </Space>
        )
      }
    ],
    [t]
  );

  return (
    <div>
      <PageHeader
        title={t("page.access.clients.title")}
        subtitle={t("page.access.clients.subtitle")}
        actions={
          <Space>
            <Button icon={<ReloadOutlined />} onClick={loadClients}>
              {t("action.refresh")}
            </Button>
            <Button className="btn-gradient" icon={<PlusOutlined />} onClick={openCreate}>
              {t("action.createClient")}
            </Button>
          </Space>
        }
      />
      <Card>
        <Table rowKey="name" columns={columns} dataSource={clients} loading={loading} />
      </Card>

      <Modal
        title={editingName ? t("modal.client.edit.title") : t("modal.client.create.title")}
        open={editorOpen}
        onCancel={() => setEditorOpen(false)}
        onOk={handleSave}
        confirmLoading={saving}
        okText={t("action.save")}
        cancelText={t("action.cancel")}
      >
        <Form form={form} layout="vertical">
          <Form.Item
            label={t("form.client.name")}
            name="name"
            rules={[{ required: true, message: t("form.client.nameRequired") }]}
          >
            <Input disabled={Boolean(editingName)} placeholder="agent-runtime" />
          </Form.Item>
          <Form.Item label={t("form.client.description")} name="description">
            <Input.TextArea rows={3} placeholder={t("form.client.descriptionPlaceholder")} />
          </Form.Item>
          <Form.Item label={t("form.client.allowList")} name="allow_list">
            <Input placeholder="server__toolA, server__toolB" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default AccessClients;

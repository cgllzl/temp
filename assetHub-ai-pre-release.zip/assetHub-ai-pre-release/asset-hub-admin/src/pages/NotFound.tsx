import { Button, Result } from "antd";
import { Link } from "react-router-dom";
import { useI18n } from "../i18n";

const NotFound = () => {
  const { t } = useI18n();
  return (
    <Result
      status="404"
      title={t("notFound.title")}
      subTitle={t("notFound.subtitle")}
      extra={
        <Link to="/dashboard">
          <Button className="btn-gradient">{t("action.backToDashboard")}</Button>
        </Link>
      }
    />
  );
};

export default NotFound;

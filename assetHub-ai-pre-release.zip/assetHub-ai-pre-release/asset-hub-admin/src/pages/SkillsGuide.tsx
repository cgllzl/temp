import { Card, Divider, Typography } from "antd";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";

const { Paragraph, Text, Title } = Typography;

const directoryExample = `example-skill/
  SKILL.md
  scripts/
    README.md
  references/
    README.md
  assets/
    README.md`;

const frontmatterExample = `---
name: example-skill
description: Example skill template
metadata:
  version: 0.1.0
  type: custom
  dependencies:
    - python>=3.11
---`;

const SkillsGuide = () => {
  const { t } = useI18n();

  return (
    <div>
      <PageHeader title={t("page.skills.guide.title")} subtitle={t("page.skills.guide.subtitle")} />

      <Card>
        <Title level={4}>{t("page.skills.guide.structure.title")}</Title>
        <Paragraph>{t("page.skills.guide.structure.desc")}</Paragraph>
        <pre style={{ margin: 0, background: "#0f172a", color: "#e2e8f0", padding: 16, borderRadius: 12 }}>
          {directoryExample}
        </pre>

        <Divider />

        <Title level={4}>{t("page.skills.guide.frontmatter.title")}</Title>
        <Paragraph>{t("page.skills.guide.frontmatter.desc")}</Paragraph>
        <pre style={{ margin: 0, background: "#0f172a", color: "#e2e8f0", padding: 16, borderRadius: 12 }}>
          {frontmatterExample}
        </pre>

        <Divider />

        <Title level={4}>{t("page.skills.guide.trigger.title")}</Title>
        <Paragraph>{t("page.skills.guide.trigger.desc")}</Paragraph>

        <Divider />

        <Title level={4}>{t("page.skills.guide.resources.title")}</Title>
        <Paragraph>{t("page.skills.guide.resources.desc")}</Paragraph>
        <Paragraph>
          <Text type="secondary">scripts/</Text> · <Text type="secondary">references/</Text> ·{" "}
          <Text type="secondary">assets/</Text>
        </Paragraph>

        <Divider />

        <Title level={4}>{t("page.skills.guide.validation.title")}</Title>
        <Paragraph>{t("page.skills.guide.validation.desc")}</Paragraph>
      </Card>
    </div>
  );
};

export default SkillsGuide;

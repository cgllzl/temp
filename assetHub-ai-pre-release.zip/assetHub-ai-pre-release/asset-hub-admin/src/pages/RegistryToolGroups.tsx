import { EditOutlined, EyeOutlined, PlusOutlined, ReloadOutlined } from "@ant-design/icons";
import {
  App,
  Button,
  Card,
  Drawer,
  Form,
  Input,
  Modal,
  Popconfirm,
  Space,
  Table,
  Tag,
  Typography
} from "antd";
import { useEffect, useMemo, useState } from "react";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";
import api, { ToolGroup, ToolGroupResponse } from "../services/mcpjungle";
import { parseStringList, toPrettyJson } from "../utils/mcp";

const { Text } = Typography;

const RegistryToolGroups = ({ embedded = false }: { embedded?: boolean }) => {
  const { t } = useI18n();
  const { message } = App.useApp();
  const [groups, setGroups] = useState<ToolGroup[]>([]);
  const [loading, setLoading] = useState(false);

  const [detailOpen, setDetailOpen] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detail, setDetail] = useState<ToolGroupResponse | null>(null);
  const [effectiveTools, setEffectiveTools] = useState<string[]>([]);

  const [editorOpen, setEditorOpen] = useState(false);
  const [editingName, setEditingName] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [form] = Form.useForm();

  const loadGroups = async () => {
    setLoading(true);
    try {
      const data = await api.listToolGroups();
      setGroups(Array.isArray(data) ? data : []);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadToolGroupsFailed")}: ${messageText}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadGroups();
  }, []);

  const openDetail = async (name: string) => {
    setDetailOpen(true);
    setDetailLoading(true);
    setDetail(null);
    setEffectiveTools([]);
    try {
      const detailResp = await api.getToolGroup(name);
      setDetail(detailResp as ToolGroupResponse);
      const effective = await api.getToolGroupEffectiveTools(name);
      setEffectiveTools(effective.tools || []);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadToolGroupDetailFailed")}: ${messageText}`);
    } finally {
      setDetailLoading(false);
    }
  };

  const openCreate = () => {
    setEditingName(null);
    form.resetFields();
    setEditorOpen(true);
  };

  const openEdit = (record: ToolGroup) => {
    setEditingName(record.name);
    form.setFieldsValue({
      name: record.name,
      description: record.description,
      included_tools: record.included_tools?.join(", "),
      included_servers: record.included_servers?.join(", "),
      excluded_tools: record.excluded_tools?.join(", ")
    });
    setEditorOpen(true);
  };

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      let includedTools: string[] | undefined;
      let includedServers: string[] | undefined;
      let excludedTools: string[] | undefined;
      try {
        includedTools = parseStringList(values.included_tools);
        includedServers = parseStringList(values.included_servers);
        excludedTools = parseStringList(values.excluded_tools);
      } catch (error) {
        const messageText = error instanceof Error ? error.message : String(error);
        message.error(`${t("message.invalidJson")}: ${messageText}`);
        return;
      }
      const payload: ToolGroup = {
        name: values.name,
        description: values.description || undefined,
        included_tools: includedTools,
        included_servers: includedServers,
        excluded_tools: excludedTools
      };

      setSaving(true);
      if (editingName) {
        await api.updateToolGroup(editingName, payload);
        message.success(t("message.toolGroupUpdated"));
      } else {
        await api.createToolGroup(payload);
        message.success(t("message.toolGroupCreated"));
      }
      setEditorOpen(false);
      loadGroups();
    } catch (error: any) {
      if (error?.errorFields) return;
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.toolGroupSaveFailed")}: ${messageText}`);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (name: string) => {
    try {
      await api.deleteToolGroup(name);
      message.success(t("message.toolGroupDeleted"));
      loadGroups();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.toolGroupDeleteFailed")}: ${messageText}`);
    }
  };

  const columns = useMemo(
    () => [
      {
        title: t("table.toolGroup.name"),
        dataIndex: "name",
        key: "name"
      },
      {
        title: t("table.toolGroup.description"),
        dataIndex: "description",
        key: "description",
        render: (value: string | undefined) => value || "-"
      },
      {
        title: t("table.toolGroup.included"),
        key: "included",
        render: (_: unknown, record: ToolGroup) => (
          <Space size="small">
            <Tag>{(record.included_tools || []).length}</Tag>
            <Tag>{(record.included_servers || []).length}</Tag>
          </Space>
        )
      },
      {
        title: t("table.toolGroup.excluded"),
        key: "excluded",
        render: (_: unknown, record: ToolGroup) => <Tag>{(record.excluded_tools || []).length}</Tag>
      },
      {
        title: t("table.actions"),
        key: "actions",
        render: (_: unknown, record: ToolGroup) => (
          <Space>
            <Button size="small" icon={<EyeOutlined />} onClick={() => openDetail(record.name)}>
              {t("action.view")}
            </Button>
            <Button size="small" icon={<EditOutlined />} onClick={() => openEdit(record)}>
              {t("action.edit")}
            </Button>
            <Popconfirm
              title={`${t("confirm.deleteToolGroup")} ${record.name}?`}
              onConfirm={() => handleDelete(record.name)}
            >
              <Button size="small" danger>
                {t("action.delete")}
              </Button>
            </Popconfirm>
          </Space>
        )
      }
    ],
    [t]
  );

  const headerActions = (
    <Space>
      <Button icon={<ReloadOutlined />} onClick={loadGroups}>
        {t("action.refresh")}
      </Button>
      <Button className="btn-gradient" icon={<PlusOutlined />} onClick={openCreate}>
        {t("action.createGroup")}
      </Button>
    </Space>
  );

  return (
    <div>
      {!embedded && (
        <PageHeader
          title={t("page.registry.toolGroups.title")}
          subtitle={t("page.registry.toolGroups.subtitle")}
          actions={headerActions}
        />
      )}
      {embedded && <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 12 }}>{headerActions}</div>}
      <Card>
        <Table rowKey="name" columns={columns} dataSource={groups} loading={loading} />
      </Card>

      <Drawer
        title={t("drawer.toolGroup.title")}
        open={detailOpen}
        onClose={() => setDetailOpen(false)}
        width={520}
      >
        {detailLoading ? (
          <Text type="secondary">{t("message.loading")}</Text>
        ) : detail ? (
          <div style={{ display: "grid", gap: 12 }}>
            <div>
              <Text type="secondary">{t("table.toolGroup.name")}</Text>
              <div>{detail.name}</div>
            </div>
            <div>
              <Text type="secondary">{t("table.toolGroup.description")}</Text>
              <div>{detail.description || "-"}</div>
            </div>
            <div>
              <Text type="secondary">{t("table.toolGroup.endpoints")}</Text>
              <pre style={{ margin: 0, background: "#f8fafc", padding: 12, borderRadius: 12 }}>
                {toPrettyJson({
                  streamable_http_endpoint: detail.streamable_http_endpoint,
                  sse_endpoint: detail.sse_endpoint,
                  sse_message_endpoint: detail.sse_message_endpoint
                })}
              </pre>
            </div>
            <div>
              <Text type="secondary">{t("table.toolGroup.includedTools")}</Text>
              <div>{detail.included_tools?.join(", ") || "-"}</div>
            </div>
            <div>
              <Text type="secondary">{t("table.toolGroup.includedServers")}</Text>
              <div>{detail.included_servers?.join(", ") || "-"}</div>
            </div>
            <div>
              <Text type="secondary">{t("table.toolGroup.excludedTools")}</Text>
              <div>{detail.excluded_tools?.join(", ") || "-"}</div>
            </div>
            <div>
              <Text type="secondary">{t("table.toolGroup.effectiveTools")}</Text>
              <div>{effectiveTools.length ? effectiveTools.join(", ") : "-"}</div>
            </div>
          </div>
        ) : (
          <Text type="secondary">{t("empty.noToolGroupDetail")}</Text>
        )}
      </Drawer>

      <Modal
        title={editingName ? t("modal.toolGroup.edit.title") : t("modal.toolGroup.create.title")}
        open={editorOpen}
        onCancel={() => setEditorOpen(false)}
        onOk={handleSave}
        confirmLoading={saving}
        okText={t("action.save")}
        cancelText={t("action.cancel")}
      >
        <Form form={form} layout="vertical">
          <Form.Item
            label={t("form.toolGroup.name")}
            name="name"
            rules={[{ required: true, message: t("form.toolGroup.nameRequired") }]}
          >
            <Input disabled={Boolean(editingName)} placeholder="core-tools" />
          </Form.Item>
          <Form.Item label={t("form.toolGroup.description")} name="description">
            <Input.TextArea rows={3} placeholder={t("form.toolGroup.descriptionPlaceholder")} />
          </Form.Item>
          <Form.Item label={t("form.toolGroup.includedTools")} name="included_tools">
            <Input placeholder="server__toolA, server__toolB" />
          </Form.Item>
          <Form.Item label={t("form.toolGroup.includedServers")} name="included_servers">
            <Input placeholder="serverA, serverB" />
          </Form.Item>
          <Form.Item label={t("form.toolGroup.excludedTools")} name="excluded_tools">
            <Input placeholder="server__toolC" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default RegistryToolGroups;

import { PlusOutlined, ReloadOutlined } from "@ant-design/icons";
import { App, Button, Card, Form, Input, Modal, Popconfirm, Space, Table, Tag } from "antd";
import { useEffect, useMemo, useState } from "react";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";
import api, { User } from "../services/mcpjungle";

const AccessUsers = () => {
  const { t } = useI18n();
  const { message } = App.useApp();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [form] = Form.useForm();

  const loadUsers = async () => {
    setLoading(true);
    try {
      const data = await api.listUsers();
      setUsers(Array.isArray(data) ? data : []);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadUsersFailed")}: ${messageText}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleCreate = async () => {
    try {
      const values = await form.validateFields();
      setCreating(true);
      const resp = await api.createUser({
        username: values.username,
        access_token: values.access_token || undefined
      });
      message.success(t("message.userCreated"));
      setCreateOpen(false);
      form.resetFields();
      loadUsers();
      if (resp?.access_token) {
        Modal.info({
          title: t("modal.user.token.title"),
          content: <pre style={{ margin: 0 }}>{resp.access_token}</pre>
        });
      }
    } catch (error: any) {
      if (error?.errorFields) return;
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.userCreateFailed")}: ${messageText}`);
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (username: string) => {
    try {
      await api.deleteUser(username);
      message.success(t("message.userDeleted"));
      loadUsers();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.userDeleteFailed")}: ${messageText}`);
    }
  };

  const columns = useMemo(
    () => [
      { title: t("table.user.username"), dataIndex: "username", key: "username" },
      {
        title: t("table.user.role"),
        dataIndex: "role",
        key: "role",
        render: (value: string) => <Tag>{value}</Tag>
      },
      {
        title: t("table.actions"),
        key: "actions",
        render: (_: unknown, record: User) => (
          <Popconfirm
            title={`${t("confirm.deleteUser")} ${record.username}?`}
            onConfirm={() => handleDelete(record.username)}
          >
            <Button size="small" danger>
              {t("action.delete")}
            </Button>
          </Popconfirm>
        )
      }
    ],
    [t]
  );

  return (
    <div>
      <PageHeader
        title={t("page.access.users.title")}
        subtitle={t("page.access.users.subtitle")}
        actions={
          <Space>
            <Button icon={<ReloadOutlined />} onClick={loadUsers}>
              {t("action.refresh")}
            </Button>
            <Button className="btn-gradient" icon={<PlusOutlined />} onClick={() => setCreateOpen(true)}>
              {t("action.inviteUser")}
            </Button>
          </Space>
        }
      />
      <Card>
        <Table rowKey="username" columns={columns} dataSource={users} loading={loading} />
      </Card>

      <Modal
        title={t("modal.user.create.title")}
        open={createOpen}
        onCancel={() => setCreateOpen(false)}
        onOk={handleCreate}
        confirmLoading={creating}
        okText={t("action.save")}
        cancelText={t("action.cancel")}
      >
        <Form form={form} layout="vertical">
          <Form.Item
            label={t("form.user.username")}
            name="username"
            rules={[{ required: true, message: t("form.user.usernameRequired") }]}
          >
            <Input placeholder="alice" />
          </Form.Item>
          <Form.Item label={t("form.user.accessToken")} name="access_token">
            <Input placeholder="optional" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default AccessUsers;

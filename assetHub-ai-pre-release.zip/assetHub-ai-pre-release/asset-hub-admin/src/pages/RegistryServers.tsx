import { MoreOutlined, PlusOutlined, ReloadOutlined } from "@ant-design/icons";
import {
  Button,
  Card,
  Dropdown,
  App,
  Form,
  Input,
  Modal,
  Popconfirm,
  Select,
  Switch,
  Space,
  Table,
  Tag,
  Typography
} from "antd";
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";
import api, { McpServer } from "../services/mcpjungle";
import { parseJson, parseStringList } from "../utils/mcp";

const { Text } = Typography;

const RegistryServers = ({ embedded = false }: { embedded?: boolean }) => {
  const { t } = useI18n();
  const navigate = useNavigate();
  const { message } = App.useApp();
  const [servers, setServers] = useState<McpServer[]>([]);
  const [loading, setLoading] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [form] = Form.useForm();

  const loadServers = async () => {
    setLoading(true);
    try {
      const data = await api.listServers();
      setServers(Array.isArray(data) ? data : []);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadServersFailed")}: ${messageText}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadServers();
  }, []);

  const handleCreate = async () => {
    try {
      const values = await form.validateFields();
      const payload: Record<string, any> = {
        name: values.name,
        transport: values.transport,
        description: values.description || undefined
      };

      if (values.url) payload.url = values.url;
      if (values.command) payload.command = values.command;
      if (values.args) {
        try {
          payload.args = parseStringList(values.args);
        } catch (error) {
          const messageText = error instanceof Error ? error.message : String(error);
          message.error(`${t("message.invalidJson")}: ${messageText}`);
          return;
        }
      }
      if (values.env) {
        const parsed = parseJson<Record<string, string>>(values.env);
        if (!parsed.ok) {
          message.error(`${t("message.invalidJson")}: ${parsed.error}`);
          return;
        }
        payload.env = parsed.value;
      }
      if (values.session_mode) {
        payload.session_mode = values.session_mode;
      }

      setCreating(true);
      await api.registerServer(payload, values.force);
      message.success(t("message.serverCreated"));
      setCreateOpen(false);
      form.resetFields();
      loadServers();
    } catch (error: any) {
      if (error?.errorFields) return;
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.serverCreateFailed")}: ${messageText}`);
    } finally {
      setCreating(false);
    }
  };

  const handleAction = async (action: string, record: McpServer) => {
    try {
      if (action === "enable") {
        await api.enableServer(record.name);
        message.success(t("message.serverEnabled"));
        loadServers();
        return;
      }
      if (action === "disable") {
        await api.disableServer(record.name);
        message.success(t("message.serverDisabled"));
        loadServers();
        return;
      }
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.serverActionFailed")}: ${messageText}`);
    }
  };

  const handleDelete = async (name: string) => {
    try {
      await api.deregisterServer(name);
      message.success(t("message.serverDeleted"));
      loadServers();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.serverDeleteFailed")}: ${messageText}`);
    }
  };

  const columns = useMemo(
    () => [
      {
        title: t("table.server.name"),
        dataIndex: "name",
        key: "name",
        render: (value: string) => (
          <Button type="link" onClick={() => navigate(`/assets/mcp/servers/${encodeURIComponent(value)}`)}>
            {value}
          </Button>
        )
      },
      {
        title: t("table.server.transport"),
        dataIndex: "transport",
        key: "transport",
        render: (value: string) => <Tag color="blue">{value}</Tag>
      },
      {
        title: t("table.server.endpoint"),
        key: "endpoint",
        render: (_: unknown, record: McpServer) => {
          if (record.url) return record.url;
          if (record.command) {
            const args = record.args?.length ? ` ${record.args.join(" ")}` : "";
            return `${record.command}${args}`;
          }
          return "-";
        }
      },
      {
        title: t("table.server.sessionMode"),
        dataIndex: "session_mode",
        key: "session_mode",
        render: (value: string | undefined) => value ?? "-"
      },
      {
        title: t("table.server.status"),
        dataIndex: "enabled",
        key: "enabled",
        render: (value: boolean | undefined) => {
          if (value === undefined) return <Text type="secondary">-</Text>;
          return value ? <Tag color="green">{t("status.enabled")}</Tag> : <Tag>{t("status.disabled")}</Tag>;
        }
      },
      {
        title: t("table.server.description"),
        dataIndex: "description",
        key: "description",
        render: (value: string | undefined) => value || "-"
      },
      {
        title: t("table.actions"),
        key: "actions",
        render: (_: unknown, record: McpServer) => (
          <Space>
            <Button size="small" onClick={() => navigate(`/assets/mcp/servers/${encodeURIComponent(record.name)}`)}>
              {t("action.view")}
            </Button>
            <Dropdown
              menu={{
                items: [
                  { key: "enable", label: t("action.enable") },
                  { key: "disable", label: t("action.disable") }
                ],
                onClick: ({ key }) => handleAction(key, record)
              }}
            >
              <Button size="small" icon={<MoreOutlined />} />
            </Dropdown>
            <Popconfirm
              title={`${t("confirm.deleteServer")} ${record.name}?`}
              onConfirm={() => handleDelete(record.name)}
            >
              <Button size="small" danger>
                {t("action.delete")}
              </Button>
            </Popconfirm>
          </Space>
        )
      }
    ],
    [navigate, t]
  );

  const headerActions = (
    <Space>
      <Button icon={<ReloadOutlined />} onClick={loadServers}>
        {t("action.refresh")}
      </Button>
      <Button className="btn-gradient" icon={<PlusOutlined />} onClick={() => setCreateOpen(true)}>
        {t("action.addServer")}
      </Button>
    </Space>
  );

  return (
    <div>
      {!embedded && (
        <PageHeader
          title={t("page.registry.servers.title")}
          subtitle={t("page.registry.servers.subtitle")}
          actions={headerActions}
        />
      )}
      {embedded && <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 12 }}>{headerActions}</div>}
      <Card>
        <Table rowKey="name" columns={columns} dataSource={servers} loading={loading} />
      </Card>

      <Modal
        title={t("modal.server.create.title")}
        open={createOpen}
        onCancel={() => setCreateOpen(false)}
        onOk={handleCreate}
        confirmLoading={creating}
        okText={t("action.save")}
        cancelText={t("action.cancel")}
      >
        <Form layout="vertical" form={form} initialValues={{ transport: "streamable_http" }}>
          <Form.Item
            label={t("form.server.name")}
            name="name"
            rules={[{ required: true, message: t("form.server.nameRequired") }]}
          >
            <Input placeholder="mcp-server" />
          </Form.Item>
          <Form.Item
            label={t("form.server.transport")}
            name="transport"
            rules={[{ required: true, message: t("form.server.transportRequired") }]}
          >
            <Select
              options={[
                { value: "streamable_http", label: "streamable_http" },
                { value: "stdio", label: "stdio" }
              ]}
            />
          </Form.Item>
          <Form.Item label={t("form.server.url")} name="url">
            <Input placeholder="http://localhost:8080" />
          </Form.Item>
          <Form.Item label={t("form.server.command")} name="command">
            <Input placeholder="node server.js" />
          </Form.Item>
          <Form.Item label={t("form.server.args")} name="args">
            <Input placeholder="--port, 9000" />
          </Form.Item>
          <Form.Item label={t("form.server.env")} name="env">
            <Input.TextArea rows={3} placeholder='{"KEY":"VALUE"}' />
          </Form.Item>
          <Form.Item label={t("form.server.sessionMode")} name="session_mode">
            <Select
              options={[
                { value: "auto", label: "auto" },
                { value: "persistent", label: "persistent" },
                { value: "stateless", label: "stateless" }
              ]}
              allowClear
            />
          </Form.Item>
          <Form.Item label={t("form.server.description")} name="description">
            <Input.TextArea rows={3} placeholder={t("form.server.descriptionPlaceholder")} />
          </Form.Item>
          <Form.Item label={t("form.server.force")} name="force" valuePropName="checked">
            <Switch />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default RegistryServers;

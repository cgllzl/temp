import { Button } from "antd";
import PlaceholderPage from "../components/PlaceholderPage";
import { useI18n } from "../i18n";

const ObservabilityLogs = () => {
  const { t } = useI18n();
  return (
    <PlaceholderPage
      title={t("page.observability.logs.title")}
      subtitle={t("page.observability.logs.subtitle")}
      emptyTitle={t("page.observability.logs.emptyTitle")}
      emptyDescription={t("page.observability.logs.emptyDesc")}
      actions={<Button className="btn-gradient">{t("action.openLogStream")}</Button>}
    />
  );
};

export default ObservabilityLogs;

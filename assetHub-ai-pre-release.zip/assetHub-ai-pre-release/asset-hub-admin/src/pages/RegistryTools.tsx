import { EyeOutlined, PlayCircleOutlined, ReloadOutlined } from "@ant-design/icons";
import { App, Button, Card, Drawer, Input, Modal, Space, Spin, Table, Tag, Typography } from "antd";
import { useEffect, useMemo, useState } from "react";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";
import api, { McpTool, ToolInvokeResult } from "../services/mcpjungle";
import { parseJson, splitEntityName, toPrettyJson } from "../utils/mcp";

const { Text } = Typography;

const RegistryTools = ({ embedded = false }: { embedded?: boolean }) => {
  const { t } = useI18n();
  const { message } = App.useApp();
  const [tools, setTools] = useState<McpTool[]>([]);
  const [loading, setLoading] = useState(false);

  const [toolDetailOpen, setToolDetailOpen] = useState(false);
  const [toolDetailLoading, setToolDetailLoading] = useState(false);
  const [toolDetail, setToolDetail] = useState<McpTool | null>(null);

  const [invokeOpen, setInvokeOpen] = useState(false);
  const [invokeLoading, setInvokeLoading] = useState(false);
  const [invokePayload, setInvokePayload] = useState("{}");
  const [invokeResult, setInvokeResult] = useState<ToolInvokeResult | null>(null);

  const loadTools = async () => {
    setLoading(true);
    try {
      const data = await api.listTools();
      setTools(Array.isArray(data) ? data : []);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadToolsFailed")}: ${messageText}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTools();
  }, []);

  const openToolDetail = async (record: McpTool) => {
    setToolDetailOpen(true);
    setToolDetailLoading(true);
    setToolDetail(null);
    try {
      const detail = await api.getTool(record.name);
      setToolDetail(detail);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.loadToolDetailFailed")}: ${messageText}`);
    } finally {
      setToolDetailLoading(false);
    }
  };

  const handleToggleTool = async (record: McpTool, nextEnabled: boolean) => {
    try {
      if (nextEnabled) {
        await api.enableTools(record.name);
        message.success(t("message.toolEnabled"));
      } else {
        await api.disableTools(record.name);
        message.success(t("message.toolDisabled"));
      }
      loadTools();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.toolActionFailed")}: ${messageText}`);
    }
  };

  const handleInvoke = async () => {
    if (!toolDetail) return;
    const parsed = parseJson<Record<string, any>>(invokePayload);
    if (!parsed.ok) {
      message.error(`${t("message.invalidJson")}: ${parsed.error}`);
      return;
    }
    setInvokeLoading(true);
    try {
      const result = await api.invokeTool(toolDetail.name, parsed.value || {});
      setInvokeResult(result);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.toolInvokeFailed")}: ${messageText}`);
    } finally {
      setInvokeLoading(false);
    }
  };

  const columns = useMemo(
    () => [
      {
        title: t("table.tool.server"),
        dataIndex: "name",
        key: "server",
        render: (value: string) => splitEntityName(value).server || "-"
      },
      {
        title: t("table.tool.name"),
        dataIndex: "name",
        key: "name",
        render: (value: string) => splitEntityName(value).local
      },
      {
        title: t("table.tool.status"),
        dataIndex: "enabled",
        key: "enabled",
        render: (value: boolean) =>
          value ? <Tag color="green">{t("status.enabled")}</Tag> : <Tag>{t("status.disabled")}</Tag>
      },
      {
        title: t("table.tool.description"),
        dataIndex: "description",
        key: "description",
        render: (value: string | undefined) => value || "-"
      },
      {
        title: t("table.actions"),
        key: "actions",
        render: (_: unknown, record: McpTool) => (
          <Space>
            <Button size="small" icon={<EyeOutlined />} onClick={() => openToolDetail(record)}>
              {t("action.view")}
            </Button>
            <Button
              size="small"
              icon={<PlayCircleOutlined />}
              onClick={() => {
                setToolDetail(record);
                setInvokeResult(null);
                setInvokePayload("{}");
                setInvokeOpen(true);
              }}
            >
              {t("action.invoke")}
            </Button>
            <Button
              size="small"
              onClick={() => handleToggleTool(record, !record.enabled)}
              type={record.enabled ? "default" : "primary"}
            >
              {record.enabled ? t("action.disable") : t("action.enable")}
            </Button>
          </Space>
        )
      }
    ],
    [t]
  );

  const headerActions = (
    <Space>
      <Button icon={<ReloadOutlined />} onClick={loadTools}>
        {t("action.refresh")}
      </Button>
    </Space>
  );

  return (
    <div>
      {!embedded && (
        <PageHeader
          title={t("page.registry.tools.title")}
          subtitle={t("page.registry.tools.subtitle")}
          actions={headerActions}
        />
      )}
      {embedded && <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 12 }}>{headerActions}</div>}
      <Card>
        <Table rowKey="name" columns={columns} dataSource={tools} loading={loading} />
      </Card>

      <Drawer
        title={t("drawer.tool.title")}
        open={toolDetailOpen}
        onClose={() => setToolDetailOpen(false)}
        width={520}
      >
        <Spin spinning={toolDetailLoading}>
          {toolDetail ? (
            <div style={{ display: "grid", gap: 12 }}>
              <div>
                <Text type="secondary">{t("table.tool.fullName")}</Text>
                <div>{toolDetail.name}</div>
              </div>
              <div>
                <Text type="secondary">{t("table.tool.status")}</Text>
                <div>
                  {toolDetail.enabled ? <Tag color="green">{t("status.enabled")}</Tag> : <Tag>{t("status.disabled")}</Tag>}
                </div>
              </div>
              <div>
                <Text type="secondary">{t("table.tool.description")}</Text>
                <div>{toolDetail.description || "-"}</div>
              </div>
              <div>
                <Text type="secondary">{t("table.tool.inputSchema")}</Text>
                <pre style={{ margin: 0, background: "#f8fafc", padding: 12, borderRadius: 12 }}>
                  {toPrettyJson(toolDetail.input_schema ?? {})}
                </pre>
              </div>
              <div>
                <Text type="secondary">{t("table.tool.annotations")}</Text>
                <pre style={{ margin: 0, background: "#f8fafc", padding: 12, borderRadius: 12 }}>
                  {toPrettyJson(toolDetail.annotations ?? {})}
                </pre>
              </div>
            </div>
          ) : (
            <Text type="secondary">{t("empty.noToolDetail")}</Text>
          )}
        </Spin>
      </Drawer>

      <Modal
        title={t("modal.tool.invoke.title")}
        open={invokeOpen}
        onCancel={() => setInvokeOpen(false)}
        onOk={handleInvoke}
        confirmLoading={invokeLoading}
        okText={t("action.invoke")}
        cancelText={t("action.cancel")}
      >
        <div style={{ display: "grid", gap: 12 }}>
          <Text type="secondary">{toolDetail?.name}</Text>
          <Input.TextArea
            rows={6}
            value={invokePayload}
            onChange={(event) => setInvokePayload(event.target.value)}
            placeholder='{"input":"value"}'
          />
          {invokeResult && (
            <pre style={{ margin: 0, background: "#f8fafc", padding: 12, borderRadius: 12 }}>
              {toPrettyJson(invokeResult)}
            </pre>
          )}
        </div>
      </Modal>
    </div>
  );
};

export default RegistryTools;

import {
  ArrowLeftOutlined,
  CheckOutlined,
  DownloadOutlined,
  EditOutlined,
  InboxOutlined,
  UploadOutlined,
  ReloadOutlined,
  FileZipOutlined
} from "@ant-design/icons";
import {
  App,
  Button,
  Card,
  Descriptions,
  Input,
  Select,
  Modal,
  Space,
  Table,
  Tabs,
  Tag,
  Typography,
  Upload
} from "antd";
import type { UploadRequestOption } from "rc-upload/lib/interface";
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import PageHeader from "../components/PageHeader";
import { useI18n } from "../i18n";
import skillhubApi, {
  SkillDetail,
  SkillStatus,
  SkillType,
  SkillVersion,
  ValidationStatus
} from "../services/skillhub";

const { Text } = Typography;

const SkillsDetail = () => {
  const { name } = useParams();
  const { t } = useI18n();
  const navigate = useNavigate();
  const { message } = App.useApp();

  const [detail, setDetail] = useState<SkillDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadVersion, setUploadVersion] = useState("");
  const [statusOpen, setStatusOpen] = useState(false);
  const [statusSaving, setStatusSaving] = useState(false);
  const [statusValue, setStatusValue] = useState<SkillStatus | undefined>(undefined);

  const loadDetail = async () => {
    if (!name) return;
    setLoading(true);
    try {
      const data = await skillhubApi.getSkill(name);
      setDetail(data);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.skillDetailFailed")}: ${messageText}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDetail();
  }, [name]);

  useEffect(() => {
    if (detail?.status) {
      setStatusValue(detail.status);
    }
  }, [detail?.status]);

  const formatDate = (value?: string | null) => {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString();
  };

  const renderTypeTag = (value?: SkillType) => {
    if (!value) return "-";
    const map: Record<SkillType, string> = {
      custom: "blue",
      "org-provisioned": "geekblue",
      partner: "purple",
      anthropic: "gold"
    };
    return <Tag color={map[value] || "default"}>{t(`skill.type.${value}`)}</Tag>;
  };

  const renderStatusTag = (value?: SkillStatus) => {
    if (!value) return "-";
    const map: Record<SkillStatus, string> = {
      draft: "default",
      active: "green",
      deprecated: "orange",
      archived: "red"
    };
    return <Tag color={map[value] || "default"}>{t(`skill.status.${value}`)}</Tag>;
  };

  const renderValidationTag = (value: ValidationStatus) => {
    const map: Record<ValidationStatus, string> = {
      not_validated: "default",
      passed: "green",
      failed: "red",
      not_available: "orange"
    };
    return <Tag color={map[value] || "default"}>{t(`skill.validation.${value}`)}</Tag>;
  };

  const latestVersion = useMemo(() => {
    if (!detail) return null;
    if (detail.latest_version) {
      return detail.versions.find((v) => v.version === detail.latest_version) || detail.versions[0] || null;
    }
    return detail.versions[0] || null;
  }, [detail]);

  const buildNextVersion = (value?: string | null) => {
    if (!value) return "0.1.1";
    const parts = value.split(".").map((item) => Number.parseInt(item, 10));
    if (parts.length !== 3 || parts.some((num) => Number.isNaN(num))) {
      return value;
    }
    return `${parts[0]}.${parts[1]}.${parts[2] + 1}`;
  };

  const handleValidate = async (version: string) => {
    if (!name) return;
    setActionLoading(true);
    try {
      await skillhubApi.validateSkillVersion(name, version);
      message.success(t("message.skillValidated"));
      loadDetail();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.skillValidateFailed")}: ${messageText}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handlePackage = async (version: string) => {
    if (!name) return;
    setActionLoading(true);
    try {
      await skillhubApi.packageSkillVersion(name, version);
      message.success(t("message.skillPackaged"));
      loadDetail();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.skillPackageFailed")}: ${messageText}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleDownload = (version: string) => {
    if (!name) return;
    const url = skillhubApi.getPackageUrl(name, version);
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const handleStatusSave = async () => {
    if (!name || !statusValue) return;
    setStatusSaving(true);
    try {
      await skillhubApi.updateSkillStatus(name, { status: statusValue });
      message.success(t("message.skillStatusUpdated"));
      setStatusOpen(false);
      loadDetail();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.skillStatusUpdateFailed")}: ${messageText}`);
    } finally {
      setStatusSaving(false);
    }
  };

  const handleUpload = async (file: File, version: string) => {
    setUploading(true);
    try {
      const resp = await skillhubApi.uploadSkill(file, version);
      message.success(`${t("message.skillUploaded")}: ${resp.name}@${resp.version}`);
      setUploadOpen(false);
      loadDetail();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(`${t("message.skillUploadFailed")}: ${messageText}`);
    } finally {
      setUploading(false);
    }
  };

  const uploadProps = {
    multiple: false,
    accept: ".zip",
    showUploadList: false,
    customRequest: (options: UploadRequestOption) => {
      const file = options.file as File;
      const version = uploadVersion.trim();
      if (!version) {
        message.warning(t("message.versionRequired"));
        options.onError?.(new Error("version required"));
        return;
      }
      handleUpload(file, version)
        .then(() => options.onSuccess?.("ok"))
        .catch((error) => options.onError?.(error));
    }
  };

  const versionColumns = useMemo(
    () => [
      {
        title: t("table.skill.version"),
        dataIndex: "version",
        key: "version",
        render: (value: string) => <Text strong>{value}</Text>
      },
      {
        title: t("table.skill.validation"),
        dataIndex: "validation_status",
        key: "validation_status",
        render: (value: ValidationStatus) => renderValidationTag(value)
      },
      {
        title: t("table.skill.dependencies"),
        dataIndex: "dependencies_count",
        key: "dependencies_count",
        render: (value: number) => value ?? 0
      },
      {
        title: t("table.skill.resources"),
        dataIndex: "resources_count",
        key: "resources_count",
        render: (value: number) => value ?? 0
      },
      {
        title: t("table.skill.validatedAt"),
        dataIndex: "validated_at",
        key: "validated_at",
        render: (value: string | null) => formatDate(value)
      },
      {
        title: t("table.skill.package"),
        dataIndex: "package_available",
        key: "package_available",
        render: (value: boolean) =>
          value ? <Tag color="green">{t("status.available")}</Tag> : <Tag>{t("status.unavailable")}</Tag>
      },
      {
        title: t("table.skill.updatedAt"),
        dataIndex: "updated_at",
        key: "updated_at",
        render: (value: string) => formatDate(value)
      },
      {
        title: t("table.actions"),
        key: "actions",
        render: (_: unknown, record: SkillVersion) => (
          <Space>
            <Button
              size="small"
              icon={<CheckOutlined />}
              onClick={() => handleValidate(record.version)}
              loading={actionLoading}
            >
              {t("action.validate")}
            </Button>
            <Button
              size="small"
              icon={<FileZipOutlined />}
              onClick={() => handlePackage(record.version)}
              loading={actionLoading}
            >
              {t("action.package")}
            </Button>
            <Button
              size="small"
              icon={<DownloadOutlined />}
              disabled={!record.package_available}
              onClick={() => handleDownload(record.version)}
            >
              {t("action.downloadPackage")}
            </Button>
          </Space>
        )
      }
    ],
    [actionLoading, t]
  );

  const dependencies = latestVersion?.dependencies || [];
  const filesSummary = latestVersion?.files_summary || {};
  const filesManifest = latestVersion?.files_manifest || [];
  const validationReport = latestVersion?.validation_report;
  const suggestedVersion = buildNextVersion(latestVersion?.version);

  useEffect(() => {
    if (uploadOpen) {
      setUploadVersion(suggestedVersion);
    }
  }, [uploadOpen, suggestedVersion]);

  return (
    <div>
      <PageHeader
        title={detail?.name || t("page.skills.detail.title")}
        subtitle={t("page.skills.detail.subtitle")}
        actions={
          <Space>
            <Button icon={<ArrowLeftOutlined />} onClick={() => navigate("/assets/skills")}>
              {t("action.backToSkills")}
            </Button>
            <Button icon={<ReloadOutlined />} onClick={loadDetail} loading={loading}>
              {t("action.refresh")}
            </Button>
            <Button icon={<EditOutlined />} onClick={() => setStatusOpen(true)}>
              {t("action.updateStatus")}
            </Button>
            <Button icon={<UploadOutlined />} onClick={() => setUploadOpen(true)}>
              {t("action.newVersion")}
            </Button>
            <Button
              icon={<CheckOutlined />}
              disabled={!latestVersion}
              onClick={() => latestVersion && handleValidate(latestVersion.version)}
              loading={actionLoading}
            >
              {t("action.validateLatest")}
            </Button>
            <Button
              icon={<FileZipOutlined />}
              disabled={!latestVersion}
              onClick={() => latestVersion && handlePackage(latestVersion.version)}
              loading={actionLoading}
            >
              {t("action.packageLatest")}
            </Button>
            <Button
              icon={<DownloadOutlined />}
              disabled={!latestVersion?.package_available}
              onClick={() => latestVersion && handleDownload(latestVersion.version)}
            >
              {t("action.downloadPackage")}
            </Button>
          </Space>
        }
      />

      <Card loading={loading} style={{ marginBottom: 16 }}>
        <Descriptions column={2} size="middle">
          <Descriptions.Item label={t("field.skill.name")}>{detail?.name || "-"}</Descriptions.Item>
          <Descriptions.Item label={t("field.skill.type")}>{renderTypeTag(detail?.type)}</Descriptions.Item>
          <Descriptions.Item label={t("field.skill.status")}>{renderStatusTag(detail?.status)}</Descriptions.Item>
          <Descriptions.Item label={t("field.skill.latestVersion")}>
            {detail?.latest_version || "-"}
          </Descriptions.Item>
          <Descriptions.Item label={t("field.skill.updatedAt")}>{formatDate(detail?.updated_at)}</Descriptions.Item>
          <Descriptions.Item label={t("field.skill.createdAt")}>{formatDate(detail?.created_at)}</Descriptions.Item>
          <Descriptions.Item label={t("field.skill.description")} span={2}>
            {detail?.description || "-"}
          </Descriptions.Item>
        </Descriptions>
      </Card>

      <Card>
        <Tabs
          items={[
            {
              key: "versions",
              label: t("tab.skill.versions"),
              children: (
                <Table
                  rowKey="version"
                  columns={versionColumns}
                  dataSource={detail?.versions || []}
                  pagination={false}
                />
              )
            },
            {
              key: "dependencies",
              label: t("tab.skill.dependencies"),
              children: (
                <Space wrap>
                  {dependencies.length === 0
                    ? t("tab.skill.dependencies.empty")
                    : dependencies.map((dep) => (
                        <Tag key={dep} color="blue">
                          {dep}
                        </Tag>
                      ))}
                </Space>
              )
            },
            {
              key: "resources",
              label: t("tab.skill.resources"),
              children: (
                <div style={{ display: "grid", gap: 12 }}>
                  <Space wrap>
                    <Tag>{`${t("label.total")}: ${filesSummary.total || 0}`}</Tag>
                    <Tag>{`${t("label.scripts")}: ${filesSummary.scripts || 0}`}</Tag>
                    <Tag>{`${t("label.references")}: ${filesSummary.references || 0}`}</Tag>
                    <Tag>{`${t("label.assets")}: ${filesSummary.assets || 0}`}</Tag>
                  </Space>
                  <div>
                    <Text type="secondary">{t("label.manifest")}</Text>
                    <div style={{ marginTop: 8 }}>
                      {filesManifest.length === 0 ? (
                        <div>{t("tab.skill.resources.empty")}</div>
                      ) : (
                        <ul style={{ paddingLeft: 18, margin: 0 }}>
                          {filesManifest.slice(0, 20).map((item) => (
                            <li key={item}>{item}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                </div>
              )
            },
            {
              key: "validation",
              label: t("tab.skill.validation"),
              children: latestVersion ? (
                <Space direction="vertical" size="middle">
                  <div>
                    <Text type="secondary">{t("field.skill.validationStatus")}</Text>
                    <div>{renderValidationTag(latestVersion.validation_status)}</div>
                  </div>
                  <div>
                    <Text type="secondary">{t("field.skill.validatedAt")}</Text>
                    <div>{formatDate(latestVersion.validated_at)}</div>
                  </div>
                  <div>
                    <Text type="secondary">{t("field.skill.validationReport")}</Text>
                    {validationReport ? (
                      <pre
                        style={{
                          marginTop: 8,
                          background: "#0f172a",
                          color: "#e2e8f0",
                          padding: 16,
                          borderRadius: 12,
                          maxHeight: 320,
                          overflow: "auto"
                        }}
                      >
                        {JSON.stringify(validationReport, null, 2)}
                      </pre>
                    ) : (
                      <div style={{ marginTop: 8 }}>{t("tab.skill.validation.reportEmpty")}</div>
                    )}
                  </div>
                </Space>
              ) : (
                <div>{t("tab.skill.validation.empty")}</div>
              )
            }
          ]}
        />
      </Card>

      <Modal
        title={t("modal.skill.upload.title")}
        open={uploadOpen}
        onCancel={() => setUploadOpen(false)}
        footer={null}
      >
        <div style={{ marginBottom: 12, display: "grid", gap: 6 }}>
          <Text type="secondary">
            {t("label.currentVersion")}: {latestVersion?.version || "-"}
          </Text>
          <Text type="secondary">
            {t("label.suggestedVersion")}: {suggestedVersion}
          </Text>
        </div>
        <div style={{ marginBottom: 12 }}>
          <Text type="secondary">{t("form.skill.newVersion")}</Text>
          <Input
            value={uploadVersion}
            onChange={(event) => setUploadVersion(event.target.value)}
            placeholder={suggestedVersion}
          />
          <div style={{ marginTop: 6, fontSize: 12, color: "var(--muted-foreground)" }}>
            {t("form.skill.newVersionHint")}
          </div>
        </div>
        <Upload.Dragger {...uploadProps} disabled={uploading}>
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">{t("modal.skill.upload.hint")}</p>
          <p className="ant-upload-hint">{t("modal.skill.upload.support")}</p>
        </Upload.Dragger>
      </Modal>

      <Modal
        title={t("modal.skill.status.title")}
        open={statusOpen}
        onCancel={() => setStatusOpen(false)}
        onOk={handleStatusSave}
        confirmLoading={statusSaving}
        okText={t("action.save")}
        cancelText={t("action.cancel")}
      >
        <Select
          value={statusValue}
          onChange={(value) => setStatusValue(value as SkillStatus)}
          style={{ width: "100%" }}
          options={[
            { label: t("skill.status.draft"), value: "draft" },
            { label: t("skill.status.active"), value: "active" },
            { label: t("skill.status.deprecated"), value: "deprecated" },
            { label: t("skill.status.archived"), value: "archived" }
          ]}
        />
      </Modal>
    </div>
  );
};

export default SkillsDetail;

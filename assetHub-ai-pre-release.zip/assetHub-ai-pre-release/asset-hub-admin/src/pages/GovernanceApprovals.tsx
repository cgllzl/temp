import { Button } from "antd";
import PlaceholderPage from "../components/PlaceholderPage";
import { useI18n } from "../i18n";

const GovernanceApprovals = () => {
  const { t } = useI18n();
  return (
    <PlaceholderPage
      title={t("page.governance.approvals.title")}
      subtitle={t("page.governance.approvals.subtitle")}
      emptyTitle={t("page.governance.approvals.emptyTitle")}
      emptyDescription={t("page.governance.approvals.emptyDesc")}
      actions={<Button className="btn-gradient">{t("action.openPolicies")}</Button>}
    />
  );
};

export default GovernanceApprovals;

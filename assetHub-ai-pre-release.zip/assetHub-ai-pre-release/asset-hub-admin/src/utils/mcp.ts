export const splitEntityName = (name: string) => {
  const index = name.indexOf("__");
  if (index === -1) {
    return { server: "", local: name };
  }
  return { server: name.slice(0, index), local: name.slice(index + 2) };
};

export const parseJson = <T = Record<string, any>>(raw: string) => {
  const trimmed = raw.trim();
  if (!trimmed) {
    return { ok: true, value: {} as T };
  }
  try {
    return { ok: true, value: JSON.parse(trimmed) as T };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Invalid JSON";
    return { ok: false, error: message };
  }
};

export const parseStringList = (raw?: string) => {
  if (!raw) return undefined;
  const trimmed = raw.trim();
  if (!trimmed) return undefined;
  if (trimmed.startsWith("[")) {
    const parsed = JSON.parse(trimmed);
    if (Array.isArray(parsed)) {
      return parsed.map((item) => String(item));
    }
  }
  return trimmed
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
};

export const toPrettyJson = (value: any) => JSON.stringify(value, null, 2);

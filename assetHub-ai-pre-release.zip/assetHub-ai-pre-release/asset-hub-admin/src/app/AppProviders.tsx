import { App as AntdApp, ConfigProvider } from "antd";
import enUS from "antd/locale/en_US";
import zhCN from "antd/locale/zh_CN";
import type { ReactNode } from "react";
import { useI18n } from "../i18n";
import { themeConfig } from "../styles/theme";

const localeMap = {
  "zh-CN": zhCN,
  "en-US": enUS
};

const AppProviders = ({ children }: { children: ReactNode }) => {
  const { locale } = useI18n();

  return (
    <ConfigProvider theme={themeConfig} locale={localeMap[locale]}>
      <AntdApp>{children}</AntdApp>
    </ConfigProvider>
  );
};

export default AppProviders;

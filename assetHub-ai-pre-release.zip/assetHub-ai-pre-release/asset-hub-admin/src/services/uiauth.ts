export type SessionInfo = {
  user?: {
    id?: string;
    email?: string;
    name?: string;
  };
};

type SignInPayload = {
  email: string;
  password: string;
};

type TokenResponse = {
  access_token: string;
};

const resolveBaseUrl = () => {
  if (typeof window !== "undefined" && window.location?.origin) {
    return `${window.location.origin}/ui-api`;
  }
  return "http://127.0.0.1:8088/ui-api";
};

const baseUrl = resolveBaseUrl();

const request = async <T>(path: string, init?: RequestInit): Promise<T> => {
  const url = `${baseUrl}${path}`;
  const headers = new Headers(init?.headers || {});
  if (!headers.has("Content-Type") && init?.body) {
    headers.set("Content-Type", "application/json");
  }
  const resp = await fetch(url, {
    ...init,
    headers,
    credentials: "include"
  });
  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(text || `HTTP ${resp.status}`);
  }
  const contentType = resp.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return resp.json() as Promise<T>;
  }
  return (await resp.text()) as unknown as T;
};

const authApi = {
  getSession: () => request<SessionInfo>("/session"),
  signIn: (payload: SignInPayload) =>
    request("/auth/sign-in/email", {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  signOut: () =>
    request("/auth/sign-out", {
      method: "POST",
      body: JSON.stringify({})
    }),
  getMcpToken: () => request<TokenResponse>("/mcp/token"),
  bootstrapMcp: () =>
    request<TokenResponse>("/mcp/bootstrap", {
      method: "POST"
    }),
  getMcpStatus: () => request("/mcp/status")
};

export default authApi;

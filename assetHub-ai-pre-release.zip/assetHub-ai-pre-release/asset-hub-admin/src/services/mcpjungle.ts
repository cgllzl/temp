export type McpServer = {
  name: string;
  transport: string;
  enabled?: boolean;
  description?: string;
  url?: string;
  command?: string;
  args?: string[];
  env?: Record<string, string>;
  session_mode?: string;
};

export type McpTool = {
  name: string;
  enabled: boolean;
  description?: string;
  input_schema?: {
    type?: string;
    properties?: Record<string, any>;
    required?: string[];
  };
  annotations?: Record<string, any>;
};

export type McpPrompt = {
  name: string;
  enabled: boolean;
  description?: string;
  arguments?: any;
};

export type ToolInvokeResult = {
  _meta?: Record<string, any>;
  isError?: boolean;
  content: Array<Record<string, any>>;
  structuredContent?: any;
};

export type PromptResult = {
  description?: string;
  messages: Array<{ role: string; content: Record<string, any> }>;
  meta?: Record<string, any>;
};

export type ToolGroup = {
  name: string;
  description?: string;
  included_tools?: string[];
  included_servers?: string[];
  excluded_tools?: string[];
};

export type ToolGroupEndpoints = {
  streamable_http_endpoint: string;
  sse_endpoint: string;
  sse_message_endpoint: string;
};

export type ToolGroupResponse = ToolGroup & ToolGroupEndpoints;

export type McpClient = {
  name: string;
  description?: string;
  access_token?: string;
  is_custom_access_token?: boolean;
  allow_list?: string[];
};

export type User = {
  username: string;
  role: string;
};

type Config = {
  baseUrl: string;
};

const STORAGE_KEY = "mcpjungle_config";

const resolveDefaultBaseUrl = () => {
  if (typeof window !== "undefined" && window.location?.origin) {
    return `${window.location.origin}/ui-api/mcpjungle`;
  }
  return "http://127.0.0.1:8088/ui-api/mcpjungle";
};

const defaultConfig: Config = {
  baseUrl: resolveDefaultBaseUrl()
};

export const getMcpjungleConfig = (): Config => {
  if (typeof window === "undefined") return defaultConfig;
  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (!raw) return defaultConfig;
  try {
    const parsed = JSON.parse(raw) as Config;
    return {
      baseUrl: parsed.baseUrl || defaultConfig.baseUrl
    };
  } catch {
    return defaultConfig;
  }
};

export const setMcpjungleConfig = (config: Config) => {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
};

const resolveBaseUrl = (baseUrl: string) => {
  if (typeof window === "undefined") return baseUrl;
  const normalized = baseUrl.replace(/\/+$/, "");
  const proxyBase = "/ui-api/mcpjungle";
  const legacyBases = new Set([
    `${window.location.origin}/mcp`,
    `${window.location.origin}/mcpjungle`,
    "http://127.0.0.1:8088/mcp",
    "http://localhost:8088/mcp",
    "http://127.0.0.1:8080",
    "http://localhost:8080"
  ]);

  if (legacyBases.has(normalized)) {
    return proxyBase;
  }

  if (import.meta.env.DEV) {
    if (
      normalized === "http://127.0.0.1:8088/ui-api/mcpjungle" ||
      normalized === "http://localhost:8088/ui-api/mcpjungle"
    ) {
      return proxyBase;
    }
  }
  return baseUrl;
};

const buildUrl = (baseUrl: string, path: string) => {
  const resolved = resolveBaseUrl(baseUrl);
  const trimmed = resolved.replace(/\/+$/, "");
  return `${trimmed}${path}`;
};

const request = async <T>(path: string, init?: RequestInit): Promise<T> => {
  const { baseUrl } = getMcpjungleConfig();
  const url = buildUrl(baseUrl, path);

  const headers = new Headers(init?.headers || {});
  if (!headers.has("Content-Type") && init?.body) {
    headers.set("Content-Type", "application/json");
  }

  const resp = await fetch(url, { ...init, headers, credentials: "include" });
  if (!resp.ok) {
    const contentType = resp.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      const data = await resp.json();
      const message = data?.error || `HTTP ${resp.status}`;
      throw new Error(message);
    }
    const text = await resp.text();
    throw new Error(text || `HTTP ${resp.status}`);
  }

  if (resp.status === 204) {
    return undefined as T;
  }

  const contentType = resp.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return resp.json() as Promise<T>;
  }
  return (await resp.text()) as unknown as T;
};

const api = {
  getHealth: () => request<{ status: string }>("/health"),
  getMetadata: () => request<{ version: string }>("/metadata"),
  initServer: (mode: "development" | "enterprise" | "production") =>
    request<{ status: string; admin_access_token?: string }>("/init", {
      method: "POST",
      body: JSON.stringify({ mode })
    }),

  listServers: () => request<McpServer[]>("/api/v0/servers"),
  registerServer: (input: any, force?: boolean) =>
    request<McpServer>(`/api/v0/servers${force ? "?force=true" : ""}`, {
      method: "POST",
      body: JSON.stringify(input)
    }),
  deregisterServer: (name: string) => request<void>(`/api/v0/servers/${name}`, { method: "DELETE" }),
  enableServer: (name: string) => request(`/api/v0/servers/${name}/enable`, { method: "POST" }),
  disableServer: (name: string) => request(`/api/v0/servers/${name}/disable`, { method: "POST" }),
  getServerConfigs: () => request("/api/v0/server_configs"),

  listTools: (server?: string) =>
    request<McpTool[]>(`/api/v0/tools${server ? `?server=${encodeURIComponent(server)}` : ""}`),
  getTool: (name: string) => request<McpTool>(`/api/v0/tool?name=${encodeURIComponent(name)}`),
  enableTools: (entity: string) =>
    request<string[]>(`/api/v0/tools/enable?entity=${encodeURIComponent(entity)}`, { method: "POST" }),
  disableTools: (entity: string) =>
    request<string[]>(`/api/v0/tools/disable?entity=${encodeURIComponent(entity)}`, { method: "POST" }),
  invokeTool: (name: string, input: Record<string, any>) =>
    request<ToolInvokeResult>("/api/v0/tools/invoke", {
      method: "POST",
      body: JSON.stringify({ ...input, name })
    }),

  listPrompts: (server?: string) =>
    request<McpPrompt[]>(`/api/v0/prompts${server ? `?server=${encodeURIComponent(server)}` : ""}`),
  getPrompt: (name: string) => request<McpPrompt>(`/api/v0/prompt?name=${encodeURIComponent(name)}`),
  renderPrompt: (name: string, args: Record<string, string>) =>
    request<PromptResult>("/api/v0/prompts/render", {
      method: "POST",
      body: JSON.stringify({ name, arguments: args })
    }),
  enablePrompts: (entity: string) =>
    request<string[]>(`/api/v0/prompts/enable?entity=${encodeURIComponent(entity)}`, { method: "POST" }),
  disablePrompts: (entity: string) =>
    request<string[]>(`/api/v0/prompts/disable?entity=${encodeURIComponent(entity)}`, { method: "POST" }),

  listToolGroups: () => request<ToolGroup[]>("/api/v0/tool-groups"),
  getToolGroup: (name: string) => request<ToolGroupResponse>(`/api/v0/tool-groups/${name}`),
  getToolGroupEffectiveTools: (name: string) =>
    request<{ tools: string[] }>(`/api/v0/tool-groups/${name}/effective-tools`),
  createToolGroup: (payload: ToolGroup) =>
    request<ToolGroupEndpoints>("/api/v0/tool-groups", { method: "POST", body: JSON.stringify(payload) }),
  updateToolGroup: (name: string, payload: ToolGroup) =>
    request(`/api/v0/tool-groups/${name}`, { method: "PUT", body: JSON.stringify(payload) }),
  deleteToolGroup: (name: string) => request(`/api/v0/tool-groups/${name}`, { method: "DELETE" }),

  listClients: () => request<McpClient[]>("/api/v0/clients"),
  createClient: (payload: McpClient) =>
    request<{ access_token: string }>("/api/v0/clients", { method: "POST", body: JSON.stringify(payload) }),
  updateClient: (name: string, payload: McpClient) =>
    request(`/api/v0/clients/${name}`, { method: "PUT", body: JSON.stringify(payload) }),
  deleteClient: (name: string) => request(`/api/v0/clients/${name}`, { method: "DELETE" }),

  listUsers: () => request<User[]>("/api/v0/users"),
  createUser: (payload: { username: string; access_token?: string }) =>
    request<{ username: string; role: string; access_token: string }>("/api/v0/users", {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  updateUser: (username: string, payload: { username: string; access_token?: string }) =>
    request(`/api/v0/users/${encodeURIComponent(username)}`, { method: "PUT", body: JSON.stringify(payload) }),
  deleteUser: (username: string) => request(`/api/v0/users/${encodeURIComponent(username)}`, { method: "DELETE" }),
  whoami: () => request<User>("/api/v0/users/whoami")
};

export default api;

export type AgentStatus = "draft" | "in_review" | "published" | "unpublished" | "archived";

export type AgentMetaInput = {
  title: string;
  description: string;
  avatar?: string;
  category?: string;
  tags?: string[];
};

export type AgentConfigInput = {
  systemRole: string;
  openingMessage?: string;
  openingQuestions?: string[];
  params?: Record<string, any>;
  plugins?: string[];
  examples?: any[];
};

export type AgentLocaleInput = {
  meta: AgentMetaInput;
  config: AgentConfigInput;
  author?: string;
  homepage?: string;
};

export type AgentCreatePayload = {
  identifier: string;
  version?: string;
  mcp_servers?: string[];
  mcp_tools?: string[];
  locales: Record<string, AgentLocaleInput>;
};

export type AgentUpdateVersionPayload = {
  version: string;
  mcp_servers?: string[];
  mcp_tools?: string[];
  locales: Record<string, AgentLocaleInput>;
};

export type AgentReviewPayload = {
  note?: string;
};

export type AgentPublishPayload = {
  version?: string;
};

export type AgentListItem = {
  identifier: string;
  title: string;
  description: string;
  status: AgentStatus;
  latest_version?: string | null;
  published_version?: string | null;
  updated_at: string;
  avatar?: string | null;
  category?: string | null;
  tags?: string[];
};

export type AgentListResponse = {
  items: AgentListItem[];
  total: number;
  page: number;
  page_size: number;
};

export type AgentVersion = {
  version: string;
  locales: string[];
  mcp_servers?: string[];
  mcp_tools?: string[];
  created_at: string;
  updated_at: string;
};

export type AgentDetail = {
  identifier: string;
  title: string;
  description: string;
  avatar?: string | null;
  category?: string | null;
  tags?: string[];
  status: AgentStatus;
  latest_version?: string | null;
  published_version?: string | null;
  review_note?: string | null;
  reviewed_at?: string | null;
  created_at: string;
  updated_at: string;
  versions: AgentVersion[];
};

export type AgentCreateResponse = {
  identifier: string;
  version: string;
  status: AgentStatus;
};

type Config = {
  baseUrl: string;
  accessToken?: string;
};

const STORAGE_KEY = "agenthub_config";

const resolveDefaultBaseUrl = () => {
  if (typeof window !== "undefined" && window.location?.origin) {
    return `${window.location.origin}/fang-agents`;
  }
  return "http://127.0.0.1:8088/fang-agents";
};

const defaultConfig: Config = {
  baseUrl: resolveDefaultBaseUrl(),
  accessToken: ""
};

export const getAgenthubConfig = (): Config => {
  if (typeof window === "undefined") return defaultConfig;
  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (!raw) return defaultConfig;
  try {
    const parsed = JSON.parse(raw) as Config;
    return {
      baseUrl: parsed.baseUrl || defaultConfig.baseUrl,
      accessToken: parsed.accessToken || ""
    };
  } catch {
    return defaultConfig;
  }
};

export const setAgenthubConfig = (config: Config) => {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
};

const resolveBaseUrl = (baseUrl: string) => {
  if (typeof window === "undefined") return baseUrl;
  const normalized = baseUrl.replace(/\/+$/, "");
  if (import.meta.env.DEV) {
    if (normalized === "http://127.0.0.1:8088/fang-agents" || normalized === "http://localhost:8088/fang-agents") {
      return "/fang-agents";
    }
    if (normalized === "http://127.0.0.1:8091" || normalized === "http://localhost:8091") {
      return "/agenthub";
    }
  }
  return baseUrl;
};

const buildUrl = (baseUrl: string, path: string) => {
  const resolved = resolveBaseUrl(baseUrl);
  const trimmed = resolved.replace(/\/+$/, "");
  return `${trimmed}${path}`;
};

const request = async <T>(path: string, init?: RequestInit): Promise<T> => {
  const { baseUrl, accessToken } = getAgenthubConfig();
  const url = buildUrl(baseUrl, path);

  const headers = new Headers(init?.headers || {});
  if (!headers.has("Content-Type") && init?.body && !(init?.body instanceof FormData)) {
    headers.set("Content-Type", "application/json");
  }
  if (accessToken) {
    headers.set("Authorization", `Bearer ${accessToken}`);
  }

  const resp = await fetch(url, { ...init, headers });
  if (!resp.ok) {
    const contentType = resp.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      const data = await resp.json();
      const message = data?.detail || data?.error || `HTTP ${resp.status}`;
      throw new Error(message);
    }
    const text = await resp.text();
    throw new Error(text || `HTTP ${resp.status}`);
  }

  if (resp.status === 204) {
    return undefined as T;
  }

  const contentType = resp.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return resp.json() as Promise<T>;
  }
  return (await resp.text()) as unknown as T;
};

type ListParams = {
  statuses?: AgentStatus[];
  page?: number;
  pageSize?: number;
};

const buildListQuery = (params?: ListParams) => {
  if (!params) return "";
  const qs = new URLSearchParams();
  params.statuses?.forEach((value) => qs.append("statuses", value));
  if (params.page) qs.set("page", String(params.page));
  if (params.pageSize) qs.set("page_size", String(params.pageSize));
  const query = qs.toString();
  return query ? `?${query}` : "";
};

const api = {
  getHealth: () => request<{ status: string }>("/health"),
  listAgents: (params?: ListParams) => request<AgentListResponse>(`/agents${buildListQuery(params)}`),
  getAgent: (identifier: string) => request<AgentDetail>(`/agents/${encodeURIComponent(identifier)}`),
  createAgent: (payload: AgentCreatePayload) =>
    request<AgentCreateResponse>("/agents", {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  createVersion: (identifier: string, payload: AgentUpdateVersionPayload) =>
    request<AgentCreateResponse>(`/agents/${encodeURIComponent(identifier)}/versions`, {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  submitReview: (identifier: string, payload?: AgentReviewPayload) =>
    request<AgentDetail>(`/agents/${encodeURIComponent(identifier)}/submit-review`, {
      method: "POST",
      body: JSON.stringify(payload || {})
    }),
  approveAgent: (identifier: string, payload?: AgentPublishPayload) =>
    request<AgentDetail>(`/agents/${encodeURIComponent(identifier)}/approve`, {
      method: "POST",
      body: JSON.stringify(payload || {})
    }),
  rejectAgent: (identifier: string, payload?: AgentReviewPayload) =>
    request<AgentDetail>(`/agents/${encodeURIComponent(identifier)}/reject`, {
      method: "POST",
      body: JSON.stringify(payload || {})
    }),
  publishAgent: (identifier: string, payload?: AgentPublishPayload) =>
    request<AgentDetail>(`/agents/${encodeURIComponent(identifier)}/publish`, {
      method: "POST",
      body: JSON.stringify(payload || {})
    }),
  unpublishAgent: (identifier: string) =>
    request<AgentDetail>(`/agents/${encodeURIComponent(identifier)}/unpublish`, {
      method: "POST" }
    ),
  exportAgents: () => request<{ status: string }>("/agents/export", { method: "POST" })
};

export default api;

export type SkillType = "custom" | "org-provisioned" | "partner" | "anthropic";
export type SkillStatus = "draft" | "active" | "deprecated" | "archived";
export type ValidationStatus = "not_validated" | "passed" | "failed" | "not_available";

export type SkillListItem = {
  name: string;
  description: string;
  type: SkillType;
  status: SkillStatus;
  latest_version?: string | null;
  updated_at: string;
  dependencies_count: number;
  resources_count: number;
  validation_status: ValidationStatus;
};

export type SkillListResponse = {
  items: SkillListItem[];
  total: number;
  page: number;
  page_size: number;
};

export type SkillVersion = {
  version: string;
  directory_name: string;
  dependencies?: string[] | null;
  files_summary?: Record<string, any> | null;
  files_manifest?: string[] | null;
  dependencies_count: number;
  resources_count: number;
  validation_status: ValidationStatus;
  validated_at?: string | null;
  validation_report?: any;
  package_available: boolean;
  created_at: string;
  updated_at: string;
};

export type SkillDetail = {
  name: string;
  description: string;
  type: SkillType;
  status: SkillStatus;
  latest_version?: string | null;
  created_at: string;
  updated_at: string;
  versions: SkillVersion[];
};

export type SkillStatusUpdatePayload = {
  status: SkillStatus;
};

export type SkillsRefHealth = {
  available: boolean;
  bin: string;
  path?: string | null;
  module_available?: boolean;
  command?: string[] | null;
};

export type UploadResponse = {
  name: string;
  version: string;
  status: string;
  warnings?: string[];
};

export type SkillCreatePayload = {
  name: string;
  description: string;
  version?: string;
  type?: SkillType;
  dependencies?: string[];
};

export type SkillCreateResponse = {
  name: string;
  version: string;
  status: string;
};

export type ValidationResponse = {
  status: ValidationStatus;
  validated_at?: string | null;
  report?: any;
};

export type PackageResponse = {
  package_path: string;
  created_at: string;
};

type Config = {
  baseUrl: string;
  accessToken?: string;
};

const STORAGE_KEY = "skillhub_config";

const resolveDefaultBaseUrl = () => {
  if (typeof window !== "undefined" && window.location?.origin) {
    return `${window.location.origin}/skill`;
  }
  return "http://127.0.0.1:8088/skill";
};

const defaultConfig: Config = {
  baseUrl: resolveDefaultBaseUrl(),
  accessToken: ""
};

export const getSkillhubConfig = (): Config => {
  if (typeof window === "undefined") return defaultConfig;
  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (!raw) return defaultConfig;
  try {
    const parsed = JSON.parse(raw) as Config;
    return {
      baseUrl: parsed.baseUrl || defaultConfig.baseUrl,
      accessToken: parsed.accessToken || ""
    };
  } catch {
    return defaultConfig;
  }
};

export const setSkillhubConfig = (config: Config) => {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
};

const resolveBaseUrl = (baseUrl: string) => {
  if (typeof window === "undefined") return baseUrl;
  const normalized = baseUrl.replace(/\/+$/, "");
  if (import.meta.env.DEV) {
    if (normalized === "http://127.0.0.1:8088/skill" || normalized === "http://localhost:8088/skill") {
      return "/skill";
    }
    if (normalized === "http://127.0.0.1:8090" || normalized === "http://localhost:8090") {
      return "/skillhub";
    }
  }
  return baseUrl;
};

const buildUrl = (baseUrl: string, path: string) => {
  const resolved = resolveBaseUrl(baseUrl);
  const trimmed = resolved.replace(/\/+$/, "");
  return `${trimmed}${path}`;
};

const request = async <T>(path: string, init?: RequestInit): Promise<T> => {
  const { baseUrl, accessToken } = getSkillhubConfig();
  const url = buildUrl(baseUrl, path);

  const headers = new Headers(init?.headers || {});
  if (!headers.has("Content-Type") && init?.body && !(init?.body instanceof FormData)) {
    headers.set("Content-Type", "application/json");
  }
  if (accessToken) {
    headers.set("Authorization", `Bearer ${accessToken}`);
  }

  const resp = await fetch(url, { ...init, headers });
  if (!resp.ok) {
    const contentType = resp.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      const data = await resp.json();
      const message = data?.detail || data?.error || `HTTP ${resp.status}`;
      throw new Error(message);
    }
    const text = await resp.text();
    throw new Error(text || `HTTP ${resp.status}`);
  }

  if (resp.status === 204) {
    return undefined as T;
  }

  const contentType = resp.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return resp.json() as Promise<T>;
  }
  return (await resp.text()) as unknown as T;
};

const requestBlob = async (path: string): Promise<Blob> => {
  const { baseUrl, accessToken } = getSkillhubConfig();
  const url = buildUrl(baseUrl, path);
  const headers = new Headers();
  if (accessToken) {
    headers.set("Authorization", `Bearer ${accessToken}`);
  }
  const resp = await fetch(url, { headers });
  if (!resp.ok) {
    const contentType = resp.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      const data = await resp.json();
      const message = data?.detail || data?.error || `HTTP ${resp.status}`;
      throw new Error(message);
    }
    const text = await resp.text();
    throw new Error(text || `HTTP ${resp.status}`);
  }
  return resp.blob();
};

type ListParams = {
  types?: SkillType[];
  statuses?: SkillStatus[];
  validationStatuses?: ValidationStatus[];
  hasScripts?: boolean;
  hasDependencies?: boolean;
  validationPassed?: boolean;
  page?: number;
  pageSize?: number;
};

const buildListQuery = (params?: ListParams) => {
  if (!params) return "";
  const qs = new URLSearchParams();
  params.types?.forEach((value) => qs.append("types", value));
  params.statuses?.forEach((value) => qs.append("statuses", value));
  params.validationStatuses?.forEach((value) => qs.append("validation_statuses", value));
  if (typeof params.hasScripts === "boolean") qs.set("has_scripts", String(params.hasScripts));
  if (typeof params.hasDependencies === "boolean") qs.set("has_dependencies", String(params.hasDependencies));
  if (typeof params.validationPassed === "boolean") qs.set("validation_passed", String(params.validationPassed));
  if (params.page) qs.set("page", String(params.page));
  if (params.pageSize) qs.set("page_size", String(params.pageSize));
  const query = qs.toString();
  return query ? `?${query}` : "";
};

const api = {
  getHealth: () => request<{ status: string }>("/health"),
  getSkillsRefHealth: () => request<SkillsRefHealth>("/health/skills-ref"),
  listSkills: (params?: ListParams) => request<SkillListResponse>(`/skills${buildListQuery(params)}`),
  getSkill: (name: string) => request<SkillDetail>(`/skills/${encodeURIComponent(name)}`),
  updateSkillStatus: (name: string, payload: SkillStatusUpdatePayload) =>
    request<SkillDetail>(`/skills/${encodeURIComponent(name)}/status`, {
      method: "PATCH",
      body: JSON.stringify(payload)
    }),
  uploadSkill: async (file: File, version?: string) => {
    const form = new FormData();
    form.append("file", file);
    const query = version ? `?version=${encodeURIComponent(version)}` : "";
    return request<UploadResponse>(`/skills/upload${query}`, { method: "POST", body: form });
  },
  createSkill: (payload: SkillCreatePayload) =>
    request<SkillCreateResponse>("/skills/create", {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  downloadTemplate: () => requestBlob("/skills/template"),
  validateSkillVersion: (name: string, version: string) =>
    request<ValidationResponse>(`/skills/${encodeURIComponent(name)}/versions/${encodeURIComponent(version)}/validate`, {
      method: "POST"
    }),
  packageSkillVersion: (name: string, version: string) =>
    request<PackageResponse>(`/skills/${encodeURIComponent(name)}/versions/${encodeURIComponent(version)}/package`, {
      method: "POST"
    }),
  getPackageUrl: (name: string, version: string) => {
    const { baseUrl } = getSkillhubConfig();
    return buildUrl(baseUrl, `/skills/${encodeURIComponent(name)}/versions/${encodeURIComponent(version)}/package`);
  }
};

export default api;

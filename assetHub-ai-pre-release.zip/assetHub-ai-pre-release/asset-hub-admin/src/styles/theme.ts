import { theme as antdTheme } from "antd";

export const themeConfig = {
  algorithm: antdTheme.defaultAlgorithm,
  token: {
    colorPrimary: "#0052FF",
    colorInfo: "#4D7CFF",
    colorText: "#0F172A",
    colorTextSecondary: "#64748B",
    colorBgLayout: "#FAFAFA",
    colorBgContainer: "#FFFFFF",
    colorBorder: "#E2E8F0",
    colorLink: "#0052FF",
    fontFamily: '"Inter", system-ui, sans-serif',
    fontFamilyCode: '"JetBrains Mono", monospace',
    borderRadius: 12
  },
  components: {
    Layout: {
      headerBg: "#FFFFFF",
      siderBg: "#FFFFFF",
      bodyBg: "#FAFAFA"
    },
    Menu: {
      itemBg: "transparent",
      itemHoverBg: "#F1F5F9",
      itemSelectedBg: "rgba(0, 82, 255, 0.12)",
      itemSelectedColor: "#0052FF"
    },
    Button: {
      borderRadius: 12
    },
    Card: {
      borderRadiusLG: 16
    }
  }
};

import type { ReactNode } from "react";

type StatCardProps = {
  label: string;
  value: string;
  trend?: string;
  icon?: ReactNode;
};

const StatCard = ({ label, value, trend, icon }: StatCardProps) => {
  return (
    <div className="stat-card">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ color: "var(--muted-foreground)", fontSize: 12 }} className="mono-label">
          {label}
        </div>
        {icon && <div style={{ color: "var(--accent)", fontSize: 18 }}>{icon}</div>}
      </div>
      <div style={{ fontSize: 28, fontWeight: 600, marginTop: 8 }}>{value}</div>
      {trend && (
        <div style={{ marginTop: 6, fontSize: 12, color: "var(--accent)" }}>
          {trend}
        </div>
      )}
    </div>
  );
};

export default StatCard;

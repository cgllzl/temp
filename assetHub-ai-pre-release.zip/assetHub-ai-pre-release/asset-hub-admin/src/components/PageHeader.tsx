import { Breadcrumb, Space, Typography } from "antd";
import type { ReactNode } from "react";

const { Title, Text } = Typography;

type BreadcrumbItem = {
  title: ReactNode;
  href?: string;
};

type PageHeaderProps = {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  breadcrumbs?: BreadcrumbItem[];
};

const PageHeader = ({ title, subtitle, actions, breadcrumbs }: PageHeaderProps) => {
  return (
    <div style={{ marginBottom: 20, display: "flex", alignItems: "flex-end", gap: 16 }}>
      <div style={{ flex: 1 }}>
        {breadcrumbs && breadcrumbs.length > 0 && (
          <Breadcrumb
            items={breadcrumbs.map((item) => ({
              title: item.href ? <a href={item.href}>{item.title}</a> : item.title
            }))}
            style={{ marginBottom: 8, color: "var(--muted-foreground)" }}
          />
        )}
        <Title level={2} className="display-font" style={{ margin: 0 }}>
          {title}
        </Title>
        {subtitle && (
          <Text type="secondary" style={{ fontSize: 14 }}>
            {subtitle}
          </Text>
        )}
      </div>
      {actions && <Space>{actions}</Space>}
    </div>
  );
};

export default PageHeader;

import type { ReactNode } from "react";
import EmptyState from "./EmptyState";
import PageHeader from "./PageHeader";

type PlaceholderPageProps = {
  title: string;
  subtitle?: string;
  emptyTitle: string;
  emptyDescription?: string;
  actions?: ReactNode;
  children?: ReactNode;
};

const PlaceholderPage = ({
  title,
  subtitle,
  emptyTitle,
  emptyDescription,
  actions,
  children
}: PlaceholderPageProps) => {
  return (
    <div>
      <PageHeader title={title} subtitle={subtitle} actions={actions} />
      {children ?? <EmptyState title={emptyTitle} description={emptyDescription} actions={actions} />}
    </div>
  );
};

export default PlaceholderPage;

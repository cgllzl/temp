import { Empty } from "antd";
import type { ReactNode } from "react";

type EmptyStateProps = {
  title: string;
  description?: string;
  actions?: ReactNode;
};

const EmptyState = ({ title, description, actions }: EmptyStateProps) => {
  return (
    <div style={{ padding: 48, textAlign: "center" }}>
      <Empty
        description={
          <div>
            <div style={{ fontWeight: 600, marginBottom: 8 }}>{title}</div>
            {description && <div style={{ color: "var(--muted-foreground)" }}>{description}</div>}
          </div>
        }
      />
      {actions && <div style={{ marginTop: 16 }}>{actions}</div>}
    </div>
  );
};

export default EmptyState;

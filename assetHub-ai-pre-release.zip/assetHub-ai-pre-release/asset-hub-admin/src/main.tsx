import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import AppProviders from "./app/AppProviders";
import { I18nProvider } from "./i18n";
import "antd/dist/reset.css";
import "./styles/globals.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <I18nProvider>
      <AppProviders>
        <App />
      </AppProviders>
    </I18nProvider>
  </React.StrictMode>
);

import { Layout } from "antd";
import { useState } from "react";
import { Outlet } from "react-router-dom";
import { useI18n } from "../i18n";
import SideNav from "./components/SideNav";
import TopBar from "./components/TopBar";

const { Header, Sider, Content } = Layout;

const AdminLayout = () => {
  const [collapsed, setCollapsed] = useState(false);
  const { t } = useI18n();

  return (
    <Layout style={{ minHeight: "100vh" }}>
      <Sider
        width={260}
        collapsible
        collapsed={collapsed}
        onCollapse={setCollapsed}
        breakpoint="lg"
        collapsedWidth={80}
      >
        <div
          style={{
            height: 72,
            display: "flex",
            alignItems: "center",
            gap: 12,
            padding: "0 20px",
            borderBottom: "1px solid var(--border)"
          }}
        >
          <div
            style={{
              width: 36,
              height: 36,
              borderRadius: 12,
              background: "linear-gradient(135deg, var(--accent), var(--accent-secondary))",
              boxShadow: "var(--shadow-accent)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff",
              fontWeight: 700
            }}
          >
            AH
          </div>
          {!collapsed && (
            <div>
              <div className="display-font" style={{ fontSize: 18 }}>
                {t("app.name")}
              </div>
              <div style={{ fontSize: 12, color: "var(--muted-foreground)" }}>{t("app.subtitle")}</div>
            </div>
          )}
        </div>
        <SideNav collapsed={collapsed} />
      </Sider>
      <Layout>
        <Header>
          <TopBar />
        </Header>
        <Content style={{ padding: "24px 28px 48px" }}>
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
};

export default AdminLayout;

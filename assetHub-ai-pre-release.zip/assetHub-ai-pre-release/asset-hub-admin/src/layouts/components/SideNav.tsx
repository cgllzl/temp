import {
  AppstoreOutlined,
  KeyOutlined,
  ProfileOutlined,
  RadarChartOutlined,
  SafetyCertificateOutlined,
  SettingOutlined
} from "@ant-design/icons";
import type { MenuProps } from "antd";
import { Menu } from "antd";
import { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useI18n } from "../../i18n";

const SideNav = ({ collapsed }: { collapsed: boolean }) => {
  const location = useLocation();
  const { t } = useI18n();

  const items: MenuProps["items"] = [
    {
      key: "/dashboard",
      icon: <AppstoreOutlined />,
      label: <Link to="/dashboard">{t("menu.dashboard")}</Link>
    },
    {
      key: "assets",
      icon: <ProfileOutlined />,
      label: t("menu.assets"),
      children: [
        { key: "/assets", label: <Link to="/assets">{t("menu.assets.overview")}</Link> },
        { key: "/assets/mcp", label: <Link to="/assets/mcp">{t("menu.assets.mcp")}</Link> },
        { key: "/assets/skills", label: <Link to="/assets/skills">{t("menu.assets.skills")}</Link> },
        { key: "/assets/prompts", label: <Link to="/assets/prompts">{t("menu.assets.prompts")}</Link> },
        { key: "/assets/agents", label: <Link to="/assets/agents">{t("menu.assets.agents")}</Link> }
      ]
    },
    {
      key: "governance",
      icon: <SafetyCertificateOutlined />,
      label: t("menu.governance"),
      children: [
        { key: "/governance/approvals", label: <Link to="/governance/approvals">{t("menu.governance.approvals")}</Link> },
        { key: "/governance/policies", label: <Link to="/governance/policies">{t("menu.governance.policies")}</Link> }
      ]
    },
    {
      key: "observability",
      icon: <RadarChartOutlined />,
      label: t("menu.observability"),
      children: [
        { key: "/observability/metrics", label: <Link to="/observability/metrics">{t("menu.observability.metrics")}</Link> },
        { key: "/observability/logs", label: <Link to="/observability/logs">{t("menu.observability.logs")}</Link> }
      ]
    },
    {
      key: "access",
      icon: <KeyOutlined />,
      label: t("menu.access"),
      children: [
        { key: "/access/users", label: <Link to="/access/users">{t("menu.access.users")}</Link> },
        { key: "/access/roles", label: <Link to="/access/roles">{t("menu.access.roles")}</Link> },
        { key: "/access/clients", label: <Link to="/access/clients">{t("menu.access.clients")}</Link> }
      ]
    },
    {
      key: "system",
      icon: <SettingOutlined />,
      label: t("menu.system"),
      children: [
        { key: "/system/settings", label: <Link to="/system/settings">{t("menu.system.settings")}</Link> },
        { key: "/system/audit", label: <Link to="/system/audit">{t("menu.system.audit")}</Link> }
      ]
    }
  ];

  const rootKeys = useMemo(() => ["assets", "governance", "observability", "access", "system"], []);

  const getOpenKeys = (path: string) => {
    if (path.startsWith("/assets")) return ["assets"];
    if (path.startsWith("/governance")) return ["governance"];
    if (path.startsWith("/observability")) return ["observability"];
    if (path.startsWith("/access")) return ["access"];
    if (path.startsWith("/system")) return ["system"];
    return [];
  };

  const getSelectedKey = (path: string) => {
    if (path.startsWith("/assets/mcp")) return "/assets/mcp";
    return path;
  };

  const [openKeys, setOpenKeys] = useState<string[]>(getOpenKeys(location.pathname));

  useEffect(() => {
    setOpenKeys(getOpenKeys(location.pathname));
  }, [location.pathname]);

  return (
    <Menu
      mode="inline"
      inlineCollapsed={collapsed}
      items={items}
      selectedKeys={[getSelectedKey(location.pathname)]}
      openKeys={openKeys}
      onOpenChange={(keys) => {
        const latest = keys.find((key) => !openKeys.includes(key as string));
        if (latest && rootKeys.includes(latest as string)) {
          setOpenKeys([latest as string]);
        } else {
          setOpenKeys(keys as string[]);
        }
      }}
      style={{ padding: "12px 8px" }}
    />
  );
};

export default SideNav;

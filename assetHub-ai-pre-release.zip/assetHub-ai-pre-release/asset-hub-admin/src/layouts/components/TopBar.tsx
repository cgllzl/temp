import { BellOutlined, DownOutlined, SearchOutlined } from "@ant-design/icons";
import type { MenuProps } from "antd";
import { App, Avatar, Badge, Button, Dropdown, Input, Select, Space } from "antd";
import { useI18n } from "../../i18n";
import { useNavigate } from "react-router-dom";
import authApi from "../../services/uiauth";

const TopBar = () => {
  const { locale, setLocale, t } = useI18n();
  const navigate = useNavigate();
  const { message } = App.useApp();
  const handleSignOut = async () => {
    try {
      await authApi.signOut();
      message.success(t("message.signOutSuccess"));
      window.location.reload();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      message.error(messageText || t("message.signOutFailed"));
    }
  };

  const userMenu: MenuProps = {
    items: [
      { key: "profile", label: t("user.profile") },
      { key: "settings", label: t("user.settings") },
      { key: "signout", label: t("user.signOut") }
    ],
    onClick: ({ key }) => {
      if (key === "profile") {
        navigate("/access/users");
        return;
      }
      if (key === "settings") {
        navigate("/system/settings");
        return;
      }
      if (key === "signout") {
        handleSignOut();
      }
    }
  };

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 16, width: "100%" }}>
      <div className="section-badge" style={{ marginRight: 12 }}>
        <span className="pulse-dot" />
        <span className="mono-label">{t("app.badge")}</span>
      </div>
      <Input
        placeholder={t("search.placeholder")}
        prefix={<SearchOutlined style={{ color: "var(--muted-foreground)" }} />}
        style={{ maxWidth: 360, borderRadius: 12 }}
      />
      <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 12 }}>
        <Select
          size="middle"
          value={locale}
          onChange={(value) => setLocale(value as typeof locale)}
          style={{ width: 120 }}
          options={[
            { value: "zh-CN", label: t("locale.zh") },
            { value: "en-US", label: t("locale.en") }
          ]}
        />
        <Badge dot>
          <Button shape="circle" icon={<BellOutlined />} />
        </Badge>
        <Dropdown menu={userMenu} placement="bottomRight">
          <Space style={{ cursor: "pointer" }}>
            <Avatar style={{ background: "var(--accent)" }}>JD</Avatar>
            <DownOutlined style={{ fontSize: 12, color: "var(--muted-foreground)" }} />
          </Space>
        </Dropdown>
      </div>
    </div>
  );
};

export default TopBar;

import { Spin } from "antd";
import { useEffect, useState } from "react";
import { BrowserRouter, Navigate, Route, Routes, useParams } from "react-router-dom";
import AdminLayout from "./layouts/AdminLayout";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import AssetsIndex from "./pages/AssetsIndex";
import AssetsMcp from "./pages/AssetsMcp";
import AssetsSkills from "./pages/AssetsSkills";
import AssetsPrompts from "./pages/AssetsPrompts";
import AssetsAgents from "./pages/AssetsAgents";
import AssetDetail from "./pages/AssetDetail";
import SkillsDetail from "./pages/SkillsDetail";
import SkillsGuide from "./pages/SkillsGuide";
import RegistryServerDetail from "./pages/RegistryServerDetail";
import GovernanceApprovals from "./pages/GovernanceApprovals";
import GovernancePolicies from "./pages/GovernancePolicies";
import ObservabilityMetrics from "./pages/ObservabilityMetrics";
import ObservabilityLogs from "./pages/ObservabilityLogs";
import AccessUsers from "./pages/AccessUsers";
import AccessRoles from "./pages/AccessRoles";
import AccessClients from "./pages/AccessClients";
import SystemSettings from "./pages/SystemSettings";
import SystemAudit from "./pages/SystemAudit";
import NotFound from "./pages/NotFound";
import authApi from "./services/uiauth";

const RegistryServerRedirect = () => {
  const { name } = useParams();
  const target = name ? `/assets/mcp/servers/${encodeURIComponent(name)}` : "/assets/mcp/servers";
  return <Navigate to={target} replace />;
};

const AuthGate = ({ children }: { children: React.ReactNode }) => {
  const [loading, setLoading] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);

  const refreshSession = async () => {
    setLoading(true);
    try {
      await authApi.getSession();
      setAuthenticated(true);
    } catch {
      setAuthenticated(false);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshSession();
  }, []);

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Spin size="large" />
      </div>
    );
  }

  if (!authenticated) {
    return <Login onSuccess={refreshSession} />;
  }

  return <>{children}</>;
};

const App = () => {
  return (
    <BrowserRouter>
      <AuthGate>
        <Routes>
          <Route element={<AdminLayout />}>
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/assets" element={<AssetsIndex />} />
            <Route path="/assets/mcp" element={<AssetsMcp />} />
            <Route path="/assets/mcp/servers" element={<Navigate to="/assets/mcp?tab=servers" replace />} />
            <Route path="/assets/mcp/servers/:name" element={<RegistryServerDetail />} />
            <Route path="/assets/mcp/tools" element={<Navigate to="/assets/mcp?tab=tools" replace />} />
            <Route path="/assets/mcp/tool-groups" element={<Navigate to="/assets/mcp?tab=toolGroups" replace />} />
            <Route path="/assets/skills" element={<AssetsSkills />} />
            <Route path="/assets/skills/guide" element={<SkillsGuide />} />
            <Route path="/assets/skills/:name" element={<SkillsDetail />} />
            <Route path="/assets/prompts" element={<AssetsPrompts />} />
            <Route path="/assets/agents" element={<AssetsAgents />} />
            <Route path="/assets/:type/:id" element={<AssetDetail />} />
            <Route path="/registry/servers" element={<Navigate to="/assets/mcp?tab=servers" replace />} />
            <Route path="/registry/servers/:name" element={<RegistryServerRedirect />} />
            <Route path="/registry/tools" element={<Navigate to="/assets/mcp?tab=tools" replace />} />
            <Route path="/registry/tool-groups" element={<Navigate to="/assets/mcp?tab=toolGroups" replace />} />
            <Route path="/governance/approvals" element={<GovernanceApprovals />} />
            <Route path="/governance/policies" element={<GovernancePolicies />} />
            <Route path="/observability/metrics" element={<ObservabilityMetrics />} />
            <Route path="/observability/logs" element={<ObservabilityLogs />} />
            <Route path="/access/users" element={<AccessUsers />} />
            <Route path="/access/roles" element={<AccessRoles />} />
            <Route path="/access/clients" element={<AccessClients />} />
            <Route path="/system/settings" element={<SystemSettings />} />
            <Route path="/system/audit" element={<SystemAudit />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </AuthGate>
    </BrowserRouter>
  );
};

export default App;

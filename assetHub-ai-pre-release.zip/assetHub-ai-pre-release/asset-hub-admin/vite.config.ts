import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    open: false,
    proxy: {
      "/mcp": {
        target: "http://127.0.0.1:8088",
        changeOrigin: true
      },
      "/fang-agents": {
        target: "http://127.0.0.1:8088",
        changeOrigin: true
      },
      "/fang-agents-index": {
        target: "http://127.0.0.1:8088",
        changeOrigin: true
      },
      "/skill": {
        target: "http://127.0.0.1:8088",
        changeOrigin: true
      },
      "/ui-api": {
        target: "http://127.0.0.1:8088",
        changeOrigin: true
      },
      "/mcpjungle": {
        target: "http://127.0.0.1:8088",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/mcpjungle/, "/ui-api/mcpjungle")
      },
      "/skillhub": {
        target: "http://127.0.0.1:8088",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/skillhub/, "/skill")
      },
      "/agenthub": {
        target: "http://127.0.0.1:8088",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/agenthub/, "/fang-agents")
      }
    }
  }
});

from __future__ import annotations

import json
import os
import secrets
import sys
import time
from pathlib import Path
from typing import Any, Dict, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen


def read_token(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        return ""
    except OSError as exc:
        print(f"[bootstrap] failed to read token file: {exc}", file=sys.stderr)
        return ""


def write_token(path: Path, token: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"{token}\n", encoding="utf-8")


def request_json(
    base_url: str,
    path: str,
    method: str = "GET",
    token: str = "",
    payload: Dict[str, Any] | None = None,
    timeout: float = 10,
) -> Tuple[int, str]:
    url = base_url.rstrip("/") + path
    data = None
    headers: Dict[str, str] = {"Accept": "application/json"}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    if token:
        headers["Authorization"] = f"Bearer {token}"

    req = Request(url, data=data, method=method, headers=headers)
    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            return resp.status, raw
    except HTTPError as exc:
        raw = exc.read().decode("utf-8") if exc.fp else ""
        return exc.code, raw
    except URLError as exc:
        raise exc


def wait_ready(base_url: str, timeout: float, retries: int) -> None:
    for attempt in range(retries):
        try:
            status, _ = request_json(base_url, "/health", timeout=timeout)
            if status == 200:
                return
        except URLError:
            pass
        time.sleep(2)
    raise RuntimeError("mcpjungle is not ready")


def main() -> int:
    base_url = os.getenv("MCPJUNGLE_BASE_URL", "http://ai-assethub-mcphub:8080").rstrip("/")
    init_mode = os.getenv("MCPJUNGLE_INIT_MODE", "enterprise")
    admin_token_path = Path(os.getenv("MCPJUNGLE_ADMIN_TOKEN_PATH", "/data/mcpjungle/admin.token"))
    user_name = os.getenv("MCP_SERVICE_PRINCIPAL_NAME", "svc-agenthub-runtime")
    user_token_path = Path(
        os.getenv("MCP_SERVICE_PRINCIPAL_TOKEN_PATH", "/data/mcpjungle/service-principals/agenthub-runtime.token")
    )
    timeout = float(os.getenv("MCPJUNGLE_TIMEOUT_SECONDS", "10"))
    retries = int(os.getenv("MCPJUNGLE_INIT_RETRIES", "30"))

    existing_user_token = read_token(user_token_path)
    if existing_user_token:
        print("[bootstrap] service principal token already exists")
        return 0

    try:
        wait_ready(base_url, timeout, retries)
    except Exception as exc:
        print(f"[bootstrap] wait mcpjungle failed: {exc}", file=sys.stderr)
        return 1

    admin_token = read_token(admin_token_path)
    if not admin_token:
        status, raw = request_json(base_url, "/init", method="POST", payload={"mode": init_mode}, timeout=timeout)
        if status in (200, 201):
            if init_mode == "development":
                print("[bootstrap] dev mode initialized")
                return 0
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                data = {}
            admin_token = (data.get("admin_access_token") or "").strip()
            if not admin_token:
                print("[bootstrap] init ok but admin token missing", file=sys.stderr)
                return 1
            write_token(admin_token_path, admin_token)
            print("[bootstrap] admin token saved")
        elif status == 400 and "already initialized" in raw:
            if init_mode == "development":
                print("[bootstrap] dev mode already initialized")
                return 0
            admin_token = read_token(admin_token_path)
            if not admin_token:
                print("[bootstrap] server already initialized but admin token missing", file=sys.stderr)
                return 1
        else:
            print(f"[bootstrap] init failed: HTTP {status} {raw}", file=sys.stderr)
            return 1

    status, raw = request_json(base_url, "/api/v0/users", token=admin_token, timeout=timeout)
    if status != 200:
        print(f"[bootstrap] list users failed: HTTP {status} {raw}", file=sys.stderr)
        return 1
    try:
        users = json.loads(raw)
    except json.JSONDecodeError:
        users = []

    exists = any(user.get("username") == user_name for user in users if isinstance(user, dict))
    if exists:
        new_token = secrets.token_urlsafe(32)
        status, raw = request_json(
            base_url,
            f"/api/v0/users/{quote(user_name)}",
            method="PUT",
            token=admin_token,
            payload={"username": user_name, "access_token": new_token},
            timeout=timeout,
        )
    else:
        status, raw = request_json(
            base_url,
            "/api/v0/users",
            method="POST",
            token=admin_token,
            payload={"username": user_name},
            timeout=timeout,
        )

    if status not in (200, 201):
        print(f"[bootstrap] upsert user failed: HTTP {status} {raw}", file=sys.stderr)
        return 1

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        data = {}
    access_token = (data.get("access_token") or "").strip()
    if not access_token:
        print("[bootstrap] user token missing in response", file=sys.stderr)
        return 1

    write_token(user_token_path, access_token)
    print("[bootstrap] service principal token saved")
    return 0


if __name__ == "__main__":
    sys.exit(main())
